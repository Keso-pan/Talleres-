# -*- coding: utf-8 -*-
"""
modulos/modulo_erp.py
Proyecto Final ISID223 - Transformacion Digital Empresarial (MerkaExpress)

Modulo ERP (Mini-Financiero).
Se suscribe al SistemaPOS (patron Observer). Cada vez que se registra una
venta, SIN INTERVENCION HUMANA:
  1) Genera el Asiento Contable de partida doble (Debe / Haber).
  2) Actualiza el saldo de Caja Chica.
Este es el modulo satelite de "Integracion Empresarial" exigido en la Fase 2.2.
"""

import csv
import os

from core.sistema_pos import ObservadorVenta
from core.modelos import Venta


class ModuloERP(ObservadorVenta):

    def __init__(self, ruta_datos: str = "data", saldo_inicial_caja: float = 5000.0):
        self.ruta_datos = ruta_datos
        self.saldo_caja = saldo_inicial_caja
        self.verbose = True
        self._contador_asientos = 0
        self.archivo_contabilidad = os.path.join(ruta_datos, "contabilidad_asientos.csv")
        self.archivo_caja = os.path.join(ruta_datos, "caja_chica.csv")
        self._inicializar_archivos()

    def _inicializar_archivos(self) -> None:
        with open(self.archivo_contabilidad, "w", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow([
                "id_asiento", "id_venta", "fecha", "cuenta", "debe", "haber", "detalle",
            ])
        with open(self.archivo_caja, "w", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow(["id_venta", "fecha", "movimiento", "monto", "saldo_caja"])
            csv.writer(f).writerow(["-", "-", "Saldo inicial de caja chica", 0, self.saldo_caja])

    # ---- Reaccion automatica a la venta (Observer) ----
    def actualizar(self, venta: Venta) -> None:
        self._registrar_asiento_contable(venta)
        self._actualizar_caja_chica(venta)

    def _registrar_asiento_contable(self, venta: Venta) -> None:
        self._contador_asientos += 1
        id_asiento = f"AC-{self._contador_asientos:06d}"
        lineas = [
            (id_asiento, venta.id_venta, venta.fecha, "1.1.01 Caja/Bancos",
             venta.total, 0, f"Cobro de venta {venta.id_venta}"),
            (id_asiento, venta.id_venta, venta.fecha, "4.1.01 Ventas",
             0, venta.subtotal, f"Ingreso por venta {venta.id_venta}"),
            (id_asiento, venta.id_venta, venta.fecha, "2.1.03 Impuesto por Pagar (5%)",
             0, venta.impuesto, f"Impuesto generado en venta {venta.id_venta}"),
        ]
        if venta.costo_total > 0:
            lineas += [
                (id_asiento, venta.id_venta, venta.fecha, "5.1.01 Costo de Ventas",
                 venta.costo_total, 0, f"Costo real (histórico) de {venta.id_venta}"),
                (id_asiento, venta.id_venta, venta.fecha, "1.1.05 Inventario",
                 0, venta.costo_total, f"Salida de inventario por {venta.id_venta}"),
            ]
        with open(self.archivo_contabilidad, "a", newline="", encoding="utf-8") as f:
            csv.writer(f).writerows(lineas)

    def _actualizar_caja_chica(self, venta: Venta) -> None:
        self.saldo_caja = round(self.saldo_caja + venta.total, 2)
        with open(self.archivo_caja, "a", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow([
                venta.id_venta, venta.fecha, "Ingreso por venta (POS)",
                venta.total, self.saldo_caja,
            ])
        if self.verbose:
            print(f"   [ERP]  Asiento contable generado para {venta.id_venta} "
                  f"| Caja chica -> ${self.saldo_caja:,.2f}")
