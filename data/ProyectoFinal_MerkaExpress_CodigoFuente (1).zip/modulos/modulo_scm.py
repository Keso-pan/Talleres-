# -*- coding: utf-8 -*-
"""
modulos/modulo_scm.py
Proyecto Final ISID223 - Transformacion Digital Empresarial (MerkaExpress)

Modulo SCM (Inventario / Proveedores).
Se suscribe al SistemaPOS (patron Observer). Cada vez que una venta deja el
stock de un producto en o por debajo de su punto de reorden, genera de forma
AUTOMATICA una Orden de Compra al proveedor simulado (Fase 2.2), sin
intervencion humana.
"""

import csv
import os
from datetime import datetime
from typing import Dict

from core.sistema_pos import ObservadorVenta
from core.modelos import Producto, Venta


class ModuloSCM(ObservadorVenta):

    def __init__(self, catalogo_productos: Dict[str, Producto], ruta_datos: str = "data",
                 cantidad_reorden: int = 60):
        self.productos = catalogo_productos
        self.ruta_datos = ruta_datos
        self.cantidad_reorden = cantidad_reorden
        self.verbose = True
        self._contador_ordenes = 0
        self._ordenes_pendientes = set()  # productos con OC ya generada y no recibida
        self._fecha_orden = {}            # id_producto -> fecha (str) en que se genero la OC
        self.archivo_ordenes = os.path.join(ruta_datos, "ordenes_compra.csv")
        self._inicializar_archivo()

    def _inicializar_archivo(self) -> None:
        with open(self.archivo_ordenes, "w", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow([
                "id_orden", "fecha", "id_producto", "producto", "proveedor",
                "cantidad_solicitada", "costo_estimado", "estado", "gatillada_por_venta",
            ])

    # ---- Reaccion automatica a la venta (Observer) ----
    def actualizar(self, venta: Venta) -> None:
        for detalle in venta.detalles:
            producto = self.productos.get(detalle.id_producto)
            if producto and producto.hay_stock_bajo() and producto.id_producto not in self._ordenes_pendientes:
                self._generar_orden_compra(producto, venta)

    def _generar_orden_compra(self, producto: Producto, venta: Venta) -> None:
        self._contador_ordenes += 1
        id_orden = f"OC-{self._contador_ordenes:06d}"
        costo_estimado = round(self.cantidad_reorden * producto.costo_unitario, 2)
        with open(self.archivo_ordenes, "a", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow([
                id_orden, venta.fecha, producto.id_producto, producto.nombre,
                producto.proveedor, self.cantidad_reorden, costo_estimado,
                "Generada", venta.id_venta,
            ])
        self._ordenes_pendientes.add(producto.id_producto)
        self._fecha_orden[producto.id_producto] = venta.fecha
        if self.verbose:
            print(f"   [SCM]  Stock bajo en '{producto.nombre}' ({producto.stock_actual} u., "
                  f"minimo {producto.stock_minimo}) -> Orden {id_orden} generada a "
                  f"'{producto.proveedor}' por {self.cantidad_reorden} u.")

    def ordenes_listas_para_recibir(self, fecha_actual_str: str, lead_time_dias: int = 6):
        """Devuelve los id_producto cuya OC ya cumplio el lead time del proveedor."""
        fecha_actual = datetime.strptime(fecha_actual_str, "%Y-%m-%d")
        listas = []
        for id_producto in list(self._ordenes_pendientes):
            fecha_orden = datetime.strptime(self._fecha_orden[id_producto], "%Y-%m-%d")
            if (fecha_actual - fecha_orden).days >= lead_time_dias:
                listas.append(id_producto)
        return listas

    def recibir_pedido(self, id_producto: str) -> None:
        """Simula la recepcion de mercaderia del proveedor y cierra el ciclo de la OC."""
        producto = self.productos.get(id_producto)
        if producto and id_producto in self._ordenes_pendientes:
            producto.aumentar_stock(self.cantidad_reorden)
            self._ordenes_pendientes.discard(id_producto)
            self._fecha_orden.pop(id_producto, None)
            self._marcar_orden_recibida(id_producto)
            if self.verbose:
                print(f"   [SCM]  Pedido de '{producto.nombre}' recibido del proveedor "
                      f"-> stock repuesto a {producto.stock_actual} u.")

    def _marcar_orden_recibida(self, id_producto: str) -> None:
        if not os.path.exists(self.archivo_ordenes):
            return
        with open(self.archivo_ordenes, newline="", encoding="utf-8") as f:
            filas = list(csv.reader(f))
        encabezado, resto = filas[0], filas[1:]
        for fila in resto:
            if fila[2] == id_producto and fila[7] == "Generada":
                fila[7] = "Recibida"
        with open(self.archivo_ordenes, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(encabezado)
            writer.writerows(resto)
