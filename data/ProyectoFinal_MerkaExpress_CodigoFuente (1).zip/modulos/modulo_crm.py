# -*- coding: utf-8 -*-
"""
modulos/modulo_crm.py
Proyecto Final ISID223 - Transformacion Digital Empresarial (MerkaExpress)

Modulo CRM (Relacion con el Cliente).
1) Se suscribe al SistemaPOS (patron Observer) para mantener SIEMPRE
   actualizada la fecha de ultima compra de cada cliente, sin intervencion
   humana.
2) Expone detectar_clientes_en_riesgo(): una "consulta automatizada" sobre la
   base de clientes que aisla a quienes superan un umbral de inactividad y
   dispara una alerta de "Cliente en Riesgo de Desercion" hacia la interfaz
   gerencial (Fase 2.2).
"""

import csv
import os
from datetime import datetime
from typing import Dict, List, Tuple

from core.sistema_pos import ObservadorVenta
from core.modelos import Cliente, Venta


class ModuloCRM(ObservadorVenta):

    def __init__(self, catalogo_clientes: Dict[str, Cliente], ruta_datos: str = "data"):
        self.clientes = catalogo_clientes
        self.ruta_datos = ruta_datos
        self.archivo_alertas = os.path.join(ruta_datos, "alertas_crm.csv")
        self._inicializar_archivo()

    def _inicializar_archivo(self) -> None:
        with open(self.archivo_alertas, "w", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow([
                "id_cliente", "nombre", "tipo", "fecha_ultima_compra",
                "dias_inactividad", "estado_alerta", "fecha_consulta",
            ])

    # ---- Reaccion automatica a la venta (Observer): mantiene el dato fresco ----
    def actualizar(self, venta: Venta) -> None:
        cliente = self.clientes.get(venta.id_cliente)
        if cliente:
            cliente.actualizar_ultima_compra(venta.fecha)

    # ---- Consulta automatizada de deteccion de riesgo ----
    def detectar_clientes_en_riesgo(
        self, fecha_referencia: str, umbral_dias: int = 30, solo_member: bool = True
    ) -> List[Tuple[str, str, int]]:
        """
        Recorre la base de clientes y aisla (marca) a quienes no han
        comprado en >= umbral_dias respecto de fecha_referencia. Cada
        cliente aislado dispara un registro de alerta persistido para
        la interfaz gerencial (Dashboard).

        solo_member=True (default) limita la consulta a clientes con tarjeta
        de membresia. Es una decision de negocio deliberada, no un filtro
        arbitrario: un cliente "Normal" (ocasional, sin tarjeta) no tiene
        ningun canal por el cual la empresa pueda "retenerlo" -no hay
        contacto, no hay historial reconocible en caja-, asi que marcarlo
        como "en riesgo de desercion" no es accionable. El programa de
        fidelizacion (y por lo tanto el CRM) tiene sentido sobre la base de
        clientes identificable, que es exactamente la de tipo Member.
        """
        fecha_ref = datetime.strptime(fecha_referencia, "%Y-%m-%d")
        en_riesgo: List[Tuple[str, str, int]] = []
        universo = [c for c in self.clientes.values() if (c.tipo == "Member" or not solo_member)]

        with open(self.archivo_alertas, "a", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            for cliente in universo:
                if not cliente.fecha_ultima_compra:
                    continue
                dias = (fecha_ref - datetime.strptime(
                    cliente.fecha_ultima_compra, "%Y-%m-%d")).days
                if dias >= umbral_dias:
                    estado = "Cliente en Riesgo de Desercion"
                    writer.writerow([
                        cliente.id_cliente, cliente.nombre, cliente.tipo,
                        cliente.fecha_ultima_compra, dias, estado, fecha_referencia,
                    ])
                    en_riesgo.append((cliente.id_cliente, cliente.nombre, dias))

        print(f"   [CRM]  Consulta automatizada ejecutada ({fecha_referencia}) sobre "
              f"{len(universo)} clientes {'Member' if solo_member else '(Member+Normal)'}: "
              f"{len(en_riesgo)} aislado(s) con alerta de 'Cliente en Riesgo de Desercion' "
              f"(umbral: {umbral_dias} dias).")
        return en_riesgo
