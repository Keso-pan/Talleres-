# -*- coding: utf-8 -*-
"""
main_app.py
Proyecto Final ISID223 - Transformacion Digital Empresarial (MerkaExpress)

Punto de entrada de la aplicacion de escritorio. Ejecutar con:
    python3 main_app.py

Requiere: pandas, matplotlib, y el paquete de sistema python3-tk
(en Ubuntu/Debian: sudo apt-get install python3-tk).
"""

from gui.app import iniciar

if __name__ == "__main__":
    iniciar()
