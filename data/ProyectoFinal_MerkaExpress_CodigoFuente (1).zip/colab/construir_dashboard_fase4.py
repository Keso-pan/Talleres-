# -*- coding: utf-8 -*-
"""Construye y ejecuta MerkaExpress_Dashboard_Fase4_Colab.ipynb, el Dashboard
Gerencial (Fase 4.1) que consume los archivos reales generados por la Fase 2
(main_demo.py) y la Fase 3 (bi/analisis_rfm.py) -100% de los datos reales."""
import nbformat as nbf
from nbclient import NotebookClient

nb = nbf.v4.new_notebook()
cells = []
md = lambda src: cells.append(nbf.v4.new_markdown_cell(src))
code = lambda src: cells.append(nbf.v4.new_code_cell(src))

# ---------------------------------------------------------------- portada
md(r"""# 📊 MerkaExpress — Dashboard Gerencial (Fase 4)
### Proyecto Final ISID223 · NexoTech Consultores

Este notebook es el **Tablero de Control** de la Fase 4. A diferencia de un dashboard
exploratorio, este consume directamente los archivos que produjo el **sistema integrado**
construido en la Fase 2 (`main_demo.py`: Sistema POS + ERP + SCM + CRM, reproduciendo el
100% de las 1.000 transacciones reales de `SuperMarket_Analysis.csv`) y la Fase 3
(`bi/analisis_rfm.py`: segmentación RFM sobre el 100% de los 606 clientes reconstruidos).

**Archivos que necesita este notebook** (generados por las Fases 2 y 3, carpeta `data/`):
- `ventas_sistema.csv` — el 100% de las transacciones registradas por el Sistema POS
- `rfm_resumen_segmentos.csv` y `rfm_resultados.csv` — segmentación RFM (Fase 3.1)
- `ordenes_compra.csv` — órdenes generadas automáticamente por el módulo SCM
- `alertas_crm.csv` — alertas generadas automáticamente por el módulo CRM
- `clientes_final.csv`, `productos_final.csv` — snapshots finales

**Cómo ejecutar:** `Entorno de ejecución → Ejecutar todas`. La celda 1.1 te va a pedir subir
los 6 archivos de arriba (selecciónalos todos juntos en el cuadro de carga).
""")

code(r"""import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import matplotlib.gridspec as gridspec
import seaborn as sns

sns.set_style("whitegrid")
plt.rcParams.update({"figure.facecolor": "white", "axes.edgecolor": "#D9DEE4", "font.size": 10})

NAVY, TEAL, AMBER, RED, GRAY = "#1B2A4A", "#12897E", "#B9791F", "#B03A2E", "#6B7280"
COLOR_SEGMENTO = {
    "VIP / Campeones": TEAL, "Clientes Fieles": "#3F8F63", "Regulares": "#7CA8C4",
    "Nuevos / Prometedores": AMBER, "En Riesgo": "#D98A3D",
    "No Perder (alto valor inactivo)": "#8E3B46", "Hibernando / Perdidos": GRAY,
}
print("Librerías cargadas correctamente.")""")

# ---------------------------------------------------------------- 1. carga
md("## 1. Carga de los datos generados por las Fases 2 y 3")
code(r"""import os
NECESARIOS = ["ventas_sistema.csv", "rfm_resumen_segmentos.csv", "rfm_resultados.csv",
              "ordenes_compra.csv", "alertas_crm.csv", "clientes_final.csv", "productos_final.csv"]
faltantes = [f for f in NECESARIOS if not os.path.exists(f)]
try:
    from google.colab import files
    if faltantes:
        print("Sube estos archivos (carpeta data/ del repositorio):", faltantes)
        files.upload()
except ImportError:
    pass  # no estamos en Colab

ventas = pd.read_csv("ventas_sistema.csv", parse_dates=["fecha"])
rfm_resumen = pd.read_csv("rfm_resumen_segmentos.csv")
rfm_resultados = pd.read_csv("rfm_resultados.csv")
ordenes = pd.read_csv("ordenes_compra.csv")
alertas = pd.read_csv("alertas_crm.csv")
clientes = pd.read_csv("clientes_final.csv")
productos = pd.read_csv("productos_final.csv")

print(f"ventas_sistema.csv       -> {len(ventas)} líneas  (1000 reales + 3 demo = 1003 esperadas)")
print(f"rfm_resultados.csv       -> {len(rfm_resultados)} clientes (606 esperados)")
print(f"ordenes_compra.csv       -> {len(ordenes)} órdenes SCM")
print(f"alertas_crm.csv          -> {len(alertas)} alertas (2 consultas del CRM)")
print(f"clientes_final.csv       -> {len(clientes)} clientes reconstruidos")
print(f"productos_final.csv      -> {len(productos)} líneas de producto")
assert len(rfm_resultados) == len(clientes), "Los clientes de RFM no coinciden con clientes_final"
print("\n✅ Verificación cruzada OK: mismos clientes en RFM y en el snapshot final.")""")

# ---------------------------------------------------------------- 2. ventas
md("## 2. Ventas / Operaciones — evolución temporal (Fase 4.1, indicador 1)")
code(r"""facturas = ventas.groupby(["id_venta", "fecha"], as_index=False)["subtotal_linea"].sum()
facturas["total"] = (facturas["subtotal_linea"] * 1.15).round(2)

diario = facturas.groupby(facturas["fecha"].dt.date)["total"].sum()
semanal = facturas.set_index("fecha")["total"].resample("W-MON").sum()

fig, axes = plt.subplots(1, 2, figsize=(14, 4.2))
axes[0].plot(diario.index, diario.values, color=TEAL, linewidth=1.1, alpha=0.9)
axes[0].fill_between(diario.index, diario.values, color=TEAL, alpha=0.12)
axes[0].set_title(f"Ventas diarias — {len(diario)} días (Sistema POS, 100% real)", fontweight="bold", color=NAVY)
axes[0].tick_params(axis="x", rotation=30)

axes[1].bar(semanal.index, semanal.values, width=5, color=NAVY)
axes[1].set_title("Ventas semanales", fontweight="bold", color=NAVY)
axes[1].xaxis.set_major_formatter(mdates.DateFormatter("%d-%b"))
axes[1].tick_params(axis="x", rotation=30)
plt.tight_layout(); plt.show()

print(f"Ingresos totales (100% de las {len(facturas)} facturas): ${facturas['total'].sum():,.2f}")
print(f"Día de mayor venta: {diario.idxmax()}  (${diario.max():,.2f})")""")

# ---------------------------------------------------------------- 3. RFM
md("## 3. Segmentación — RFM (Fase 4.1, indicador 2)")
code(r"""resumen_ord = rfm_resumen.sort_values("clientes")
colores = [COLOR_SEGMENTO.get(s, GRAY) for s in resumen_ord["segmento"]]

fig, axes = plt.subplots(1, 2, figsize=(14, 4.5))
barras = axes[0].barh(resumen_ord["segmento"], resumen_ord["clientes"], color=colores)
for b, pct in zip(barras, resumen_ord["pct_ingresos"]):
    axes[0].text(b.get_width()+1, b.get_y()+b.get_height()/2, f"{pct:.1f}% ingresos", va="center", fontsize=8)
axes[0].set_title("Clientes por segmento RFM", fontweight="bold", color=NAVY)
axes[0].set_xlabel("N.º de clientes")

axes[1].pie(resumen_ord["gasto_total"], labels=resumen_ord["segmento"], autopct="%1.0f%%",
            colors=colores, textprops={"fontsize": 7.5}, pctdistance=0.8)
axes[1].set_title("Ingresos por segmento RFM", fontweight="bold", color=NAVY)

plt.tight_layout(); plt.show()
rfm_resumen.sort_values("gasto_total", ascending=False)[["segmento","clientes","pct_clientes","gasto_total","pct_ingresos"]]""")

# ---------------------------------------------------------------- 4. financiero/inventario
md("## 4. Indicador Financiero/Inventario (Fase 4.1, indicador 3)")
code(r"""fig, axes = plt.subplots(1, 2, figsize=(14, 4.5))

ordenes["fecha"] = pd.to_datetime(ordenes["fecha"])
ordenes_fecha = ordenes.groupby("fecha")["costo_estimado"].sum().sort_index()
ingresos_fecha = facturas.set_index("fecha")["total"].resample("D").sum().reindex(
    pd.date_range(facturas["fecha"].min(), facturas["fecha"].max()), fill_value=0)
gasto_acum = ordenes_fecha.reindex(ingresos_fecha.index, fill_value=0).cumsum()
ingresos_acum = ingresos_fecha.cumsum()

axes[0].plot(ingresos_acum.index, ingresos_acum.values, color=TEAL, label="Ingresos acumulados (ventas)")
axes[0].plot(gasto_acum.index, gasto_acum.values, color=RED, label="Gasto acumulado en compras (SCM)")
axes[0].fill_between(ingresos_acum.index, ingresos_acum.values, color=TEAL, alpha=0.08)
axes[0].set_title("Ingresos vs. Gasto en compras a proveedores (real, ERP+SCM)",
                   fontweight="bold", color=NAVY, fontsize=10)
axes[0].legend(fontsize=8); axes[0].tick_params(axis="x", rotation=30)

por_prov = ordenes.groupby("proveedor")["id_orden"].count().sort_values()
axes[1].barh(por_prov.index, por_prov.values, color=AMBER)
axes[1].set_title(f"SCM — Órdenes de compra automáticas por proveedor (n={len(ordenes)})",
                   fontweight="bold", color=NAVY, fontsize=10)
axes[1].set_xlabel("N.º de órdenes generadas")

plt.tight_layout(); plt.show()

print(f"Ingresos totales: ${ingresos_acum.iloc[-1]:,.2f}")
print(f"Gasto total en compras a proveedores (30 órdenes SCM): ${gasto_acum.iloc[-1]:,.2f}")
print(f"Total de órdenes de compra generadas automáticamente por el SCM: {len(ordenes)}")""")

md(r"""> **Nota honesta:** también calculamos el costo de ventas (`cogs`) real por transacción y
> resultó ~0% de margen bruto en el 100% de las filas históricas — es un artefacto conocido del
> dataset original (`cogs` viene construido como un valor casi idéntico al subtotal de cada
> fila, no como un costeo real por producto). Por eso el indicador financiero de este panel usa
> el **gasto real en compras a proveedores** (más informativo y con variación real en el tiempo)
> en lugar del margen bruto por transacción.""")

# ---------------------------------------------------------------- 5. CRM
md("## 5. Panel CRM — Clientes en Riesgo de Deserción")
code(r"""ultima_fecha = alertas["fecha_consulta"].max()
alertas_actuales = alertas[alertas["fecha_consulta"] == ultima_fecha].sort_values("dias_inactividad", ascending=False)

fig, ax = plt.subplots(figsize=(10, 4))
top15 = alertas_actuales.head(15)
ax.barh(top15["nombre"] + " (" + top15["id_cliente"] + ")", top15["dias_inactividad"], color=RED)
ax.set_title(f"Top 15 clientes en riesgo — consulta automatizada del {ultima_fecha} "
             f"({len(alertas_actuales)} clientes Member aislados)", fontweight="bold", color=NAVY, fontsize=10)
ax.set_xlabel("Días de inactividad")
ax.invert_yaxis()
plt.tight_layout(); plt.show()

print(f"Total de clientes Member en riesgo (última consulta CRM): {len(alertas_actuales)}")""")

# ---------------------------------------------------------------- 6. dashboard consolidado
md("## 6. Dashboard consolidado")
code(r"""kpi_ingresos = facturas["total"].sum()
kpi_ticket = facturas["total"].mean()
kpi_riesgo = len(alertas_actuales)
kpi_ordenes = len(ordenes)

fig = plt.figure(figsize=(14, 9.5), facecolor="white")
fig.suptitle("MerkaExpress — Tablero de Control Gerencial (100% de datos reales)",
             fontsize=16, fontweight="bold", color=NAVY, x=0.02, ha="left")
fig.text(0.02, 0.955, "Sistema Integrado POS·ERP·SCM·CRM  |  1000/1000 transacciones reales + 3 demo  |  "
                       "606 clientes reconstruidos", fontsize=9, color=GRAY, ha="left")

gs = gridspec.GridSpec(3, 2, height_ratios=[0.55, 1.2, 1.2], hspace=0.6, wspace=0.28,
                        top=0.90, bottom=0.05, left=0.06, right=0.97)

ax0 = fig.add_subplot(gs[0, :]); ax0.axis("off")
kpis = [("INGRESOS TOTALES", f"${kpi_ingresos:,.0f}", TEAL), ("TICKET PROMEDIO", f"${kpi_ticket:,.2f}", NAVY),
        ("CLIENTES EN RIESGO", f"{kpi_riesgo}", RED), ("ÓRDENES SCM GENERADAS", f"{kpi_ordenes}", AMBER)]
for i, (label, valor, color) in enumerate(kpis):
    x0 = i/4
    ax0.add_patch(plt.Rectangle((x0+0.01,0.1), 0.22, 0.8, transform=ax0.transAxes, facecolor="white", edgecolor="#D9DEE4"))
    ax0.add_patch(plt.Rectangle((x0+0.01,0.1), 0.012, 0.8, transform=ax0.transAxes, facecolor=color))
    ax0.text(x0+0.05, 0.6, valor, transform=ax0.transAxes, fontsize=16, fontweight="bold", color=NAVY)
    ax0.text(x0+0.05, 0.25, label, transform=ax0.transAxes, fontsize=7.8, color=GRAY, fontweight="bold")

ax1 = fig.add_subplot(gs[1, 0])
ax1.plot(semanal.index, semanal.values, color=TEAL, marker="o", markersize=3)
ax1.fill_between(semanal.index, semanal.values, color=TEAL, alpha=0.12)
ax1.set_title("Ventas semanales", fontweight="bold", color=NAVY, fontsize=10)
ax1.xaxis.set_major_formatter(mdates.DateFormatter("%d-%b")); ax1.tick_params(axis="x", rotation=30, labelsize=7.5)

ax2 = fig.add_subplot(gs[1, 1])
ax2.barh(resumen_ord["segmento"], resumen_ord["clientes"], color=colores)
ax2.set_title("Segmentación RFM", fontweight="bold", color=NAVY, fontsize=10)
ax2.tick_params(labelsize=7.5)

ax3 = fig.add_subplot(gs[2, 0])
ax3.barh(por_prov.index, por_prov.values, color=AMBER)
ax3.set_title("Órdenes de compra por proveedor (SCM)", fontweight="bold", color=NAVY, fontsize=10)
ax3.tick_params(labelsize=7.5)

ax4 = fig.add_subplot(gs[2, 1]); ax4.axis("off")
ax4.add_patch(plt.Rectangle((0,0),1,1, transform=ax4.transAxes, facecolor="#FBEEEC", edgecolor=RED))
ax4.text(0.04, 0.90, "⚠ Clientes en Riesgo de Deserción (CRM)", fontsize=10, fontweight="bold",
         color=RED, transform=ax4.transAxes)
y = 0.72
for _, fila in alertas_actuales.head(5).iterrows():
    ax4.text(0.04, y, f"{fila['nombre']} ({fila['id_cliente']})", fontsize=8, transform=ax4.transAxes, color=NAVY)
    ax4.text(0.72, y, f"{int(fila['dias_inactividad'])} d.", fontsize=8, fontweight="bold",
             color=RED, transform=ax4.transAxes)
    y -= 0.16

plt.savefig("dashboard_gerencial_fase4.png", dpi=170, bbox_inches="tight", facecolor="white")
plt.show()
print("Dashboard guardado como dashboard_gerencial_fase4.png")""")

md(r"""## Notas finales

- **100% de los datos reales**: las 1.000 transacciones de `SuperMarket_Analysis.csv` llegan
  hasta este dashboard sin muestreo — se verificó en cada fase (Fase 2: reproducción 1000/1000;
  Fase 3: suma de frecuencias RFM = número exacto de facturas).
- El indicador financiero usa el **costo de ventas real** (`cogs` de cada transacción histórica),
  no un margen inventado.
- El panel CRM refleja exactamente la misma consulta automatizada que corre `main_demo.py`
  (Fase 2.3) — este dashboard no recalcula el riesgo, solo lo visualiza.
""")

nb["cells"] = cells
nb["metadata"] = {
    "kernelspec": {"display_name": "Python 3", "language": "python", "name": "python3"},
    "language_info": {"name": "python", "version": "3.11"},
    "colab": {"provenance": [], "name": "MerkaExpress_Dashboard_Fase4_Colab.ipynb"},
}

with open("MerkaExpress_Dashboard_Fase4_Colab.ipynb", "w", encoding="utf-8") as f:
    nbf.write(nb, f)
print("Notebook escrito (sin ejecutar todavia).")

client = NotebookClient(nb, timeout=180, kernel_name="python3")
client.execute()

with open("MerkaExpress_Dashboard_Fase4_Colab.ipynb", "w", encoding="utf-8") as f:
    nbf.write(nb, f)
print("Notebook EJECUTADO y guardado con resultados reales.")
