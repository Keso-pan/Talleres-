# -*- coding: utf-8 -*-
"""
diagramas/generar_diagramas.py
Proyecto Final ISID223 - Transformacion Digital Empresarial (MerkaExpress)

Genera todos los diagramas de diseno tecnico del informe (Fase 1.3):
  - diagrama_er.png            Modelo Entidad-Relacion
  - diagrama_arquitectura.png  Arquitectura de integracion (Observer POS->ERP/SCM/CRM)
  - cadena_valor.png           Cadena de Valor de Porter (propuesta con el SI)
  - mockup_pos.png             Boceto de interfaz: Punto de Venta
  - mockup_dashboard.png       Boceto de interfaz: Dashboard Gerencial
"""

import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Circle, Rectangle
from matplotlib.lines import Line2D

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SALIDA = os.path.dirname(os.path.abspath(__file__))

NAVY = "#1B2A4A"
TEAL = "#12897E"
AMBER = "#B9791F"
RED = "#B03A2E"
GRAY = "#6B7280"
LIGHTGRAY = "#EDEFF2"
WHITE = "#FFFFFF"

plt.rcParams.update({"font.family": "DejaVu Sans"})


# ======================================================================
# 1) DIAGRAMA ENTIDAD-RELACION
# ======================================================================
def caja_entidad(ax, x, y, w, h, titulo, atributos, color, header_h=0.40):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.012,rounding_size=0.06",
                                 linewidth=1.5, edgecolor=color, facecolor=WHITE, zorder=2))
    ax.add_patch(Rectangle((x, y + h - header_h), w, header_h, facecolor=color,
                            edgecolor="none", zorder=3))
    ax.text(x + w / 2, y + h - header_h / 2, titulo, ha="center", va="center",
            fontsize=9.6, fontweight="bold", color="white", zorder=4)
    for i, attr in enumerate(atributos):
        ax.text(x + 0.13, y + h - header_h - 0.24 - i * 0.255, attr, ha="left", va="center",
                fontsize=7.4, color=NAVY, zorder=4, family="monospace")
    return dict(x=x, y=y, w=w, h=h)


def conectar(ax, caja_a, lado_a, caja_b, lado_b, card_a="1", card_b="N", color=GRAY):
    def punto(caja, lado):
        x, y, w, h = caja["x"], caja["y"], caja["w"], caja["h"]
        return {"der": (x + w, y + h / 2), "izq": (x, y + h / 2),
                "sup": (x + w / 2, y + h), "inf": (x + w / 2, y)}[lado]

    pa, pb = punto(caja_a, lado_a), punto(caja_b, lado_b)
    ax.add_patch(FancyArrowPatch(pa, pb, arrowstyle="-", linewidth=1.3, color=color,
                                  connectionstyle="arc3,rad=0.0", zorder=1))
    dx, dy = pb[0] - pa[0], pb[1] - pa[1]
    ax.text(pa[0] + dx * 0.09, pa[1] + dy * 0.09 + 0.12, card_a, fontsize=8.5,
            color=color, fontweight="bold", ha="center")
    ax.text(pa[0] + dx * 0.91, pa[1] + dy * 0.91 + 0.12, card_b, fontsize=8.5,
            color=color, fontweight="bold", ha="center")


def generar_diagrama_er():
    fig, ax = plt.subplots(figsize=(13.5, 8.3))
    ax.set_xlim(0, 13.5)
    ax.set_ylim(0, 8.3)
    ax.axis("off")
    ax.set_title("Modelo Entidad-Relación — MerkaExpress (Sistema Integrado POS·ERP·SCM·CRM)",
                 fontsize=13, fontweight="bold", color=NAVY, loc="left", pad=14)

    cliente = caja_entidad(ax, 0.4, 5.9, 2.9, 2.0, "CLIENTE", [
        "PK id_cliente", "nombre", "tipo (Member/Normal)", "genero",
        "sucursal_registro", "fecha_registro", "fecha_ultima_compra"], NAVY)

    producto = caja_entidad(ax, 0.4, 0.4, 2.9, 2.15, "PRODUCTO", [
        "PK id_producto", "nombre", "linea", "precio_unitario",
        "costo_unitario", "stock_actual", "stock_minimo", "proveedor"], NAVY)

    venta = caja_entidad(ax, 5.05, 4.55, 2.7, 1.55, "VENTA", [
        "PK id_venta", "FK id_cliente", "sucursal", "fecha, hora", "forma_pago"], TEAL)

    detalle = caja_entidad(ax, 5.05, 1.55, 2.7, 1.55, "DETALLE_VENTA", [
        "FK id_venta", "FK id_producto", "cantidad", "precio_unitario"], TEAL)

    asiento = caja_entidad(ax, 9.7, 6.05, 3.3, 1.85, "ASIENTO_CONTABLE  [ERP]", [
        "PK id_asiento", "FK id_venta", "fecha", "cuenta", "debe / haber"], TEAL)

    orden = caja_entidad(ax, 9.7, 3.35, 3.3, 1.85, "ORDEN_COMPRA  [SCM]", [
        "PK id_orden", "FK id_producto", "fecha, proveedor",
        "cantidad_solicitada", "estado"], AMBER)

    alerta = caja_entidad(ax, 9.7, 0.4, 3.3, 1.85, "ALERTA_CRM  [CRM]", [
        "FK id_cliente", "fecha_consulta", "dias_inactividad", "estado_alerta"], RED)

    conectar(ax, cliente, "der", venta, "izq", "1", "N", NAVY)
    conectar(ax, producto, "der", detalle, "izq", "1", "N", NAVY)
    conectar(ax, venta, "inf", detalle, "sup", "1", "N", TEAL)
    conectar(ax, venta, "der", asiento, "izq", "1", "N", TEAL)
    conectar(ax, producto, "der", orden, "izq", "1", "N", AMBER)
    conectar(ax, cliente, "der", alerta, "izq", "1", "N", RED)

    leyenda = [Line2D([0], [0], color=NAVY, lw=2.4, label="Núcleo (Core Business)"),
               Line2D([0], [0], color=TEAL, lw=2.4, label="Módulo ERP"),
               Line2D([0], [0], color=AMBER, lw=2.4, label="Módulo SCM"),
               Line2D([0], [0], color=RED, lw=2.4, label="Módulo CRM")]
    ax.legend(handles=leyenda, loc="lower center", bbox_to_anchor=(0.5, -0.045),
              ncol=4, frameon=False, fontsize=9)

    ruta = os.path.join(SALIDA, "diagrama_er.png")
    fig.savefig(ruta, dpi=200, facecolor="white", bbox_inches="tight")
    plt.close(fig)
    print("Generado:", ruta)


# ======================================================================
# 2) DIAGRAMA DE ARQUITECTURA / INTEGRACION (patron Observer)
# ======================================================================
def caja_modulo(ax, x, y, w, h, titulo, subtitulo, color, icono_txt=""):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.10",
                                 linewidth=0, facecolor=color, zorder=2))
    ax.text(x + w / 2, y + h * 0.62, titulo, ha="center", va="center", fontsize=11.5,
            fontweight="bold", color="white", zorder=3)
    ax.text(x + w / 2, y + h * 0.30, subtitulo, ha="center", va="center", fontsize=8,
            color="white", zorder=3, wrap=True)
    return dict(x=x, y=y, w=w, h=h)


def flecha(ax, p1, p2, color, texto="", curva=0.0, estilo="-|>", lw=1.8, txt_dy=0.18):
    ax.add_patch(FancyArrowPatch(p1, p2, arrowstyle=estilo, linewidth=lw, color=color,
                                  connectionstyle=f"arc3,rad={curva}",
                                  mutation_scale=16, zorder=2))
    if texto:
        mx, my = (p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2
        ax.text(mx, my + txt_dy, texto, fontsize=8, color=color, ha="center",
                fontweight="bold", style="italic")


def generar_diagrama_arquitectura():
    fig, ax = plt.subplots(figsize=(13, 8))
    ax.set_xlim(0, 13)
    ax.set_ylim(0, 8)
    ax.axis("off")
    ax.set_title("Arquitectura de Integración — Patrón Observer (Fase 2.3)",
                 fontsize=13.5, fontweight="bold", color=NAVY, loc="left", pad=16)

    pos = caja_modulo(ax, 0.6, 3.1, 3.0, 1.9, "SISTEMA POS", "Núcleo del negocio\n(Core Business)", NAVY)

    erp = caja_modulo(ax, 6.6, 6.0, 2.9, 1.55, "MÓDULO ERP", "Asientos contables\n+ Caja chica", TEAL)
    scm = caja_modulo(ax, 6.6, 3.25, 2.9, 1.55, "MÓDULO SCM", "Inventario +\nÓrdenes de compra", AMBER)
    crm = caja_modulo(ax, 6.6, 0.5, 2.9, 1.55, "MÓDULO CRM", "Clientes en riesgo\nde deserción", RED)

    dash = caja_modulo(ax, 10.6, 3.1, 2.0, 1.9, "DASHBOARD", "Gerencial\n(Fase 4)", "#3E4C63")

    # Suscripcion (linea punteada) hacia el POS
    for modulo, color in [(erp, TEAL), (scm, AMBER), (crm, RED)]:
        flecha(ax, (pos["x"] + pos["w"], pos["y"] + pos["h"] * 0.85),
               (modulo["x"], modulo["y"] + modulo["h"] / 2), "#B9C0CB",
               estilo="-", lw=1.1, curva=0.08)

    ax.text(pos["x"] + pos["w"] + 0.15, 5.35, "suscribir()\n(observadores)",
            fontsize=7.6, color="#8A93A0", style="italic", ha="left")

    # Notificacion automatica: POS -> modulos (flecha fuerte, evento)
    flecha(ax, (pos["x"] + pos["w"] + 0.05, pos["y"] + pos["h"] * 0.9),
           (erp["x"] - 0.05, erp["y"] + erp["h"] * 0.35), TEAL,
           texto="notificar(venta)", curva=0.18)
    flecha(ax, (pos["x"] + pos["w"] + 0.05, pos["y"] + pos["h"] * 0.5),
           (scm["x"] - 0.05, scm["y"] + scm["h"] * 0.5), AMBER,
           texto="notificar(venta)", curva=0.0)
    flecha(ax, (pos["x"] + pos["w"] + 0.05, pos["y"] + pos["h"] * 0.15),
           (crm["x"] - 0.05, crm["y"] + crm["h"] * 0.75), RED,
           texto="notificar(venta)", curva=-0.20)

    # Modulos -> Dashboard (alimentan datos)
    for modulo, color in [(erp, TEAL), (scm, AMBER), (crm, RED)]:
        flecha(ax, (modulo["x"] + modulo["w"] + 0.05, modulo["y"] + modulo["h"] / 2),
               (dash["x"] - 0.05, dash["y"] + dash["h"] / 2), color, curva=0.0, lw=1.4,
               estilo="-|>")

    ax.annotate("1  Cliente compra\nen el POS", (pos["x"] + pos["w"] / 2, pos["y"] + pos["h"] + 0.15),
                fontsize=8.3, color=NAVY, ha="center", fontweight="bold")
    ax.annotate("2  Notificación automática a\nlos módulos suscritos\n(sin intervención humana)",
                (7.9, 2.55), fontsize=8.3, color=NAVY, ha="center", fontweight="bold")
    ax.annotate("3  Los módulos alimentan\nel tablero gerencial",
                (11.6, 5.35), fontsize=8.3, color=NAVY, ha="center", fontweight="bold")

    ruta = os.path.join(SALIDA, "diagrama_arquitectura.png")
    fig.savefig(ruta, dpi=200, facecolor="white", bbox_inches="tight")
    plt.close(fig)
    print("Generado:", ruta)


# ======================================================================
# 3) CADENA DE VALOR (Porter) - propuesta con el SI
# ======================================================================
def generar_cadena_valor():
    fig, ax = plt.subplots(figsize=(13.5, 7.2))
    ax.set_xlim(0, 13.5)
    ax.set_ylim(0, 7.2)
    ax.axis("off")
    ax.set_title("Cadena de Valor propuesta — MerkaExpress (con el Sistema de Información integrado)",
                 fontsize=13, fontweight="bold", color=NAVY, loc="left", pad=14)

    soporte = [
        ("Infraestructura de la firma", "Tablero gerencial único\n(antes: hojas sueltas por sucursal)"),
        ("Gestión de Talento Humano", "Registro digital de ventas\npor cajero/sucursal"),
        ("Desarrollo Tecnológico", "Sistema POS + ERP + SCM + CRM\nintegrados (Observer)"),
        ("Abastecimiento", "Órdenes de compra automáticas\n(módulo SCM)"),
    ]
    x0, y0, w_total, h_soporte = 0.3, 5.55, 12.9, 1.5
    w_i = w_total / len(soporte)
    for i, (titulo, detalle) in enumerate(soporte):
        x = x0 + i * w_i
        ax.add_patch(Rectangle((x, y0), w_i - 0.08, h_soporte, facecolor="#DCE6EA",
                                edgecolor=NAVY, linewidth=1.0))
        ax.text(x + (w_i - 0.08) / 2, y0 + h_soporte - 0.28, titulo, ha="center", va="top",
                fontsize=8.6, fontweight="bold", color=NAVY, wrap=True)
        ax.text(x + (w_i - 0.08) / 2, y0 + 0.62, detalle, ha="center", va="center",
                fontsize=7.3, color=NAVY)
    ax.text(x0 - 0.05, y0 + h_soporte / 2, "ACTIVIDADES\nDE APOYO", ha="right", va="center",
            fontsize=8.5, fontweight="bold", color=GRAY, rotation=90)

    primarias = [
        ("Logística Interna", "Stock en tiempo real\npor sucursal", NAVY),
        ("Operaciones", "Venta registrada en\nSistema POS (Fase 2.1)", TEAL),
        ("Logística Externa", "Reposición automática\nde góndolas (SCM)", AMBER),
        ("Marketing y Ventas", "Promociones dirigidas por\nsegmento RFM (Fase 3.1)", "#8E5DB0"),
        ("Servicio Postventa", "Alertas CRM: clientes\nen riesgo de deserción", RED),
    ]
    y0p, h_p = 1.1, 3.6
    w_p = w_total / len(primarias)
    for i, (titulo, detalle, color) in enumerate(primarias):
        x = x0 + i * w_p
        punta = w_p * 0.22 if i < len(primarias) - 1 else 0
        pts = [(x, y0p), (x + w_p - 0.10 - punta, y0p),
               (x + w_p - 0.10, y0p + h_p / 2), (x + w_p - 0.10 - punta, y0p + h_p),
               (x, y0p + h_p)]
        if i > 0:
            pts = [(x + punta * 0, y0p)] + pts
        poly = plt.Polygon(pts, closed=True, facecolor=color, edgecolor="white", linewidth=1.2)
        ax.add_patch(poly)
        ax.text(x + w_p * 0.36, y0p + h_p * 0.68, titulo, ha="center", va="center",
                fontsize=9.2, fontweight="bold", color="white")
        ax.text(x + w_p * 0.36, y0p + h_p * 0.34, detalle, ha="center", va="center",
                fontsize=7.4, color="white")

    ax.annotate("MARGEN", (x0 + w_total - 0.35, y0p + h_p / 2), fontsize=10, fontweight="bold",
                color=NAVY, ha="center", rotation=-90)
    ax.text(x0 - 0.05, y0p + h_p / 2, "ACTIVIDADES\nPRIMARIAS", ha="right", va="center",
            fontsize=8.5, fontweight="bold", color=GRAY, rotation=90)

    ax.text(x0, 0.35, "El SI agrega valor directo en Operaciones (digitalización del core), Logística "
                      "Externa y Abastecimiento (automatización SCM), Marketing (segmentación RFM) y "
                      "Servicio (alertas CRM proactivas).", fontsize=8.4, color=GRAY, ha="left", style="italic")

    ruta = os.path.join(SALIDA, "cadena_valor.png")
    fig.savefig(ruta, dpi=200, facecolor="white", bbox_inches="tight")
    plt.close(fig)
    print("Generado:", ruta)


# ======================================================================
# 4) MOCKUPS DE INTERFAZ (bocetos de baja fidelidad)
# ======================================================================
WF_LINE = "#9AA3AF"
WF_BOX = "#CBD2D9"
WF_BG = "#F7F8FA"
WF_DARK = "#3D4652"


def _barra_texto(ax, x, y, w, h=0.11, color=WF_BOX):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.006,rounding_size=0.03",
                                 linewidth=0, facecolor=color, zorder=3))


def _placeholder_img(ax, x, y, w, h, color=WF_BOX):
    ax.add_patch(Rectangle((x, y), w, h, facecolor="white", edgecolor=color, linewidth=1.2, zorder=3))
    ax.plot([x, x + w], [y, y + h], color=color, linewidth=1.0, zorder=3)
    ax.plot([x, x + w], [y + h, y], color=color, linewidth=1.0, zorder=3)


def _boton(ax, x, y, w, h, texto, color=NAVY, txt_color="white"):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.006,rounding_size=0.04",
                                 linewidth=0, facecolor=color, zorder=4))
    ax.text(x + w / 2, y + h / 2, texto, ha="center", va="center", fontsize=7.6,
            color=txt_color, fontweight="bold", zorder=5)


def _marco_pantalla(ax, x, y, w, h, titulo):
    ax.add_patch(Rectangle((x, y), w, h, facecolor=WF_BG, edgecolor=WF_DARK, linewidth=1.6, zorder=1))
    ax.add_patch(Rectangle((x, y + h - 0.42), w, 0.42, facecolor=WF_DARK, edgecolor="none", zorder=2))
    for i, c in enumerate(["#E8635C", "#E8B95C", "#5CBE6E"]):
        ax.add_patch(Circle((x + 0.22 + i * 0.22, y + h - 0.21), 0.06, facecolor=c,
                             edgecolor="none", zorder=3))
    ax.text(x + w / 2, y + h - 0.21, titulo, ha="center", va="center", fontsize=9,
            color="white", fontweight="bold", zorder=3)


def generar_mockup_pos():
    fig, ax = plt.subplots(figsize=(12.5, 7.6))
    ax.set_xlim(0, 12.5)
    ax.set_ylim(0, 7.6)
    ax.axis("off")
    ax.set_title("Boceto de interfaz — Sistema POS (Punto de Venta)", fontsize=12.5,
                 fontweight="bold", color=NAVY, loc="left", pad=10)

    _marco_pantalla(ax, 0.3, 0.3, 11.9, 6.9, "MerkaExpress · Sucursal: Alex (Yangon) ▾      Cajero: 001      "
                                              "2026-07-05  11:15")

    # ---- Panel izquierdo: catalogo / busqueda ----
    ax.text(0.65, 6.55, "Buscar producto", fontsize=8, color=WF_DARK, fontweight="bold")
    _barra_texto(ax, 0.65, 6.28, 4.9, 0.24, WF_BOX)
    ax.text(0.9, 6.38, "Buscar:  cafe, bebidas, aseo...", fontsize=7, color="#8A93A0", zorder=5)

    lineas_prod = ["Todos", "Alimentos", "Belleza", "Electrónica", "Hogar", "Deporte", "Moda"]
    xc = 0.65
    for chip in lineas_prod:
        w = 0.28 + len(chip) * 0.075
        _boton(ax, xc, 5.85, w, 0.26, chip, color="#E3E7EC" if chip != "Todos" else TEAL,
               txt_color=WF_DARK if chip != "Todos" else "white")
        xc += w + 0.12

    filas, cols = 3, 4
    cw, ch = 1.24, 1.28
    x0, y0 = 0.65, 2.0
    nombres_demo = ["Café Molido", "Aceite Oliva", "Shampoo", "Audífonos",
                     "Power Bank", "Bufanda", "Mat Yoga", "Vela Aromát.",
                     "Snack Mix", "Gafas Sol", "Organizador", "Botella Térm."]
    precios_demo = ["$8.90", "$11.90", "$12.50", "$45.00", "$29.90", "$17.90",
                     "$21.90", "$9.90", "$4.50", "$26.90", "$14.90", "$16.90"]
    k = 0
    for r in range(filas):
        for c in range(cols):
            x = x0 + c * (cw + 0.12)
            y = y0 + (filas - 1 - r) * (ch + 0.12)
            ax.add_patch(FancyBboxPatch((x, y), cw, ch, boxstyle="round,pad=0.006,rounding_size=0.05",
                                         linewidth=1.0, edgecolor=WF_BOX, facecolor="white", zorder=3))
            _placeholder_img(ax, x + 0.12, y + 0.48, cw - 0.24, ch - 0.62)
            ax.text(x + cw / 2, y + 0.30, nombres_demo[k], ha="center", fontsize=6.6, color=WF_DARK, zorder=5)
            ax.text(x + cw / 2, y + 0.12, precios_demo[k], ha="center", fontsize=6.8, color=TEAL,
                    fontweight="bold", zorder=5)
            k += 1

    # ---- Panel derecho: carrito ----
    px, pw = 5.95, 5.95
    ax.add_patch(Rectangle((px, 0.65), pw, 5.85, facecolor="white", edgecolor=WF_BOX, linewidth=1.2, zorder=2))
    ax.text(px + 0.25, 6.20, "Carrito de compra", fontsize=9, fontweight="bold", color=NAVY, zorder=3)

    ax.text(px + 0.25, 5.85, "Cliente:", fontsize=7.4, color=WF_DARK, zorder=3)
    _barra_texto(ax, px + 1.05, 5.78, pw - 1.35, 0.22, "#E3E7EC")
    ax.text(px + 1.2, 5.87, "CL-0002 · Christian Vargas", fontsize=6.8, color=WF_DARK, zorder=5)

    items = [("Café Molido Premium 500g", "x3", "$26.70"), ("Cargador Rápido USB-C", "x2", "$39.80")]
    y = 5.35
    for nombre, cant, monto in items:
        ax.text(px + 0.25, y, nombre, fontsize=7.2, color=WF_DARK, zorder=3)
        ax.text(px + pw - 1.25, y, cant, fontsize=7.2, color="#8A93A0", zorder=3)
        ax.text(px + pw - 0.85, y, monto, fontsize=7.2, color=WF_DARK, fontweight="bold", zorder=3, ha="left")
        ax.plot([px + 0.2, px + pw - 0.2], [y - 0.13, y - 0.13], color="#EEF0F3", linewidth=1, zorder=2)
        y -= 0.42

    ax.plot([px + 0.2, px + pw - 0.2], [3.55, 3.55], color=WF_BOX, linewidth=1.1, zorder=3)
    for etiqueta, valor, y_ in [("Subtotal", "$66.50", 3.28), ("Impuesto (5%)", "$3.33", 3.00)]:
        ax.text(px + 0.25, y_, etiqueta, fontsize=7.6, color=WF_DARK, zorder=3)
        ax.text(px + pw - 0.9, y_, valor, fontsize=7.6, color=WF_DARK, zorder=3)
    ax.text(px + 0.25, 2.62, "TOTAL", fontsize=10, fontweight="bold", color=NAVY, zorder=3)
    ax.text(px + pw - 1.05, 2.62, "$69.83", fontsize=10, fontweight="bold", color=TEAL, zorder=3)

    ax.text(px + 0.25, 2.18, "Forma de pago:", fontsize=7.4, color=WF_DARK, zorder=3)
    for i, (fp, activo) in enumerate([("Efectivo", False), ("Tarjeta", True), ("Billetera", False)]):
        _boton(ax, px + 0.25 + i * 1.85, 1.75, 1.7, 0.32, fp,
               color=TEAL if activo else "#E3E7EC", txt_color="white" if activo else WF_DARK)

    _boton(ax, px + 0.25, 0.95, pw - 0.5, 0.55, "COBRAR VENTA  →", color=AMBER)

    ruta = os.path.join(SALIDA, "mockup_pos.png")
    fig.savefig(ruta, dpi=200, facecolor="white", bbox_inches="tight")
    plt.close(fig)
    print("Generado:", ruta)


def generar_mockup_dashboard():
    fig, ax = plt.subplots(figsize=(12.5, 7.6))
    ax.set_xlim(0, 12.5)
    ax.set_ylim(0, 7.6)
    ax.axis("off")
    ax.set_title("Boceto de interfaz — Dashboard Gerencial", fontsize=12.5,
                 fontweight="bold", color=NAVY, loc="left", pad=10)

    _marco_pantalla(ax, 0.3, 0.3, 11.9, 6.9, "MerkaExpress · Panel Gerencial      "
                                              "Periodo: Mar–Jun 2026 ▾")

    kpis = ["Ingresos\ntotales", "Ticket\npromedio", "Clientes\nactivos", "Clientes\nen riesgo"]
    kx, ky, kw, kh = 0.6, 6.0, 2.78, 0.72
    for i, k in enumerate(kpis):
        x = kx + i * (kw + 0.12)
        ax.add_patch(FancyBboxPatch((x, ky), kw, kh, boxstyle="round,pad=0.006,rounding_size=0.05",
                                     linewidth=1.0, edgecolor=WF_BOX, facecolor="white", zorder=3))
        _barra_texto(ax, x + 0.15, ky + 0.42, 1.0, 0.16, TEAL if i < 3 else RED)
        ax.text(x + 0.15, ky + 0.14, k.replace("\n", " "), fontsize=6.6, color=WF_DARK, zorder=4)

    ax.add_patch(Rectangle((0.6, 3.1), 7.1, 2.65, facecolor="white", edgecolor=WF_BOX, linewidth=1.1, zorder=2))
    ax.text(0.85, 5.5, "Evolución de ventas (semanal)", fontsize=8, fontweight="bold", color=NAVY, zorder=3)
    xs = [0.95 + i * 0.62 for i in range(11)]
    ys = [3.5, 3.7, 3.6, 3.9, 4.1, 3.95, 4.3, 4.6, 4.4, 4.9, 5.1]
    ax.plot(xs, ys, color=TEAL, linewidth=1.8, marker="o", markersize=3, zorder=3)
    ax.fill_between(xs, ys, 3.25, color=TEAL, alpha=0.12, zorder=2)
    ax.plot([0.85, 7.5], [3.25, 3.25], color=WF_BOX, linewidth=1, zorder=3)

    ax.add_patch(Rectangle((7.95, 3.1), 3.85, 2.65, facecolor="white", edgecolor=WF_BOX, linewidth=1.1, zorder=2))
    ax.text(8.2, 5.5, "Segmentación RFM", fontsize=8, fontweight="bold", color=NAVY, zorder=3)
    segs = [("VIP", TEAL, 0.85), ("Fieles", "#3F8F63", 0.55), ("Regulares", "#7CA8C4", 0.45),
            ("En riesgo", AMBER, 0.35), ("Hibernando", GRAY, 0.30)]
    yb = 5.15
    for nombre, color, frac in segs:
        ax.text(8.2, yb, nombre, fontsize=6.6, color=WF_DARK, zorder=3)
        ax.add_patch(Rectangle((9.15, yb - 0.03), 2.35 * frac, 0.16, facecolor=color,
                                edgecolor="none", zorder=3))
        yb -= 0.40

    ax.add_patch(Rectangle((0.6, 0.65), 11.2, 2.15, facecolor="#FBEEEC", edgecolor=RED, linewidth=1.2, zorder=2))
    ax.text(0.85, 2.5, "Clientes en Riesgo de Deserción  (CRM — consulta automatizada)", fontsize=8.3,
            fontweight="bold", color=RED, zorder=3)
    filas_demo = [("Christian Vargas", "CL-0002", "82 días"), ("Domenica Mendoza", "CL-0003", "116 días"),
                  ("Kevin Guamán", "CL-0007", "64 días")]
    yy = 2.10
    for nombre, cid, dias in filas_demo:
        ax.text(0.95, yy, f"{nombre}  ({cid})", fontsize=7.2, color=WF_DARK, zorder=3)
        ax.text(9.6, yy, dias, fontsize=7.2, color=RED, fontweight="bold", zorder=3)
        yy -= 0.42

    ruta = os.path.join(SALIDA, "mockup_dashboard.png")
    fig.savefig(ruta, dpi=200, facecolor="white", bbox_inches="tight")
    plt.close(fig)
    print("Generado:", ruta)


if __name__ == "__main__":
    generar_diagrama_er()
    generar_diagrama_arquitectura()
    generar_cadena_valor()
    generar_mockup_pos()
    generar_mockup_dashboard()
