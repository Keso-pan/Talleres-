# -*- coding: utf-8 -*-
"""
core/sistema_pos.py
Proyecto Final ISID223 - Transformacion Digital Empresarial (MerkaExpress)

Sistema Principal (Core Business) - Punto de Venta.

Implementa el patron de diseno OBSERVER: el SistemaPOS es el "Sujeto" y los
modulos ERP, SCM y CRM son "Observadores" que se suscriben una sola vez.
Cada vez que se registra una venta, el sistema notifica automaticamente a
todos los observadores SIN INTERVENCION HUMANA. Esta es la evidencia de
integracion exigida en la Fase 2.3 del proyecto: una accion en el Sistema A
(POS) dispara consecuencias automaticas en los Sistemas B (ERP, SCM, CRM).
"""

import csv
import os
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Dict, List, Tuple

from core.modelos import Cliente, Producto, Venta, DetalleVenta


class ObservadorVenta(ABC):
    """Interfaz (contrato) que deben cumplir los modulos ERP, SCM y CRM."""

    @abstractmethod
    def actualizar(self, venta: Venta) -> None:
        """Metodo invocado automaticamente por el SistemaPOS tras cada venta."""
        raise NotImplementedError


class SistemaPOS:
    """
    Sistema principal de ventas (Core Business).
    Gestiona clientes, catalogo de productos, registro de transacciones,
    persistencia en CSV y notificacion automatica a modulos suscritos.
    """

    def __init__(self, ruta_datos: str = "data"):
        self.ruta_datos = ruta_datos
        self.clientes: Dict[str, Cliente] = {}
        self.productos: Dict[str, Producto] = {}
        self._observadores: List[ObservadorVenta] = []
        self._contador_ventas = 0
        os.makedirs(ruta_datos, exist_ok=True)
        self.archivo_ventas = os.path.join(ruta_datos, "ventas_sistema.csv")
        self._inicializar_archivo_ventas()

    # ---------- Patron Observer ----------
    def suscribir(self, observador: ObservadorVenta) -> None:
        """Registra un modulo (ERP, SCM, CRM) para ser notificado de cada venta."""
        self._observadores.append(observador)

    def _notificar_observadores(self, venta: Venta) -> None:
        for observador in self._observadores:
            observador.actualizar(venta)

    # ---------- Carga de datos maestros ----------
    def cargar_clientes(self, clientes: List[Cliente]) -> None:
        for c in clientes:
            self.clientes[c.id_cliente] = c

    def cargar_productos(self, productos: List[Producto]) -> None:
        for p in productos:
            self.productos[p.id_producto] = p

    # ---------- Persistencia (Fase 2.1: persistencia en CSV) ----------
    def _inicializar_archivo_ventas(self) -> None:
        # Se sobrescribe SIEMPRE al crear el SistemaPOS (misma politica que
        # ERP/SCM/CRM): cada arranque de la aplicacion reproduce el 100% del
        # historico real desde cero, para evitar duplicar filas entre
        # ejecuciones sucesivas.
        with open(self.archivo_ventas, "w", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow([
                "id_venta", "id_cliente", "sucursal", "fecha", "hora",
                "forma_pago", "id_producto", "nombre_producto",
                "cantidad", "precio_unitario", "subtotal_linea", "costo_linea",
            ])

    def _persistir_venta(self, venta: Venta) -> None:
        with open(self.archivo_ventas, "a", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            for d in venta.detalles:
                writer.writerow([
                    venta.id_venta, venta.id_cliente, venta.sucursal,
                    venta.fecha, venta.hora, venta.forma_pago,
                    d.id_producto, d.nombre_producto, d.cantidad,
                    d.precio_unitario, d.subtotal, d.costo_total_linea,
                ])

    # ---------- Logica principal del negocio ----------
    def registrar_venta(
        self,
        id_cliente: str,
        sucursal: str,
        forma_pago: str,
        carrito: List[Tuple],
        fecha: str = None,
        hora: str = None,
        modo_historico: bool = False,
    ) -> Venta:
        """
        Registra una nueva venta.
        carrito: lista de tuplas (id_producto, cantidad) o
                 (id_producto, cantidad, precio_unitario_real, costo_total_linea_real).
                 Las dos ultimas son opcionales: si no se pasan, se usa el precio de
                 lista del catalogo y costo 0.0 (uso: ventas nuevas via POS). Si se
                 pasan (uso: reproducir una transaccion real del historico), se
                 respeta el precio y costo exactos de esa transaccion.

        modo_historico=True: la venta es la REPRODUCCION de una transaccion que
        ya ocurrio de verdad (esta en el CSV historico). El stock inicial del
        catalogo es una estimacion nuestra, no un dato real -> no es correcto
        "rechazar" un hecho historico documentado por un supuesto de inventario
        nuestro. En este modo el stock puede quedar en negativo (senal de que
        el supuesto de stock inicial se quedo corto) pero la venta SIEMPRE se
        registra completa, y el SCM igual dispara su orden de compra.
        modo_historico=False (default, ventas nuevas/futuras): si no hay stock
        suficiente, la linea se omite -> asi se comporta un POS real.

        Al finalizar, dispara la notificacion automatica a ERP, SCM y CRM.
        """
        self._contador_ventas += 1
        id_venta = f"V-{self._contador_ventas:06d}"
        fecha = fecha or datetime.now().strftime("%Y-%m-%d")
        hora = hora or datetime.now().strftime("%H:%M:%S")

        detalles = []
        for item in carrito:
            id_producto, cantidad = item[0], item[1]
            precio_real = item[2] if len(item) > 2 else None
            costo_real = item[3] if len(item) > 3 else 0.0

            producto = self.productos.get(id_producto)
            if producto is None:
                raise ValueError(f"Producto '{id_producto}' no existe en el catalogo.")
            if producto.stock_actual < cantidad and not modo_historico:
                continue  # solo se omite en modo "venta nueva"; en modo historico, no
            producto.stock_actual -= cantidad
            detalles.append(DetalleVenta(
                id_producto=producto.id_producto,
                nombre_producto=producto.nombre,
                cantidad=cantidad,
                precio_unitario=precio_real if precio_real is not None else producto.precio_unitario,
                costo_total_linea=costo_real,
            ))

        if not detalles:
            raise ValueError("La venta no tiene lineas validas (sin stock disponible).")

        venta = Venta(
            id_venta=id_venta, id_cliente=id_cliente, sucursal=sucursal,
            fecha=fecha, hora=hora, forma_pago=forma_pago, detalles=detalles,
        )
        self._persistir_venta(venta)

        if id_cliente in self.clientes:
            self.clientes[id_cliente].actualizar_ultima_compra(fecha)

        # ---- INTEGRACION AUTOMATICA (Fase 2.3) ----
        self._notificar_observadores(venta)

        return venta
