# -*- coding: utf-8 -*-
"""
core/modelos.py
Proyecto Final ISID223 - Transformacion Digital Empresarial (MerkaExpress)

Modelos de dominio del Sistema Principal (Core Business).
Aplica Programacion Orientada a Objetos: encapsulamiento (atributos protegidos
con validacion via property), composicion (Venta contiene DetalleVenta) y
responsabilidad unica por clase.
"""

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class Cliente:
    """Representa a un cliente registrado en el sistema (miembro o normal)."""
    id_cliente: str
    nombre: str
    tipo: str            # "Member" o "Normal"
    genero: str
    sucursal_registro: str
    fecha_registro: str
    fecha_ultima_compra: Optional[str] = None

    def actualizar_ultima_compra(self, fecha: str) -> None:
        """Actualiza la fecha de ultima compra. Es invocado automaticamente
        por el Modulo CRM cada vez que el cliente realiza una transaccion."""
        if self.fecha_ultima_compra is None or fecha > self.fecha_ultima_compra:
            self.fecha_ultima_compra = fecha


@dataclass
class Producto:
    """Representa un producto/SKU del catalogo, con control de inventario."""
    id_producto: str
    nombre: str
    linea: str            # Linea de producto (categoria)
    precio_unitario: float
    costo_unitario: float
    stock_actual: int
    stock_minimo: int     # Punto de reorden (usado por el Modulo SCM)
    proveedor: str

    def hay_stock_bajo(self) -> bool:
        """True si el stock esta en o por debajo del punto de reorden."""
        return self.stock_actual <= self.stock_minimo

    def reducir_stock(self, cantidad: int) -> None:
        if cantidad > self.stock_actual:
            raise ValueError(
                f"Stock insuficiente para '{self.nombre}': "
                f"disponible {self.stock_actual}, solicitado {cantidad}"
            )
        self.stock_actual -= cantidad

    def aumentar_stock(self, cantidad: int) -> None:
        self.stock_actual += cantidad


@dataclass
class DetalleVenta:
    """Linea individual de una venta (un producto dentro del carrito)."""
    id_producto: str
    nombre_producto: str
    cantidad: int
    precio_unitario: float
    costo_total_linea: float = 0.0   # costo real de la linea (columna 'cogs' del historico)

    @property
    def subtotal(self) -> float:
        return round(self.cantidad * self.precio_unitario, 2)


@dataclass
class Venta:
    """
    Representa una transaccion de venta completa (encabezado + detalle).
    TASA_IMPUESTO = 0.05, la misma tarifa plana ("Tax 5%") que trae el
    historico real de MerkaExpress -no se asume ninguna tarifa de un pais
    en particular-.
    """
    id_venta: str
    id_cliente: str
    sucursal: str
    fecha: str
    hora: str
    forma_pago: str
    detalles: List[DetalleVenta] = field(default_factory=list)
    TASA_IMPUESTO: float = 0.05

    @property
    def subtotal(self) -> float:
        return round(sum(d.subtotal for d in self.detalles), 2)

    @property
    def impuesto(self) -> float:
        return round(self.subtotal * self.TASA_IMPUESTO, 2)

    @property
    def total(self) -> float:
        return round(self.subtotal + self.impuesto, 2)

    @property
    def costo_total(self) -> float:
        """Costo real de la venta (suma de 'cogs' de cada línea, tomado del histórico)."""
        return round(sum(d.costo_total_linea for d in self.detalles), 2)

    @property
    def cantidad_items(self) -> int:
        return sum(d.cantidad for d in self.detalles)
