# -*- coding: utf-8 -*-
"""
main_demo.py
Proyecto Final ISID223 - Transformacion Digital Empresarial
Cliente simulado: MerkaExpress (cadena de minimercados - Alex/Yangon, Cairo/Mandalay, Giza/Naypyitaw)
Firma consultora: NexoTech Consultores (EPN)

IMPORTANTE: este script reproduce el 100% de las 1.000 transacciones REALES de
data/SuperMarket_Analysis.csv a traves del nuevo Sistema POS, en el orden
cronologico exacto (fecha+hora reales), con el precio y costo reales de cada
transaccion. No se genera ninguna venta sintetica. La unica reconstruccion
necesaria es el id_cliente (el archivo no trae uno -> ver datos_maestros.py
para la metodologia, ya validada, de reconstruccion de pseudo-clientes).

Estructura:
  FASE A - Carga del 100% del CSV historico (con verificacion)
  FASE B - Catalogo (6 lineas reales) + reconstruccion de clientes
  FASE C - Suscripcion de ERP/SCM/CRM al Sistema POS (Observer)
  FASE D - Reproduccion cronologica de las 1000 transacciones reales
  FASE E - Primera consulta automatizada del CRM (clientes en riesgo)
  FASE F - Escenario de demostracion en vivo (transacciones adicionales,
           ya que las 1000 reales se agotaron en la FASE D)
  FASE G - Segunda consulta del CRM: se confirma el cierre del ciclo
  FASE H - Persistencia de snapshots finales + resumen ejecutivo
"""

import csv
import os
import random

import pandas as pd

from core.sistema_pos import SistemaPOS
from modulos.modulo_erp import ModuloERP
from modulos.modulo_scm import ModuloSCM
from modulos.modulo_crm import ModuloCRM
from datos_maestros import (
    crear_catalogo_productos, reconstruir_clientes, preparar_eventos_reales, MAPA_SUCURSAL,
)

RUTA_DATOS = "data"
RUTA_CSV_HISTORICO = os.path.join(RUTA_DATOS, "SuperMarket_Analysis.csv")
LEAD_TIME_PROVEEDOR = 6
SEED = 42


def linea(char="-", n=78):
    print(char * n)


def main():
    random.seed(SEED)
    rnd = random.Random(SEED)

    print()
    linea("=")
    print(" PROYECTO FINAL ISID223 | MerkaExpress - Reproduccion del 100% de datos reales")
    linea("=")

    # ---------------- FASE A: Carga del 100% del historico ----------------
    df = pd.read_csv(RUTA_CSV_HISTORICO, encoding="utf-8-sig")
    df["Date"] = pd.to_datetime(df["Date"])
    assert len(df) == 1000, f"Se esperaban 1000 filas reales, se cargaron {len(df)}"
    print(f"\n[FASE A] {len(df)} transacciones reales cargadas -> 100% del archivo, sin muestreo.")
    print(f"[FASE A] Periodo real: {df['Date'].min().date()} a {df['Date'].max().date()}")
    print(f"[FASE A] Ventas totales reales: ${df['Sales'].sum():,.2f}  (verificable contra el CSV original)")

    # ---------------- FASE B: Catalogo + reconstruccion de clientes ----------------
    productos, mapa_id_por_linea = crear_catalogo_productos(df)
    clientes, ids_por_fila, perfil_cliente = reconstruir_clientes(df, seed=SEED)
    eventos = preparar_eventos_reales(df, ids_por_fila, mapa_id_por_linea)

    n_member = sum(1 for p in perfil_cliente.values() if p.startswith("Member"))
    n_normal = sum(1 for p in perfil_cliente.values() if p.startswith("Normal"))
    print(f"\n[FASE B] Catalogo: {len(productos)} productos (una por cada linea real del CSV).")
    print(f"[FASE B] Clientes reconstruidos: {len(clientes)}  "
          f"({n_member} pseudo-clientes Member a partir de {(df['Customer type']=='Member').sum()} filas, "
          f"{n_normal} clientes Normal a partir de {(df['Customer type']=='Normal').sum()} filas)")
    print(f"[FASE B] Eventos preparados para reproducir: {len(eventos)}  (debe ser 1000)")

    # ---------------- FASE C: Sistema POS + suscripcion Observer ----------------
    sistema = SistemaPOS(ruta_datos=RUTA_DATOS)
    sistema.cargar_clientes(list(clientes.values()))
    sistema.cargar_productos(list(productos.values()))

    erp = ModuloERP(ruta_datos=RUTA_DATOS, saldo_inicial_caja=5000.0)
    scm = ModuloSCM(catalogo_productos=productos, ruta_datos=RUTA_DATOS, cantidad_reorden=180)
    crm = ModuloCRM(catalogo_clientes=clientes, ruta_datos=RUTA_DATOS)

    sistema.suscribir(erp)
    sistema.suscribir(scm)
    sistema.suscribir(crm)
    print("\n[FASE C] Modulos ERP, SCM y CRM suscritos al Sistema POS (patron Observer).")

    # ---------------- FASE D: Reproduccion cronologica del 100% de datos reales ----------------
    erp.verbose = False
    scm.verbose = False

    ventas_ok, ventas_perdidas = 0, 0
    for ev in eventos:
        try:
            sistema.registrar_venta(
                id_cliente=ev["id_cliente"], sucursal=ev["sucursal"], forma_pago=ev["forma_pago"],
                carrito=ev["carrito"], fecha=ev["fecha"], hora=ev["hora"], modo_historico=True,
            )
            ventas_ok += 1
        except ValueError:
            ventas_perdidas += 1

        for pid in scm.ordenes_listas_para_recibir(ev["fecha"], LEAD_TIME_PROVEEDOR):
            scm.recibir_pedido(pid)

    print(f"\n[FASE D] Reproduccion completada: {ventas_ok} de {len(eventos)} transacciones reales "
          f"registradas exitosamente ({ventas_ok/len(eventos)*100:.1f}%).")
    if ventas_perdidas:
        print(f"[FASE D] AVISO: {ventas_perdidas} filas no se pudieron registrar (revisar catalogo).")
    else:
        print(f"[FASE D] Las 1000 filas reales quedaron registradas -> ninguna transaccion historica "
              f"fue descartada por supuestos de inventario (modo_historico=True).")
    n_negativos = sum(1 for p in productos.values() if p.stock_actual < 0)
    print(f"[FASE D] Productos cuyo stock estimado quedo en negativo: {n_negativos} de {len(productos)} "
          f"(senal de que la demanda real supero el supuesto de stock inicial -> el SCM habria "
          f"reordenado igual; el numero negativo solo indica que, ademas, convendria subir ese "
          f"stock inicial en una siguiente iteracion).")
    print(f"[FASE D] Asientos contables generados automaticamente por ERP: {erp._contador_asientos}")
    print(f"[FASE D] Ordenes de compra generadas automaticamente por SCM: {scm._contador_ordenes}")
    print(f"[FASE D] Saldo final de caja chica: ${erp.saldo_caja:,.2f}")

    # ---------------- FASE E: Primera consulta automatizada del CRM ----------------
    fecha_ref_1 = df["Date"].max().strftime("%Y-%m-%d")
    print(f"\n[FASE E] Ejecutando consulta automatizada de clientes en riesgo (corte {fecha_ref_1})...")
    en_riesgo = crm.detectar_clientes_en_riesgo(fecha_referencia=fecha_ref_1, umbral_dias=30)

    cliente_reactivar = en_riesgo[0] if en_riesgo else None

    # ---------------- FASE F: ESCENARIO DE DEMOSTRACION EN VIVO ----------------
    # Las 1000 transacciones reales ya se agotaron en la FASE D. Para demostrar
    # la integracion "en vivo" (como se haria en la sustentacion) se registran
    # unas pocas transacciones ILUSTRATIVAS ADICIONALES, con fecha posterior al
    # ultimo dato real (2019-03-30) -> claramente distinguibles del historico.
    print()
    linea("=")
    print(" FASE F | ESCENARIO DE DEMOSTRACION EN VIVO (transacciones adicionales, para sustentacion)")
    print(" Las 1000 transacciones reales ya fueron reproducidas en la FASE D.")
    linea("=")
    erp.verbose = True
    scm.verbose = True

    fecha_demo = "2019-03-31"  # un dia despues del ultimo dato real

    id_cliente_demo = eventos[-1]["id_cliente"]
    print(f"\n(E1) Cliente registra una venta normal en Sucursal {MAPA_SUCURSAL['Alex']} ({fecha_demo}):")
    p_seguro = max(productos.values(), key=lambda p: p.stock_actual)
    venta_1 = sistema.registrar_venta(
        id_cliente=id_cliente_demo, sucursal=MAPA_SUCURSAL["Alex"], forma_pago="Tarjeta de Credito",
        carrito=[(p_seguro.id_producto, 3, p_seguro.precio_unitario, round(p_seguro.costo_unitario*3, 2))],
        fecha=fecha_demo, hora="11:15:00",
    )
    print(f"   [POS]  Venta {venta_1.id_venta} registrada | Subtotal ${venta_1.subtotal} "
          f"+ Impuesto ${venta_1.impuesto} = Total ${venta_1.total}")
    print("          -> ERP registro el asiento y actualizo caja chica arriba, de forma")
    print("             AUTOMATICA, sin que nadie ejecute una accion adicional.")

    print(f"\n(E2) Se agota el margen de stock del producto mas cercano a su punto de reorden:")
    candidatos = [p for p in productos.values() if p.id_producto not in scm._ordenes_pendientes]
    p_critico = min(candidatos, key=lambda p: p.stock_actual - p.stock_minimo)
    stock_previo = p_critico.stock_actual
    cantidad_venta = min(stock_previo, max(stock_previo - p_critico.stock_minimo + 1, 1))
    print(f"   Stock actual de '{p_critico.nombre}': {stock_previo} u. (minimo: {p_critico.stock_minimo} u.)")
    venta_2 = sistema.registrar_venta(
        id_cliente=id_cliente_demo, sucursal=MAPA_SUCURSAL["Cairo"], forma_pago="Efectivo",
        carrito=[(p_critico.id_producto, cantidad_venta, p_critico.precio_unitario,
                  round(p_critico.costo_unitario*cantidad_venta, 2))],
        fecha=fecha_demo, hora="16:40:00",
    )
    print(f"   [POS]  Venta {venta_2.id_venta} registrada | Stock resultante: {p_critico.stock_actual} u.")
    print("          -> El Modulo SCM detecto el stock en/bajo el minimo y genero la OC arriba,")
    print("             de forma AUTOMATICA (Fase 2.2/2.3), sin intervencion humana.")

    print(f"\n(E3) Simulamos la llegada del pedido del proveedor (cierre del ciclo SCM):")
    scm.recibir_pedido(p_critico.id_producto)

    if cliente_reactivar:
        cid_r, nombre_r, dias_r = cliente_reactivar
        print(f"\n(E4) El cliente '{nombre_r}' ({cid_r}) estaba marcado en riesgo "
              f"({dias_r} dias sin comprar). Regresa a comprar hoy:")
        p_disponible = max(productos.values(), key=lambda p: p.stock_actual)
        venta_4 = sistema.registrar_venta(
            id_cliente=cid_r, sucursal=clientes[cid_r].sucursal_registro,
            forma_pago="Billetera Digital",
            carrito=[(p_disponible.id_producto, 2, p_disponible.precio_unitario,
                      round(p_disponible.costo_unitario*2, 2))],
            fecha=fecha_demo, hora="18:05:00",
        )
        print(f"   [POS]  Venta {venta_4.id_venta} registrada para {cid_r}.")
        print("          -> El Modulo CRM actualizo automaticamente su fecha de ultima compra.")

    # ---------------- FASE G: Segunda consulta CRM ----------------
    print(f"\n[FASE G] Repetimos la consulta automatizada del CRM (corte {fecha_demo})...")
    en_riesgo_2 = crm.detectar_clientes_en_riesgo(fecha_referencia=fecha_demo, umbral_dias=30)

    if cliente_reactivar:
        cid_r = cliente_reactivar[0]
        sigue_en_riesgo = any(c[0] == cid_r for c in en_riesgo_2)
        print(f"\n   >> Verificacion de integracion end-to-end: el cliente {cid_r} "
              f"{'AUN aparece' if sigue_en_riesgo else 'YA NO aparece'} en la lista de riesgo.")
        print("      (Una venta en el Sistema A -POS- actualizo el Sistema B -CRM- de forma automatica.)")

    # ---------------- FASE H: snapshots finales + resumen ----------------
    _guardar_snapshot_clientes(clientes, os.path.join(RUTA_DATOS, "clientes_final.csv"))
    _guardar_snapshot_productos(productos, os.path.join(RUTA_DATOS, "productos_final.csv"))
    _guardar_perfiles(perfil_cliente, os.path.join(RUTA_DATOS, "perfil_diseno_simulacion.csv"))

    ventas_csv = pd.read_csv(os.path.join(RUTA_DATOS, "ventas_sistema.csv"))
    subtotal_total_sistema = round(ventas_csv["subtotal_linea"].sum(), 2)
    subtotal_historico_original = round(df["Sales"].sum() / 1.05, 2)  # el CSV aplica 5% de impuesto
    n_demo = 3 if cliente_reactivar else 2

    print()
    linea("=")
    print(" RESUMEN EJECUTIVO - VERIFICACION DE USO DEL 100% DE LOS DATOS")
    linea("=")
    print(f" Filas reales en el CSV original............... {len(df)}")
    print(f" Transacciones reales reproducidas en el POS.... {ventas_ok}  ({ventas_ok/len(df)*100:.1f}%)")
    print(f" Transacciones adicionales de demostracion...... {n_demo}")
    print(f" Subtotal historico original (Sales / 1.05)..... ${subtotal_historico_original:,.2f}")
    print(f" Subtotal reproducido en el nuevo POS (100 real). ${subtotal_total_sistema:,.2f}  (incluye demo)")
    print(f"   -> coinciden porque se uso el precio y cantidad EXACTOS de cada fila real. El")
    print(f"      sistema nuevo aplica la MISMA tarifa de impuesto del historico (5%), por lo")
    print(f"      que el total con impuesto tambien coincide (la diferencia son las {n_demo} ventas demo).")
    print(f" Asientos contables generados (ERP).............. {erp._contador_asientos}")
    print(f" Ordenes de compra generadas (SCM)............... {scm._contador_ordenes}")
    print(f" Saldo final de caja chica (ERP).................. ${erp.saldo_caja:,.2f}")
    print(f" Clientes reconstruidos (100% de las filas)...... {len(clientes)}")
    print(f" Clientes en riesgo detectados (1a consulta)..... {len(en_riesgo)}")
    print(f" Clientes en riesgo detectados (2a consulta)..... {len(en_riesgo_2)}")
    linea("=")
    print("\nArchivos generados en data/: ventas_sistema.csv, contabilidad_asientos.csv,")
    print("caja_chica.csv, ordenes_compra.csv, alertas_crm.csv, clientes_final.csv,")
    print("productos_final.csv, perfil_diseno_simulacion.csv\n")


def _guardar_snapshot_clientes(clientes, ruta):
    with open(ruta, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["id_cliente", "nombre", "tipo", "genero", "sucursal_registro",
                          "fecha_registro", "fecha_ultima_compra"])
        for c in clientes.values():
            writer.writerow([c.id_cliente, c.nombre, c.tipo, c.genero,
                              c.sucursal_registro, c.fecha_registro, c.fecha_ultima_compra])


def _guardar_snapshot_productos(productos, ruta):
    with open(ruta, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["id_producto", "nombre", "linea", "precio_unitario",
                          "costo_unitario", "stock_actual", "stock_minimo", "proveedor"])
        for p in productos.values():
            writer.writerow([p.id_producto, p.nombre, p.linea, p.precio_unitario,
                              p.costo_unitario, p.stock_actual, p.stock_minimo, p.proveedor])


def _guardar_perfiles(perfil_cliente, ruta):
    with open(ruta, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow(["id_cliente", "perfil_diseno"])
        for cid, perfil in perfil_cliente.items():
            writer.writerow([cid, perfil])


if __name__ == "__main__":
    main()
