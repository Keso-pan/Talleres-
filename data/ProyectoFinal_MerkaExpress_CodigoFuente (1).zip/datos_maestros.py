# -*- coding: utf-8 -*-
"""
datos_maestros.py
Proyecto Final ISID223 - Transformacion Digital Empresarial (MerkaExpress)

A diferencia de la version anterior de este archivo, AQUI NO SE GENERA NINGUNA
VENTA SINTETICA. Este modulo:

  1) Construye el catalogo de productos a partir de las 6 lineas REALES que
     existen en SuperMarket_Analysis.csv (con parametros de inventario -stock,
     punto de reorden, proveedor- calibrados sobre la demanda real observada;
     esos parametros no existen en un log de ventas por definicion, asi que
     son la unica pieza de configuracion de negocio que se define a mano).
  2) Reconstruye una base de clientes a partir del 100% de las 1000 filas
     reales, ya que el archivo no trae un id_cliente (solo "Customer type":
     Member/Normal). Metodologia (documentada y validada con el usuario):
        - Member -> se asume compra recurrente (posee tarjeta): sus filas se
          agrupan dentro de cada (Sucursal, Genero) en pseudo-clientes de 1 a
          7 compras, usando una distribucion realista.
        - Normal -> sin evidencia de recompra: cada fila es su propio cliente
          (frecuencia = 1). No se inventa una recurrencia que el dato no
          respalda.
     Ninguna fila se descarta ni se duplica: frecuencia total == 1000.
  3) Prepara la lista de eventos, en orden cronologico EXACTO (Fecha+Hora
     reales), listos para reproducirse 1:1 a traves de SistemaPOS.registrar_venta().
"""

import numpy as np
import pandas as pd

from core.modelos import Cliente, Producto

MAPA_SUCURSAL = {"Alex": "Alex (Yangon)", "Cairo": "Cairo (Mandalay)", "Giza": "Giza (Naypyitaw)"}
MAPA_PAGO = {"Ewallet": "Billetera Digital", "Cash": "Efectivo", "Credit card": "Tarjeta de Credito"}

NOMBRES_F = ["Maria", "Ana", "Gabriela", "Andrea", "Daniela", "Camila", "Valentina",
             "Paola", "Fernanda", "Lucia", "Carla", "Sofia", "Michelle", "Domenica",
             "Priscila", "Johanna", "Karen", "Estefania"]
NOMBRES_M = ["Carlos", "Luis", "Juan", "Andres", "Diego", "Fernando", "Santiago",
             "Pablo", "Kevin", "Xavier", "Bryan", "Marco", "Israel", "Jefferson",
             "Christian", "Danilo", "Patricio", "Ricardo"]
APELLIDOS = ["Perez", "Chuquimarca", "Vargas", "Mendoza", "Guaman", "Salazar", "Ortiz",
             "Cevallos", "Cando", "Toapanta", "Zambrano", "Yepez", "Andrade", "Suarez",
             "Tacuri", "Villacis", "Chicaiza", "Naranjo", "Quishpe", "Rivadeneira",
             "Simbana", "Pilamunga"]

# (linea_real_csv, nombre_es, proveedor, stock_inicial, stock_minimo, cantidad_reorden)
# stock_inicial/stock_minimo calibrados a partir de la demanda REAL de 90 dias
# (Quantity.sum() por linea): ~854 a 971 unidades -> stock inicial ~= 27%,
# punto de reorden ~= 7% de esa demanda observada.
LINEAS = [
    ("Health and beauty", "Cuidado Personal y Belleza", "Distribuidora Central de Belleza", 230, 60, 180),
    ("Electronic accessories", "Accesorios Electronicos", "TecnoImport Cia. Ltda.", 260, 65, 180),
    ("Home and lifestyle", "Hogar y Estilo de Vida", "Hogar & Deco Proveedores", 245, 60, 180),
    ("Sports and travel", "Deportes y Viaje", "DeportTravel S.A.", 245, 60, 180),
    ("Food and beverages", "Alimentos y Bebidas", "Distribuidora Central de Alimentos", 255, 65, 180),
    ("Fashion accessories", "Accesorios de Moda", "Moda Total Proveedores", 240, 60, 180),
]


def crear_catalogo_productos(df: pd.DataFrame):
    """Un 'producto' por cada una de las 6 lineas reales del CSV. El precio de
    lista es el precio promedio real observado (solo como referencia; cada
    venta reproducida usa el precio REAL de su fila, no este promedio)."""
    productos = {}
    mapa_id_por_linea = {}
    for i, (linea, nombre_es, proveedor, stock, stock_min, reorden) in enumerate(LINEAS, start=1):
        pid = f"PR-{i:02d}"
        precio_ref = round(df.loc[df["Product line"] == linea, "Unit price"].mean(), 2)
        productos[pid] = Producto(
            id_producto=pid, nombre=nombre_es, linea=linea,
            precio_unitario=precio_ref, costo_unitario=round(precio_ref * 0.95, 2),
            stock_actual=stock, stock_minimo=stock_min, proveedor=proveedor,
        )
        mapa_id_por_linea[linea] = pid
    return productos, mapa_id_por_linea


def _clusterizar(indices, rng):
    """Reparte una lista de indices reales en grupos de 1 a 7 (pseudo-clientes
    recurrentes), sin descartar ni duplicar ningun indice."""
    indices = list(indices)
    rng.shuffle(indices)
    tams = np.array([1, 2, 3, 4, 5, 6, 7])
    pesos = np.array([0.12, 0.22, 0.24, 0.18, 0.12, 0.08, 0.04])
    pesos = pesos / pesos.sum()
    grupos, i = [], 0
    while i < len(indices):
        restantes = len(indices) - i
        tam = min(int(rng.choice(tams, p=pesos)), restantes)
        grupos.append(indices[i:i + tam])
        i += tam
    return grupos


def _nombre_aleatorio(genero_es, rng):
    pila = rng.choice(NOMBRES_F if genero_es == "Femenino" else NOMBRES_M)
    apellido = rng.choice(APELLIDOS)
    return f"{pila} {apellido}"


def reconstruir_clientes(df: pd.DataFrame, seed: int = 42):
    """Reconstruye pseudo-clientes sobre el 100% de las 1000 filas reales.
    Devuelve (dict id_cliente->Cliente, Series index_fila->id_cliente,
    dict perfil_diseno para trazabilidad -Member/Normal-)."""
    rng = np.random.default_rng(seed)
    ids_por_fila = pd.Series(index=df.index, dtype=object)
    clientes = {}
    perfil = {}

    k = 0
    miembros = df[df["Customer type"] == "Member"]
    for (branch, gender), grupo in miembros.groupby(["Branch", "Gender"]):
        for cluster in _clusterizar(list(grupo.index), rng):
            k += 1
            cid = f"CL-M{k:04d}"
            genero_es = "Femenino" if gender == "Female" else "Masculino"
            fechas_cluster = df.loc[cluster, "Date"]
            ids_por_fila.loc[cluster] = cid
            clientes[cid] = Cliente(
                id_cliente=cid, nombre=_nombre_aleatorio(genero_es, rng), tipo="Member",
                genero=genero_es, sucursal_registro=MAPA_SUCURSAL[branch],
                fecha_registro=fechas_cluster.min().strftime("%Y-%m-%d"),
            )
            perfil[cid] = f"Member ({len(cluster)} compras reales)"

    j = 0
    normales = df[df["Customer type"] == "Normal"]
    for idx in normales.index:
        j += 1
        cid = f"CL-N{j:04d}"
        fila = df.loc[idx]
        genero_es = "Femenino" if fila["Gender"] == "Female" else "Masculino"
        ids_por_fila.loc[idx] = cid
        clientes[cid] = Cliente(
            id_cliente=cid, nombre=_nombre_aleatorio(genero_es, rng), tipo="Normal",
            genero=genero_es, sucursal_registro=MAPA_SUCURSAL[fila["Branch"]],
            fecha_registro=fila["Date"].strftime("%Y-%m-%d"),
        )
        perfil[cid] = "Normal (1 compra real)"

    assert ids_por_fila.notna().sum() == len(df), "Quedaron filas reales sin pseudo-cliente asignado"
    return clientes, ids_por_fila, perfil


def preparar_eventos_reales(df: pd.DataFrame, ids_por_fila: pd.Series, mapa_id_por_linea: dict):
    """Ordena el 100% de las filas reales cronologicamente (Fecha+Hora reales)
    y arma, para cada una, los parametros exactos que espera
    SistemaPOS.registrar_venta(): precio y costo REALES de esa transaccion."""
    d = df.copy()
    d["id_cliente"] = ids_por_fila
    d["Datetime"] = pd.to_datetime(d["Date"].dt.strftime("%Y-%m-%d") + " " + d["Time"],
                                    format="%Y-%m-%d %I:%M:%S %p")
    d = d.sort_values("Datetime").reset_index(drop=True)

    eventos = []
    for _, fila in d.iterrows():
        id_prod = mapa_id_por_linea[fila["Product line"]]
        eventos.append({
            "id_cliente": fila["id_cliente"],
            "sucursal": MAPA_SUCURSAL[fila["Branch"]],
            "forma_pago": MAPA_PAGO.get(fila["Payment"], fila["Payment"]),
            "carrito": [(id_prod, int(fila["Quantity"]), float(fila["Unit price"]), float(fila["cogs"]))],
            "fecha": fila["Date"].strftime("%Y-%m-%d"),
            "hora": fila["Time"],
        })
    assert len(eventos) == len(df), "El numero de eventos no coincide con el numero de filas reales"
    return eventos
