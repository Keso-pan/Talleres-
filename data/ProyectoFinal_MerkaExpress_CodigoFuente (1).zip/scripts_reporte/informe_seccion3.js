// scripts_reporte/informe_seccion3.js
// SECCION 3 - DOCUMENTACIÓN TÉCNICA (Fase 2 del proyecto)

const { h1, h2, h3, p, pRuns, bullet, tabla, figura, mono, spacer, fmt$, fmtN,
  extraerEvidenciaConsola, datos, TEAL, RED } = require("./informe_base");
const { TextRun, Paragraph, PageBreak } = require("docx");

const s = datos.simulacion;

const seccion3_1 = [
  h2("3.1 Arquitectura de la solución"),
  p(`El Sistema Principal (POS) actúa como sujeto observable; los módulos ERP, SCM y CRM se suscriben `
    + `una única vez, al arrancar el sistema. A partir de ese momento, cada venta registrada dispara `
    + `automáticamente una notificación a los tres módulos, que reaccionan de forma independiente según `
    + `su propia responsabilidad, y alimentan en conjunto el Dashboard Gerencial (Fase 4).`),
  ...figura("diagrama_arquitectura.png", 560, 367, "Figura 5. Arquitectura de integración basada en el patrón Observer."),
];

const clasesCore = [
  ["Cliente", "Entidad de dominio", "Representa a un cliente registrado: identificador único, tipo "
    + "(Member/Normal), sucursal y fecha de última compra (actualizada automáticamente por el CRM)."],
  ["Producto", "Entidad de dominio", "Representa un SKU del catálogo, con control de inventario propio "
    + "(hay_stock_bajo(), reducir_stock(), aumentar_stock())."],
  ["DetalleVenta", "Entidad de dominio", "Línea individual dentro de una venta (un producto, cantidad y "
    + "precio); expone la propiedad calculada subtotal."],
  ["Venta", "Entidad de dominio", "Encabezado de una transacción; compone una lista de DetalleVenta y "
    + "expone las propiedades calculadas subtotal, iva (15%) y total."],
  ["ObservadorVenta", "Interfaz (ABC)", "Contrato abstracto que deben implementar todos los módulos que "
    + "reaccionan a una venta (método actualizar(venta))."],
  ["SistemaPOS", "Servicio / Sujeto Observable", "Orquesta el registro de ventas, la persistencia en CSV "
    + "y la notificación automática a los observadores suscritos."],
];

const seccion3_2 = [
  h2("3.2 Sistema Principal (Core Business)"),
  p(`El núcleo del sistema (paquete core/) se desarrolló en Python aplicando Programación Orientada a `
    + `Objetos: cada clase tiene una única responsabilidad, los atributos de dominio se encapsulan en `
    + `dataclasses con métodos propios de validación, y la persistencia se delega a la clase de servicio `
    + `SistemaPOS.`),
  tabla(["Clase", "Tipo", "Responsabilidad"], clasesCore, [0.18, 0.20, 0.62]),
  spacer(140),
  p(`Fragmento representativo del núcleo — registro de una venta y disparo automático de la `
    + `integración (core/sistema_pos.py):`),
  mono("def registrar_venta(self, id_cliente, sucursal, forma_pago, carrito, fecha=None, hora=None):"),
  mono("    ...                                    # valida stock y arma DetalleVenta por cada línea"),
  mono("    venta = Venta(id_venta, id_cliente, sucursal, fecha, hora, forma_pago, detalles)"),
  mono("    self._persistir_venta(venta)          # guarda en data/ventas_sistema.csv"),
  mono("    self.clientes[id_cliente].actualizar_ultima_compra(fecha)"),
  mono("    self._notificar_observadores(venta)   # <-- INTEGRACION AUTOMATICA (Fase 2.3)"),
  mono("    return venta"),
  spacer(200),
];

const seccion3_3 = [
  h2("3.3 Módulos satélite: ERP, SCM y CRM"),
  h3("3.3.1 Módulo ERP (mini-financiero)"),
  p(`La clase ModuloERP implementa ObservadorVenta. Por cada venta notificada, genera un asiento `
    + `contable de partida doble (Debe/Haber: Caja-Bancos, Ventas, IVA por Pagar) y actualiza el saldo `
    + `de Caja Chica, persistiendo ambos resultados en data/contabilidad_asientos.csv y `
    + `data/caja_chica.csv respectivamente.`),
  h3("3.3.2 Módulo SCM (inventario / proveedores)"),
  p(`La clase ModuloSCM también implementa ObservadorVenta. Revisa, línea por línea, si el producto `
    + `vendido quedó en o por debajo de su punto de reorden (stock_minimo); de ser así, genera `
    + `automáticamente una Orden de Compra al proveedor asociado y la persiste en `
    + `data/ordenes_compra.csv. El método recibir_pedido() simula la llegada de la mercadería del `
    + `proveedor tras un lead time configurable, cerrando el ciclo de la orden.`),
  h3("3.3.3 Módulo CRM (relación con el cliente)"),
  p(`La clase ModuloCRM cumple una doble función: como ObservadorVenta, mantiene siempre actualizada la `
    + `fecha de última compra de cada cliente; y, de forma independiente, expone el método `
    + `detectar_clientes_en_riesgo(), una consulta automatizada que recorre la base de clientes y aísla `
    + `—generando una alerta persistida en data/alertas_crm.csv— a quienes superan el umbral de `
    + `inactividad configurado (30 días por defecto), disparando el estado "Cliente en Riesgo de `
    + `Deserción" hacia la interfaz gerencial.`),
  new Paragraph({ children: [new PageBreak()] }),
];

const evidenciaLineas = extraerEvidenciaConsola();

function envolver(linea, maxLen = 92) {
  if (linea.length <= maxLen) return [linea];
  const palabras = linea.split(" ");
  const salida = [];
  let actual = "";
  for (const palabra of palabras) {
    const propuesta = actual ? actual + " " + palabra : palabra;
    if (propuesta.length > maxLen) {
      salida.push(actual);
      actual = "   " + palabra;
    } else {
      actual = propuesta;
    }
  }
  if (actual) salida.push(actual);
  return salida;
}
const evidenciaLineasEnvueltas = evidenciaLineas.flatMap((l) => envolver(l));

const seccion3_4 = [
  h2("3.4 Evidencia de integración (Fase 2.3)"),
  p(`Para demostrar —con código en ejecución, no solo en el diseño— que una acción en el Sistema `
    + `Principal dispara consecuencias automáticas en los módulos ERP, SCM y CRM, se construyó un `
    + `escenario de demostración (main_demo.py) sobre una base ya operando con cuatro meses de historial `
    + `simulado. La salida real de consola se reproduce a continuación (log completo disponible en `
    + `evidencia_integracion_consola.txt, en la raíz del repositorio):`),
  ...evidenciaLineasEnvueltas.map(l => mono(l.replace(/\s+$/,'') || " ")),
  spacer(160),
  p(`Esta traza demuestra el ciclo de integración completo: (E1) una venta normal dispara `
    + `automáticamente el asiento contable del ERP; (E2) una venta que agota el margen de stock dispara `
    + `automáticamente una orden de compra del SCM; (E3) se simula la recepción del proveedor, cerrando `
    + `el ciclo; y (E4) un cliente previamente marcado "en riesgo" vuelve a comprar, lo que el CRM `
    + `refleja de inmediato — al repetir la consulta automatizada, ese cliente ya no aparece en la lista `
    + `de riesgo, verificando el cierre del ciclo Sistema A → Sistema B sin intervención humana.`),
];

module.exports = [
  h1("3. Documentación Técnica"),
  ...seccion3_1, spacer(100),
  ...seccion3_2,
  ...seccion3_3,
  ...seccion3_4,
  new Paragraph({ children: [new PageBreak()] }),
];
