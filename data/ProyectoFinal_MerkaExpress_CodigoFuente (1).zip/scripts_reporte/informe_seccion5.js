// scripts_reporte/informe_seccion5.js
// SECCION 5 - ANEXOS

const { h1, h2, h3, p, pRuns, bullet, mono, spacer, tabla, datos, TEAL } = require("./informe_base");
const { TextRun, Paragraph, ExternalHyperlink } = require("docx");

const s = datos.simulacion;

const estructura = [
"proyecto_final/",
"├── README.md                      Guia general del repositorio",
"├── main_demo.py                   Orquestador: simulacion + escenario de integracion en vivo",
"├── datos_maestros.py              Generador de catalogo de productos y clientes",
"├── core/",
"│   ├── modelos.py                 Clases Cliente, Producto, Venta, DetalleVenta",
"│   └── sistema_pos.py             SistemaPOS (Core Business) + patron Observer",
"├── modulos/",
"│   ├── modulo_erp.py              Asientos contables + caja chica",
"│   ├── modulo_scm.py               Ordenes de compra automaticas",
"│   └── modulo_crm.py               Deteccion de clientes en riesgo",
"├── bi/",
"│   ├── analisis_rfm.py            Segmentacion RFM (Fase 3.1)",
"│   └── dashboard.py               Generacion del tablero gerencial (Fase 4.1)",
"├── diagramas/                     ER, arquitectura, cadena de valor, mockups, dashboard (.png)",
"├── data/                          CSV generados por la simulacion (ventas, contabilidad, ordenes...)",
"└── scripts_reporte/               Generador de este informe (.docx/.pdf)",
];

const seccion5_1 = [
  h2("5.1 Repositorio de código"),
  p(`El código fuente completo del proyecto —sistema principal, los tres módulos satélite, los `
    + `scripts de inteligencia de negocios y los generadores de diagramas— se entrega junto a este `
    + `informe y debe publicarse en el repositorio de GitHub del equipo (cuenta de referencia: `
    + `Keso-pan) antes de la sustentación.`),
  mono("Estructura del repositorio:"),
  ...estructura.map(l => mono(l)),
];

const pasos = [
  "Instalar dependencias: pip install pandas matplotlib numpy",
  "Ejecutar la simulación completa (genera todos los CSV en data/): python3 main_demo.py",
  "Ejecutar la segmentación RFM (genera data/rfm_resultados.csv): python3 bi/analisis_rfm.py",
  "Generar el tablero gerencial (genera diagramas/dashboard_gerencial.png): python3 bi/dashboard.py",
  "(Opcional) Regenerar ER, arquitectura, cadena de valor y mockups: python3 diagramas/generar_diagramas.py",
];

const seccion5_2 = [
  spacer(120),
  h2("5.2 Instrucciones de ejecución"),
  p(`Todos los scripts deben ejecutarse desde la raíz del repositorio, con Python 3.10 o superior:`),
  ...pasos.map((t, i) => bullet(`${i + 1}. ${t}`)),
  p(`Durante la sustentación en vivo, se recomienda ejecutar main_demo.py y detener la exposición en la `
    + `sección "FASE E | ESCENARIO DE DEMOSTRACIÓN EN VIVO" (líneas E1–E4), que reproduce en tiempo `
    + `real la integración POS → ERP/SCM/CRM exigida por la rúbrica del proyecto.`),
];

const seccion5_3 = [
  spacer(120),
  h2("5.3 Alcances y limitaciones"),
  bullet("El módulo ERP registra únicamente los ingresos por venta; no modela cuentas por pagar a "
    + "proveedores ni nómina, lo que podría incorporarse en una segunda iteración."),
  bullet("El módulo SCM asume un lead time de proveedor fijo (6 días) y una cantidad de reorden fija "
    + "por producto; un refinamiento natural sería calcular ambos parámetros de forma dinámica a partir "
    + "del histórico de ventas."),
  bullet("La persistencia actual es en archivos CSV, adecuada para el alcance académico del proyecto; "
    + "la migración a un motor relacional (PostgreSQL/MySQL) es directa gracias al desacoplamiento entre "
    + "los modelos de dominio y la capa de persistencia."),
  bullet("El umbral de inactividad del CRM (30 días) es un parámetro de negocio configurable; su valor "
    + "óptimo debería calibrarse con datos reales de recompra de MerkaExpress una vez en producción."),
  bullet("La auditoría web (sección 4.2) se entrega como especificación de KPI a exigir en el despliegue "
    + "en la nube; no fue posible medirla contra un ambiente productivo real dentro del alcance de este "
    + "proyecto académico."),
];

const seccion5_4 = [
  spacer(120),
  h2("5.4 Nota metodológica sobre los datos"),
  p(`Con fines exclusivamente académicos, este proyecto combina dos fuentes de datos con propósitos `
    + `distintos y claramente delimitados:`),
  bullet(`Diagnóstico inicial (Sección 2.1): se utilizó el archivo histórico SuperMarket_Analysis.csv `
    + `(${1000} transacciones reales de un minimercado, ${s.periodo_inicio.slice(3)}) como sustituto de `
    + `los datos reales de MerkaExpress, renombrando únicamente sus tres sucursales a Quito, Guayaquil `
    + `y Cuenca para mantener la coherencia narrativa del caso. Estos datos evidencian, además, la `
    + `limitación estructural (ausencia de un id_cliente) que motiva el rediseño propuesto.`),
  bullet(`Operación del nuevo sistema (Fases 2, 3 y 4): dado que el sistema heredado no capturaba `
    + `identificador de cliente, no es posible reconstruir un historial de compras real por persona a `
    + `partir del archivo histórico. Se generó entonces una simulación de ${s.n_facturas} ventas para `
    + `${s.n_clientes_simulados} clientes a lo largo de ${s.periodo_inicio} – ${s.periodo_fin}, calibrada `
    + `con los mismos rangos de precio, cantidad y líneas de producto observados en el diagnóstico, y `
    + `diseñada con perfiles de comportamiento diferenciados (VIP, Fieles, Regulares, Nuevos, En Riesgo, `
    + `Inactivos) para poder validar que el modelo RFM y las alertas del CRM responden correctamente a `
    + `patrones de compra realistas.`),
  p(`Todo el código que genera, procesa y visualiza estos datos —incluyendo el generador de la `
    + `simulación (datos_maestros.py)— se entrega junto con este informe, de modo que cualquier cifra `
    + `presentada pueda reproducirse de forma exacta.`),
];

module.exports = [
  h1("5. Anexos"),
  ...seccion5_1,
  ...seccion5_2,
  ...seccion5_3,
  ...seccion5_4,
];
