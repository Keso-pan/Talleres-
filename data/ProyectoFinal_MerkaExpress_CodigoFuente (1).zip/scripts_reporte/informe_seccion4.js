// scripts_reporte/informe_seccion4.js
// SECCION 4 - INTELIGENCIA DE NEGOCIOS Y AUDITORÍA (Fases 3 y 4 del proyecto)

const { h1, h2, h3, p, pRuns, tabla, figura, spacer, fmt$, fmtN, datos,
  TEAL, RED, AMBER } = require("./informe_base");
const { TextRun, Paragraph, PageBreak } = require("docx");

const r = datos.rfm, s = datos.simulacion;
const vip = r.segmentos.find(x => x.segmento === "VIP / Campeones");
const noPerder = r.segmentos.find(x => x.segmento === "No Perder (alto valor inactivo)");
const hibernando = r.segmentos.find(x => x.segmento === "Hibernando / Perdidos");

const filasRfm = r.segmentos.map(x => [
  x.segmento, fmtN(x.clientes), `${x.pct_clientes}%`, fmt$(x.gasto_total), `${x.pct_ingresos}%`,
  fmt$(x.gasto_promedio), String(x.frecuencia_promedio), `${x.recencia_promedio} días`,
]);

const filasTopVip = r.top_vip.map((x, i) => [String(i + 1), x.cliente, fmt$(x.gasto), fmtN(x.frecuencia)]);

const seccion4_1 = [
  h2("4.1 Segmentación RFM"),
  p(`Se implementó el algoritmo de segmentación RFM (Recencia, Frecuencia, Monetario) en Python `
    + `(bi/analisis_rfm.py), aplicado sobre el histórico de transacciones generado por el Sistema POS `
    + `(data/ventas_sistema.csv). Para cada uno de los ${fmtN(r.n_clientes_analizados)} clientes se `
    + `calculó: (R) días transcurridos desde su última compra; (F) número de facturas distintas; y `
    + `(M) gasto total acumulado. Cada dimensión se clasificó en quintiles (puntaje 1 a 5) y la `
    + `combinación de los tres puntajes determinó una etiqueta estratégica.`),
  tabla(
    ["Segmento", "Clientes", "% clientes", "Ingresos", "% ingresos", "Gasto prom.", "Frec. prom.", "Recencia prom."],
    filasRfm, [0.19, 0.09, 0.09, 0.14, 0.10, 0.13, 0.10, 0.16]
  ),
  spacer(160),
  pRuns([
    new TextRun({ text: "Interpretación. ", bold: true, size: 22 }),
    new TextRun({ text: `El segmento `, size: 22 }),
    new TextRun({ text: "VIP / Campeones", size: 22, bold: true, color: TEAL }),
    new TextRun({ text: ` reúne solo al ${vip.pct_clientes}% de la cartera de clientes, pero concentra `
      + `el ${vip.pct_ingresos}% de los ingresos totales — un patrón de concentración (tipo Pareto) que `
      + `justifica priorizar la retención de este grupo por sobre la adquisición de clientes nuevos. En `
      + `el extremo opuesto, el segmento `, size: 22 }),
    new TextRun({ text: "Hibernando / Perdidos", size: 22, bold: true, color: RED }),
    new TextRun({ text: ` agrupa al ${hibernando.pct_clientes}% de los clientes pero solo aporta el `
      + `${hibernando.pct_ingresos}% de los ingresos, por lo que no amerita grandes esfuerzos de `
      + `reactivación individual. El hallazgo de mayor valor accionable es el segmento `, size: 22 }),
    new TextRun({ text: "“No Perder”", size: 22, bold: true, color: AMBER }),
    new TextRun({ text: `: ${noPerder.clientes} clientes con historial de alto valor `
      + `(gasto promedio de ${fmt$(noPerder.gasto_promedio)}) que llevan en promedio `
      + `${noPerder.recencia_promedio} días sin comprar. Recuperar a este grupo específico —mediante una `
      + `campaña dirigida que el propio módulo CRM puede activar— tiene, en términos de costo-beneficio, `
      + `el mayor retorno esperado de todo el ejercicio de segmentación.`, size: 22 }),
  ]),
  spacer(140),
  p(`A modo de validación cruzada, la Tabla 7 lista a los cinco clientes de mayor gasto dentro del `
    + `segmento VIP / Campeones:`),
  tabla(["#", "Cliente", "Gasto acumulado", "N.º de compras"], filasTopVip, [0.08, 0.42, 0.28, 0.22]),
];

const coreWebVitals = [
  ["LCP — Largest Contentful Paint", "≤ 2.5 s", "Tiempo hasta que el elemento principal visible "
    + "(p. ej., el catálogo de productos) termina de cargar."],
  ["INP — Interaction to Next Paint", "≤ 200 ms", "Tiempo de respuesta ante la interacción del "
    + "usuario (clic en “Cobrar”, filtro de categoría); sustituye a FID."],
  ["CLS — Cumulative Layout Shift", "≤ 0.1", "Estabilidad visual: que los elementos de la pantalla no "
    + "“salten” mientras carga la página del POS o del Dashboard."],
  ["TTFB — Time to First Byte", "≤ 800 ms", "Tiempo de respuesta inicial del servidor ante cada "
    + "solicitud, crítico durante las horas pico de venta."],
];

const kpiSeguridad = [
  ["Cifrado en tránsito", "TLS 1.2 o superior (HTTPS obligatorio)", "Protege las credenciales del "
    + "cajero y los datos personales del cliente en cada transacción."],
  ["Cumplimiento normativo", "Alineación con la Ley Orgánica de Protección de Datos Personales (Ecuador)",
    "El sistema almacena datos personales de clientes (historial de compra, segmento RFM)."],
  ["Gestión de accesos", "Autenticación por rol + doble factor (MFA) para roles gerencial y contable",
    "Limita el acceso a asientos contables, saldos de caja y reportes financieros."],
  ["Disponibilidad (SLA)", "≥ 99.5% de disponibilidad mensual", "Evita interrupciones del POS durante "
    + "el horario de atención de las tres sucursales."],
  ["Respaldo de datos", "Backup automático diario, con retención de 30 días", "Garantiza la "
    + "continuidad del negocio ante fallos técnicos o pérdida de datos."],
  ["Gestión de vulnerabilidades", "Escaneo alineado a OWASP Top 10, con revisión trimestral", "Mitiga "
    + "riesgos comunes en aplicaciones web (inyección, XSS, configuración insegura)."],
  ["Tiempo de detección de incidentes (MTTD)", "≤ 24 horas", "Minimiza el impacto de una eventual "
    + "brecha de seguridad sobre los datos de clientes y transacciones."],
];

const seccion4_2 = [
  spacer(100),
  h2("4.2 Auditoría web"),
  p(`Aunque en esta fase del proyecto el sistema opera de forma local (POS de escritorio + CSV), el `
    + `plan de transformación digital de MerkaExpress contempla una futura exposición web del Dashboard `
    + `Gerencial y, eventualmente, de un canal de autoservicio para clientes. Por ello, se definieron `
    + `desde ya los KPI de desempeño (Core Web Vitals) y de seguridad exigibles al momento de desplegar `
    + `el sistema en la nube.`),
  h3("4.2.1 Core Web Vitals"),
  tabla(["Métrica", "Objetivo recomendado", "Descripción"], coreWebVitals, [0.30, 0.18, 0.52]),
  spacer(160),
  h3("4.2.2 KPI de seguridad"),
  tabla(["Indicador", "Meta / estándar", "Justificación"], kpiSeguridad, [0.26, 0.32, 0.42]),
  new Paragraph({ children: [new PageBreak()] }),
];

const seccion4_3 = [
  h2("4.3 Dashboard gerencial"),
  p(`El tablero de control consolida, en una sola vista, los tres tipos de indicador exigidos: `
    + `evolución temporal de ventas, segmentación de clientes (RFM) y un indicador proveniente de los `
    + `módulos ERP/SCM (órdenes de compra por proveedor), además de un panel de alertas alimentado en `
    + `tiempo real por el módulo CRM.`),
  ...figura("dashboard_gerencial.png", 560, 338, "Figura 6. Tablero de Control Gerencial de MerkaExpress, generado a partir de los datos reales de la simulación."),
  pRuns([
    new TextRun({ text: "Interpretación. ", bold: true, size: 22 }),
    new TextRun({ text: `La evolución semanal de ventas muestra un pico a inicios de marzo (arranque `
      + `del nuevo sistema y campaña de lanzamiento simulada) y una tendencia a la baja hacia finales de `
      + `junio, coincidente con el aumento de clientes en el segmento "En Riesgo" — una señal de alerta `
      + `temprana que el módulo CRM ya está capturando de forma automatizada. El panel de proveedores `
      + `muestra que “Moda Total Proveedores” concentra el mayor número de órdenes de compra automáticas, `
      + `lo que sugiere revisar su punto de reorden o negociar un lote de reposición mayor para reducir `
      + `la frecuencia de pedidos pequeños. Finalmente, el panel de alertas CRM materializa, en la `
      + `interfaz gerencial, la consulta automatizada descrita en la Sección 3.3.3: cada fila representa `
      + `un cliente aislado por el sistema sin que ningún gerente haya tenido que revisarlo manualmente.`,
      size: 22 }),
  ]),
];

module.exports = [
  h1("4. Inteligencia de Negocios y Auditoría"),
  ...seccion4_1,
  ...seccion4_2,
  ...seccion4_3,
  new Paragraph({ children: [new PageBreak()] }),
];
