// scripts_reporte/informe_seccion2.js
// SECCION 2 - DISEÑO ESTRATÉGICO (Fase 1 del proyecto)

const { h1, h2, h3, p, pRuns, bullet, tabla, figura, spacer, fmt$, fmtN, datos,
  NAVY, TEAL, AMBER, RED, GRAY } = require("./informe_base");
const { TextRun, Paragraph, PageBreak, AlignmentType } = require("docx");

const d = datos.diagnostico;

// ---------------------------------------------------------- 2.1 diagnóstico
const filasSucursal = d.por_sucursal.map(x => [x.sucursal, fmtN(x.transacciones), fmt$(x.ventas)]);
const filasLinea = d.por_linea.map(x => [x.linea, fmtN(x.transacciones), fmt$(x.ventas), fmt$(x.ticket_promedio)]);

const seccion2_1 = [
  h2("2.1 Diagnóstico del negocio"),
  p(`Como primer paso del levantamiento estratégico, NexoTech Consultores analizó el histórico `
    + `transaccional que MerkaExpress mantenía en su sistema de punto de venta heredado: `
    + `${fmtN(d.n_transacciones)} transacciones registradas entre el ${d.fecha_min} y el ${d.fecha_max} `
    + `en sus tres sucursales, con ventas acumuladas de ${fmt$(d.ventas_totales)} (ticket promedio de `
    + `${fmt$(d.ticket_promedio)}) distribuidas de forma relativamente homogénea entre las seis líneas `
    + `de producto que maneja la empresa. La satisfacción promedio autorreportada por el cliente en ese `
    + `sistema heredado es de ${d.rating_promedio}/10, y el ${d.pct_member}% de las transacciones ya `
    + `corresponde a clientes con tarjeta de membresía («Member»).`),
  tabla(["Sucursal", "Transacciones", "Ventas históricas"], filasSucursal, [0.4, 0.3, 0.3]),
  spacer(160),
  tabla(["Línea de producto", "Transacciones", "Ventas históricas", "Ticket promedio"], filasLinea,
    [0.34, 0.2, 0.24, 0.22]),
  spacer(120),
  p(`El diagnóstico reveló un hallazgo crítico para el alcance del proyecto: el sistema heredado `
    + `registra cada transacción de forma aislada, identificando únicamente el tipo de cliente `
    + `(Miembro o Normal) pero sin un identificador único que permita reconstruir el historial de `
    + `compras de una misma persona a lo largo del tiempo. En consecuencia, la empresa no podía `
    + `responder preguntas tan básicas como “¿qué clientes han dejado de comprar?” o “¿quiénes son mis `
    + `mejores clientes?”, pese a que más de la mitad de sus transacciones corresponde a clientes con `
    + `membresía activa. Este hallazgo se convirtió en un requerimiento no negociable del nuevo Sistema `
    + `Principal (RF-01, sección 2.4.1) y por sí solo justifica gran parte del valor de este proyecto.`),
];

// ------------------------------------------------------------ 2.2 Porter
const filasPorter = [
  ["Poder de negociación\nde los clientes", "Alto",
    "Costos de cambio bajísimos: el cliente puede acudir a la competencia sin fricción, y no existe "
    + "un programa de fidelización activo pese a que más de la mitad ya porta tarjeta de miembro.",
    "El módulo CRM y la segmentación RFM habilitan campañas de fidelización dirigidas (Fase 3.1), "
    + "elevando el costo de cambio percibido y personalizando la oferta."],
  ["Poder de negociación\nde los proveedores", "Medio",
    "Existen múltiples distribuidores para la mayoría de líneas de producto, pero la falta de datos "
    + "de consumo histórico limita la capacidad de negociar volúmenes y plazos de pago.",
    "El módulo SCM provee datos reales de consumo y genera órdenes oportunas, mejorando la posición "
    + "negociadora frente a los proveedores."],
  ["Amenaza de nuevos\ncompetidores", "Medio-Alto",
    "Barreras de entrada bajas para el formato minimercado de barrio; no requiere grandes capitales "
    + "ni tecnología sofisticada para operar de forma básica.",
    "La eficiencia operativa y el conocimiento del cliente basado en datos generan una ventaja difícil "
    + "de replicar rápidamente por un nuevo entrante sin historial."],
  ["Amenaza de productos\nsustitutos", "Alto",
    "Comercio electrónico, tiendas de conveniencia y venta directa por redes sociales compiten por "
    + "el mismo gasto del consumidor final.",
    "El tablero gerencial en tiempo real habilita decisiones ágiles (promociones, mix de productos) "
    + "para responder con rapidez a canales alternativos."],
  ["Rivalidad entre\ncompetidores existentes", "Alta",
    "Márgenes estrechos y competencia frecuente por precio entre cadenas y minimercados independientes "
    + "de las mismas zonas.",
    "La automatización del módulo SCM reduce quiebres de stock y costos operativos (Fase 2.2), "
    + "sosteniendo márgenes sin necesidad de una guerra de precios."],
];

const seccion2_2 = [
  h2("2.2 Análisis de las 5 Fuerzas de Porter"),
  p(`Se aplicó el modelo de las 5 Fuerzas de Porter para caracterizar la industria del retail de `
    + `conveniencia en la que compite MerkaExpress y justificar cómo el Sistema de Información `
    + `propuesto mejora su posición competitiva.`),
  tabla(["Fuerza", "Nivel", "Análisis", "Cómo el SI mejora la posición"], filasPorter,
    [0.15, 0.09, 0.36, 0.40]),
];

// ------------------------------------------------------------ 2.3 Cadena de valor
const filasCadena = [
  ["Logística interna", "Conteo físico de inventario por sucursal, sin visibilidad cruzada entre tiendas.",
    "Stock en tiempo real por sucursal (atributo stock_actual de cada Producto), consultable desde el tablero."],
  ["Operaciones", "Registro de venta en hojas de cálculo o cuadernos independientes por cajero.",
    "Sistema POS con persistencia digital inmediata y cálculo automático de subtotal, IVA y total."],
  ["Logística externa /\nAbastecimiento", "Pedidos telefónicos a proveedores, de carácter reactivo y manual.",
    "Órdenes de compra automáticas del módulo SCM al alcanzar el punto de reorden (sin intervención humana)."],
  ["Marketing y ventas", "Promociones genéricas, iguales para toda la base de clientes.",
    "Segmentación RFM dirigida (VIP, Fieles, En Riesgo, Nuevos, etc.) que permite ofertas diferenciadas."],
  ["Servicio postventa", "Sin mecanismo alguno para detectar clientes inactivos o insatisfechos.",
    "Alertas automáticas del módulo CRM (“Cliente en Riesgo de Deserción”) ante inactividad prolongada."],
];

const seccion2_3 = [
  h2("2.3 Cadena de Valor: situación actual vs. propuesta"),
  p(`La Figura 1 presenta la Cadena de Valor propuesta para MerkaExpress una vez incorporado el `
    + `Sistema de Información. La Tabla 5 detalla, eslabón por eslabón, en qué consiste la situación `
    + `actual (manual) y en qué consiste la propuesta, identificando explícitamente dónde agrega valor `
    + `el nuevo sistema.`),
  ...figura("cadena_valor.png", 560, 290, "Figura 1. Cadena de Valor propuesta para MerkaExpress, con el SI integrado en cada eslabón."),
  tabla(["Eslabón", "Situación actual (manual)", "Propuesta con el SI"], filasCadena, [0.18, 0.40, 0.42]),
];

// ------------------------------------------------------------ 2.4 Requerimientos
const reqFuncionales = [
  ["RF-01", "El sistema debe permitir registrar una venta asociada a un cliente identificado de forma "
    + "única (id_cliente), corrigiendo la principal limitación detectada en el diagnóstico."],
  ["RF-02", "El sistema debe calcular automáticamente el subtotal, el IVA (15%) y el total de cada venta."],
  ["RF-03", "El sistema debe descontar el stock del producto vendido en tiempo real."],
  ["RF-04", "El sistema debe notificar automáticamente a los módulos ERP, SCM y CRM cada vez que se "
    + "registra una venta, sin intervención humana."],
  ["RF-05", "El módulo ERP debe generar un asiento contable de partida doble y actualizar el saldo de "
    + "caja chica por cada venta."],
  ["RF-06", "El módulo SCM debe generar una orden de compra automática cuando el stock de un producto "
    + "llegue a su punto de reorden."],
  ["RF-07", "El módulo CRM debe ejecutar una consulta automatizada que identifique a los clientes cuya "
    + "inactividad supere un umbral configurable (30 días por defecto) y genere una alerta de "
    + "“Cliente en Riesgo de Deserción”."],
  ["RF-08", "El sistema debe permitir calcular la segmentación RFM de los clientes a partir del "
    + "historial de transacciones."],
  ["RF-09", "El sistema debe generar un tablero de control gerencial con indicadores de ventas, "
    + "segmentación de clientes e inventario/proveedores."],
];

const reqNoFuncionales = [
  ["RNF-01", "Rendimiento", "El registro de una venta y la notificación a los tres módulos suscritos "
    + "debe completarse en menos de 2 segundos."],
  ["RNF-02", "Disponibilidad", "El sistema debe estar disponible durante el horario de atención de las "
    + "tres sucursales (8:00–21:00)."],
  ["RNF-03", "Persistencia", "Toda transacción debe quedar registrada de forma persistente (CSV/BD) "
    + "incluso ante un cierre inesperado del proceso."],
  ["RNF-04", "Escalabilidad", "La arquitectura basada en el patrón Observer debe permitir agregar "
    + "nuevos módulos (p. ej., un futuro e-commerce) sin modificar el Sistema Principal."],
  ["RNF-05", "Usabilidad", "La interfaz del POS debe permitir completar una venta típica (2–4 "
    + "productos) en menos de 5 interacciones del cajero."],
  ["RNF-06", "Seguridad", "El acceso a los módulos ERP y CRM debe restringirse por rol (cajero, "
    + "contador, gerente)."],
  ["RNF-07", "Portabilidad", "El almacenamiento en CSV debe facilitar una futura migración a un motor "
    + "de base de datos relacional sin cambios en la lógica de negocio."],
];

const seccion2_4 = [
  h2("2.4 Especificación de requerimientos (SDLC — Análisis)"),
  h3("2.4.1 Requerimientos funcionales"),
  tabla(["Código", "Requerimiento"], reqFuncionales, [0.12, 0.88]),
  spacer(160),
  h3("2.4.2 Requerimientos no funcionales"),
  tabla(["Código", "Categoría", "Restricción"], reqNoFuncionales, [0.12, 0.20, 0.68]),
];

const seccion2_5 = [
  h2("2.5 Integración empresarial: fundamento teórico"),
  p(`Uno de los riesgos más frecuentes al digitalizar procesos de forma aislada es crear nuevos "silos" `
    + `de información: un sistema de ventas que no conversa con contabilidad, o un inventario que no `
    + `conversa con compras. Para evitar este escenario, el diseño de MerkaExpress adopta el patrón de `
    + `diseño Observer, en el cual el Sistema POS actúa como sujeto observable y los módulos ERP, SCM y `
    + `CRM se suscriben a sus eventos de negocio.`),
  p(`Conceptualmente, esto equivale a una integración basada en eventos ("event-driven integration"): `
    + `en lugar de que cada módulo consulte periódicamente al sistema principal ("polling"), el sistema `
    + `principal publica el evento "venta registrada" y cada módulo reacciona de inmediato según su `
    + `propia lógica de negocio. Esta arquitectura es análoga a la que utilizan los ERP comerciales `
    + `(SAP, Odoo) para sincronizar sus módulos de Ventas, Finanzas e Inventario, y es la misma que `
    + `permitiría, en una segunda iteración, publicar estos eventos a un bus de mensajería (p. ej. `
    + `RabbitMQ o Kafka) para operar de forma distribuida sin alterar la lógica interna de cada módulo: `
    + `el contrato ObservadorVenta.actualizar() se mantendría intacto.`),
  p(`La evidencia de que esta integración efectivamente ocurre —y no solo se describe en la teoría— se `
    + `presenta en la Sección 3.4, con una ejecución real del sistema.`),
];

const seccion2_6 = [
  h2("2.6 Diseño técnico (SDLC — Diseño)"),
  h3("2.6.1 Diagrama Entidad-Relación"),
  p(`El modelo de datos integra las entidades del núcleo del negocio (Cliente, Producto, Venta, `
    + `Detalle_Venta) con las entidades propias de cada módulo satélite (Asiento_Contable del ERP, `
    + `Orden_Compra del SCM y Alerta_CRM del CRM), evidenciando desde el modelo de datos mismo cómo se `
    + `conectan los cuatro subsistemas.`),
  ...figura("diagrama_er.png", 560, 376, "Figura 2. Modelo Entidad-Relación del sistema integrado MerkaExpress."),
  h3("2.6.2 Mockups de interfaz"),
  p(`Se elaboraron bocetos de baja fidelidad de las dos interfaces principales del sistema: el punto `
    + `de venta (uso diario del cajero) y el tablero gerencial (uso directivo). Ambos bocetos ya reflejan `
    + `los campos y KPI reales que produce el sistema implementado en la Fase 2.`),
  ...figura("mockup_pos.png", 520, 332, "Figura 3. Boceto de interfaz — Sistema POS."),
  ...figura("mockup_dashboard.png", 520, 332, "Figura 4. Boceto de interfaz — Dashboard Gerencial."),
  new Paragraph({ children: [new PageBreak()] }),
];

module.exports = [
  h1("2. Diseño Estratégico"),
  ...seccion2_1, spacer(100),
  ...seccion2_2, spacer(100),
  ...seccion2_3, spacer(100),
  ...seccion2_4, spacer(100),
  ...seccion2_5, spacer(100),
  ...seccion2_6,
];
