// scripts_reporte/informe_base.js
// Proyecto Final ISID223 - Transformacion Digital Empresarial (MerkaExpress)
// Helpers + Portada + TOC + Resumen Ejecutivo

const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  Table, TableRow, TableCell, WidthType, ShadingType, BorderStyle,
  ImageRun, PageBreak, TableOfContents, Header, Footer, PageNumber,
  VerticalAlign, LevelFormat, convertInchesToTwip,
} = require("docx");

const RAIZ = path.join(__dirname, "..");
const DIAG = path.join(RAIZ, "diagramas");
const datos = require("./datos_informe.json");

// ---------------------------------------------------------------- paleta --
const NAVY = "1B2A4A", TEAL = "12897E", AMBER = "B9791F", RED = "B03A2E",
      GRAY = "6B7280", LIGHTBG = "EFF2F5", WHITE = "FFFFFF", DARK = "222222";
const CONTENT_W = 9026; // dxa (A4, margen 1in)

// -------------------------------------------------------------- helpers --
const h1 = (text) => new Paragraph({
  heading: HeadingLevel.HEADING_1, spacing: { before: 480, after: 220 },
  border: { bottom: { color: TEAL, space: 4, style: BorderStyle.SINGLE, size: 8 } },
  children: [new TextRun({ text, color: NAVY, bold: true })],
});
const h2 = (text) => new Paragraph({
  heading: HeadingLevel.HEADING_2, spacing: { before: 340, after: 160 },
  children: [new TextRun({ text, color: NAVY, bold: true })],
});
const h3 = (text) => new Paragraph({
  heading: HeadingLevel.HEADING_3, spacing: { before: 240, after: 120 },
  children: [new TextRun({ text, color: TEAL, bold: true })],
});
const p = (text, opts = {}) => new Paragraph({
  spacing: { after: 180, line: 300 }, alignment: AlignmentType.JUSTIFIED,
  children: [new TextRun({ text, size: 22, color: DARK, ...opts })],
});
const pRuns = (runs, opts = {}) => new Paragraph({
  spacing: { after: 180, line: 300 }, alignment: AlignmentType.JUSTIFIED, ...opts,
  children: runs,
});
const bullet = (text, opts = {}) => new Paragraph({
  numbering: { reference: "bullets", level: 0 }, spacing: { after: 90 },
  children: [new TextRun({ text, size: 22, color: DARK, ...opts })],
});
const caption = (text) => new Paragraph({
  alignment: AlignmentType.CENTER, spacing: { after: 260 },
  children: [new TextRun({ text, italics: true, size: 18, color: GRAY })],
});
const mono = (text, opts = {}) => new Paragraph({
  spacing: { after: 20 },
  shading: { type: ShadingType.CLEAR, fill: "1E2530" },
  children: [new TextRun({ text: text || " ", font: "Consolas", size: 16, color: "D8DEE9", ...opts })],
});
const spacer = (hgt = 120) => new Paragraph({ spacing: { after: hgt }, children: [] });

function celda(text, { header = false, width, fill, align = AlignmentType.LEFT, color, bold: b } = {}) {
  return new TableCell({
    width: { size: width, type: WidthType.DXA },
    shading: { type: ShadingType.CLEAR, fill: fill || (header ? NAVY : WHITE) },
    verticalAlign: VerticalAlign.CENTER,
    margins: { top: 90, bottom: 90, left: 110, right: 110 },
    children: [new Paragraph({
      alignment: align,
      children: [new TextRun({
        text: String(text), bold: b !== undefined ? b : header, size: 19,
        color: color || (header ? WHITE : DARK),
      })],
    })],
  });
}

function tabla(headers, rows, pesos) {
  const widths = pesos.map((w) => Math.round(CONTENT_W * w));
  const headerRow = new TableRow({
    tableHeader: true,
    children: headers.map((t, i) => celda(t, { header: true, width: widths[i] })),
  });
  const bodyRows = rows.map((rw, ridx) => new TableRow({
    children: rw.map((t, i) => celda(t, { width: widths[i], fill: ridx % 2 ? LIGHTBG : WHITE })),
  }));
  return new Table({ width: { size: CONTENT_W, type: WidthType.DXA }, columnWidths: widths, rows: [headerRow, ...bodyRows] });
}

function figura(filename, widthPx, heightPx, cap) {
  const data = fs.readFileSync(path.join(DIAG, filename));
  return [
    new Paragraph({
      alignment: AlignmentType.CENTER, spacing: { before: 160, after: 70 },
      children: [new ImageRun({ data, type: "png", transformation: { width: widthPx, height: heightPx } })],
    }),
    caption(cap),
  ];
}

const fmt$ = (n) => "$" + Number(n).toLocaleString("es-EC", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const fmtN = (n) => Number(n).toLocaleString("es-EC");

// -------------------------------------------------- evidencia de consola --
function extraerEvidenciaConsola() {
  const ruta = path.join(RAIZ, "evidencia_integracion_consola.txt");
  const lineas = fs.readFileSync(ruta, "utf-8").split("\n");
  const inicio = lineas.findIndex((l) => l.includes("FASE E |"));
  const fin = lineas.findIndex((l) => l.includes("RESUMEN EJECUTIVO"));
  return lineas.slice(Math.max(inicio - 1, 0), fin - 1);
}

// ============================================================ PORTADA ===
const portada = [
  spacer(1400),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 60 },
    children: [new TextRun({ text: "ESCUELA POLITÉCNICA NACIONAL", bold: true, size: 22, color: GRAY })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 500 },
    children: [new TextRun({ text: "Facultad de Ingeniería de Sistemas — ISID223", size: 20, color: GRAY })] }),

  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 160 },
    children: [new TextRun({ text: "PROYECTO FINAL", bold: true, size: 30, color: NAVY })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 60 },
    children: [new TextRun({ text: "TRANSFORMACIÓN DIGITAL EMPRESARIAL", bold: true, size: 44, color: NAVY })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 500 },
    children: [new TextRun({ text: "Sistema Integrado POS · ERP · SCM · CRM para MerkaExpress", italics: true, size: 24, color: TEAL })] }),

  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 40 },
    children: [new TextRun({ text: "Firma consultora", size: 18, color: GRAY })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 380 },
    children: [new TextRun({ text: "NexoTech Consultores", bold: true, size: 26, color: NAVY })] }),

  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 40 },
    children: [new TextRun({ text: "Cliente (simulación académica)", size: 18, color: GRAY })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 700 },
    children: [new TextRun({ text: "MerkaExpress — Cadena de Minimercados (Quito · Guayaquil · Cuenca)", size: 20, color: DARK })] }),

  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 40 },
    children: [new TextRun({ text: "Integrantes", size: 18, color: GRAY })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 40 },
    children: [new TextRun({ text: "[Nombre completo — usuario GitHub: Keso-pan]", size: 20, color: DARK })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 380 },
    children: [new TextRun({ text: "(completar con los integrantes reales del grupo de trabajo)", italics: true, size: 16, color: GRAY })] }),

  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 20 },
    children: [new TextRun({ text: "Docente: Prof. Iván Carrera — EPN-FIS", size: 20, color: DARK })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: { after: 20 },
    children: [new TextRun({ text: "Periodo académico: 2025-B", size: 20, color: DARK })] }),
  new Paragraph({ alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: "Quito, Ecuador — Julio de 2026", size: 20, color: DARK })] }),

  new Paragraph({ children: [new PageBreak()] }),
];

// ============================================================ TOC ===
// NOTA: se usa un indice ESTATICO (no un campo TOC dinamico) porque los
// campos de Word no se recalculan durante una exportacion headless a PDF
// (LibreOffice) y quedarian en blanco. Las paginas fueron verificadas
// contra el PDF ya generado.
const { TabStopType, TabStopPosition, LeaderType } = require("docx");

function tocEntry(titulo, pagina, { nivel = 0 } = {}) {
  const tamano = nivel === 0 ? 22 : 20;
  return new Paragraph({
    spacing: { after: nivel === 0 ? 140 : 90 },
    indent: { left: nivel === 0 ? 0 : 320 },
    tabStops: [{ type: TabStopType.RIGHT, position: TabStopPosition.MAX, leader: LeaderType.DOT }],
    children: [
      new TextRun({ text: titulo, bold: nivel === 0, size: tamano, color: nivel === 0 ? NAVY : DARK }),
      new TextRun({ text: `\t${pagina}`, bold: nivel === 0, size: tamano, color: nivel === 0 ? NAVY : GRAY }),
    ],
  });
}

const tocSeccion = [
  h1("Contenido"),
  tocEntry("1.  Resumen Ejecutivo", 3),
  tocEntry("2.  Diseño Estratégico", 4),
  tocEntry("2.1  Diagnóstico del negocio", 4, { nivel: 1 }),
  tocEntry("2.2  Análisis de las 5 Fuerzas de Porter", 4, { nivel: 1 }),
  tocEntry("2.3  Cadena de Valor: situación actual vs. propuesta", 5, { nivel: 1 }),
  tocEntry("2.4  Especificación de requerimientos", 6, { nivel: 1 }),
  tocEntry("2.5  Integración empresarial: fundamento teórico", 7, { nivel: 1 }),
  tocEntry("2.6  Diseño técnico (ER y mockups)", 7, { nivel: 1 }),
  tocEntry("3.  Documentación Técnica", 10),
  tocEntry("3.1  Arquitectura de la solución", 10, { nivel: 1 }),
  tocEntry("3.2  Sistema Principal (Core Business)", 10, { nivel: 1 }),
  tocEntry("3.3  Módulos satélite: ERP, SCM y CRM", 11, { nivel: 1 }),
  tocEntry("3.4  Evidencia de integración (Fase 2.3)", 12, { nivel: 1 }),
  tocEntry("4.  Inteligencia de Negocios y Auditoría", 13),
  tocEntry("4.1  Segmentación RFM", 13, { nivel: 1 }),
  tocEntry("4.2  Auditoría web", 14, { nivel: 1 }),
  tocEntry("4.3  Dashboard gerencial", 16, { nivel: 1 }),
  tocEntry("5.  Anexos", 17),
  tocEntry("5.1  Repositorio de código", 17, { nivel: 1 }),
  tocEntry("5.2  Instrucciones de ejecución", 17, { nivel: 1 }),
  tocEntry("5.3  Alcances y limitaciones", 17, { nivel: 1 }),
  tocEntry("5.4  Nota metodológica sobre los datos", 18, { nivel: 1 }),
  new Paragraph({ children: [new PageBreak()] }),
];

// ================================================== 1. RESUMEN EJECUTIVO ===
const d = datos.diagnostico, s = datos.simulacion, r = datos.rfm;
const vip = r.segmentos.find(x => x.segmento === "VIP / Campeones");

const resumenEjecutivo = [
  h1("1. Resumen Ejecutivo"),
  p(`MerkaExpress es una cadena ecuatoriana de minimercados con tres puntos de venta `
    + `(Quito, Guayaquil y Cuenca) que, hasta hoy, ha operado de forma mayoritariamente manual y `
    + `desconectada: cada sucursal registra sus ventas de forma independiente, el control de `
    + `inventario depende de conteos periódicos y la relación con el cliente se limita a una tarjeta `
    + `de membresía sin trazabilidad real de compras. NexoTech Consultores fue contratada para liderar `
    + `su transformación digital mediante la implementación de un ecosistema de información integrado.`),
  p(`Este informe documenta el resultado de dicho proceso en cuatro frentes: (1) un diagnóstico `
    + `estratégico del negocio bajo el modelo de las 5 Fuerzas de Porter y la Cadena de Valor; `
    + `(2) el diseño e implementación de un Sistema Principal de punto de venta (POS) desarrollado en `
    + `Python bajo el paradigma de Programación Orientada a Objetos, con persistencia en archivos CSV; `
    + `(3) tres módulos satélite —ERP financiero, SCM de inventario/proveedores y CRM de relación con `
    + `el cliente— que se integran automáticamente con el sistema principal mediante el patrón de `
    + `diseño Observer, de modo que cada venta desencadena, sin intervención humana, un asiento `
    + `contable, una eventual orden de compra y la actualización del historial del cliente; y `
    + `(4) un modelo de inteligencia de negocios que segmenta a los clientes mediante la metodología `
    + `RFM y los consolida en un tablero de control gerencial.`),
  pRuns([
    new TextRun({ text: `Sobre una simulación de operación de cuatro meses del nuevo sistema (`, size: 22 }),
    new TextRun({ text: `${s.periodo_inicio} – ${s.periodo_fin}`, size: 22, bold: true }),
    new TextRun({ text: `, calibrada con los patrones reales observados en el histórico transaccional `
      + `de la empresa), la solución registró `, size: 22 }),
    new TextRun({ text: `${fmtN(s.n_facturas)} ventas`, size: 22, bold: true, color: TEAL }),
    new TextRun({ text: ` por un total de `, size: 22 }),
    new TextRun({ text: `${fmt$(s.ingresos_totales)}`, size: 22, bold: true, color: TEAL }),
    new TextRun({ text: `, generó automáticamente `, size: 22 }),
    new TextRun({ text: `${fmtN(s.n_asientos_contables)} asientos contables`, size: 22, bold: true }),
    new TextRun({ text: ` y `, size: 22 }),
    new TextRun({ text: `${fmtN(s.n_ordenes_compra)} órdenes de compra`, size: 22, bold: true }),
    new TextRun({ text: `, e identificó `, size: 22 }),
    new TextRun({ text: `${fmtN(s.en_riesgo_primera_consulta)} clientes en riesgo de deserción`, size: 22, bold: true, color: RED }),
    new TextRun({ text: ` mediante una consulta automatizada del módulo CRM. La segmentación RFM reveló que el `
      + `segmento `, size: 22 }),
    new TextRun({ text: `“VIP / Campeones” (${vip.pct_clientes}% de los clientes)`, size: 22, bold: true }),
    new TextRun({ text: ` concentra el `, size: 22 }),
    new TextRun({ text: `${vip.pct_ingresos}% de los ingresos`, size: 22, bold: true }),
    new TextRun({ text: `, un hallazgo que sustenta directamente las recomendaciones de fidelización de `
      + `este informe.`, size: 22 }),
  ]),
  p(`Todo el código fuente descrito en este documento es funcional y fue ejecutado para generar las `
    + `cifras aquí presentadas; no se trata de un diseño únicamente conceptual (véase la Sección 3.4 y `
    + `los Anexos).`),
  new Paragraph({ children: [new PageBreak()] }),
];

module.exports = { portada, tocSeccion, resumenEjecutivo, h1, h2, h3, p, pRuns, bullet, caption, mono,
  spacer, tabla, figura, fmt$, fmtN, extraerEvidenciaConsola, NAVY, TEAL, AMBER, RED, GRAY, LIGHTBG,
  WHITE, DARK, CONTENT_W, datos, RAIZ, DIAG };
