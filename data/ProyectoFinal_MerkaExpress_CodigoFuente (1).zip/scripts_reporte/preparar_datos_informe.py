# -*- coding: utf-8 -*-
"""
scripts_reporte/preparar_datos_informe.py
Consolida en un unico JSON todas las cifras, tablas y textos numericos que
el informe final necesita, para que el generador del .docx no tenga que
hardcodear ningun resultado a mano.
"""
import json
import os
import pandas as pd

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(RAIZ, "data")


def diagnostico_historico():
    df = pd.read_csv(os.path.join(DATA, "SuperMarket_Analysis.csv"), encoding="utf-8-sig")
    df["Date"] = pd.to_datetime(df["Date"])
    mapa_sucursal = {"Alex": "Alex (Yangon)", "Cairo": "Cairo (Mandalay)", "Giza": "Giza (Naypyitaw)"}
    df["Sucursal"] = df["Branch"].map(mapa_sucursal)

    por_sucursal = df.groupby("Sucursal")["Sales"].agg(["count", "sum"]).round(2)
    por_linea = df.groupby("Product line")["Sales"].agg(["count", "sum", "mean"]).round(2).sort_values("sum", ascending=False)
    por_pago = df["Payment"].value_counts()
    por_tipo_cliente = df["Customer type"].value_counts()

    return {
        "n_transacciones": int(len(df)),
        "fecha_min": df["Date"].min().strftime("%d/%m/%Y"),
        "fecha_max": df["Date"].max().strftime("%d/%m/%Y"),
        "ventas_totales": round(float(df["Sales"].sum()), 2),
        "ticket_promedio": round(float(df["Sales"].mean()), 2),
        "rating_promedio": round(float(df["Rating"].mean()), 2),
        "n_sucursales": int(df["Sucursal"].nunique()),
        "n_lineas_producto": int(df["Product line"].nunique()),
        "pct_member": round(float((df["Customer type"] == "Member").mean() * 100), 1),
        "por_sucursal": [
            {"sucursal": s, "transacciones": int(r["count"]), "ventas": round(float(r["sum"]), 2)}
            for s, r in por_sucursal.iterrows()
        ],
        "por_linea": [
            {"linea": l, "transacciones": int(r["count"]), "ventas": round(float(r["sum"]), 2),
             "ticket_promedio": round(float(r["mean"]), 2)}
            for l, r in por_linea.iterrows()
        ],
        "por_pago": {k: int(v) for k, v in por_pago.items()},
        "por_tipo_cliente": {k: int(v) for k, v in por_tipo_cliente.items()},
    }


def resultados_simulacion():
    ventas = pd.read_csv(os.path.join(DATA, "ventas_sistema.csv"))
    facturas = ventas.groupby(["id_venta", "fecha"], as_index=False)["subtotal_linea"].sum()
    facturas["total"] = (facturas["subtotal_linea"] * 1.15).round(2)

    contab = pd.read_csv(os.path.join(DATA, "contabilidad_asientos.csv"))
    caja = pd.read_csv(os.path.join(DATA, "caja_chica.csv"))
    ordenes = pd.read_csv(os.path.join(DATA, "ordenes_compra.csv"))
    alertas = pd.read_csv(os.path.join(DATA, "alertas_crm.csv"))
    clientes = pd.read_csv(os.path.join(DATA, "clientes_final.csv"))
    productos = pd.read_csv(os.path.join(DATA, "productos_final.csv"))

    ultima_fecha_alerta = alertas["fecha_consulta"].max()
    primera_fecha_alerta = alertas["fecha_consulta"].min()
    en_riesgo_final = alertas[alertas["fecha_consulta"] == ultima_fecha_alerta]["id_cliente"].nunique()
    en_riesgo_inicial = alertas[alertas["fecha_consulta"] == primera_fecha_alerta]["id_cliente"].nunique()

    por_proveedor = ordenes.groupby("proveedor")["id_orden"].count().sort_values(ascending=False)
    ordenes_recibidas = int((ordenes["estado"] == "Recibida").sum())

    return {
        "periodo_inicio": "01/03/2026",
        "periodo_fin": "30/06/2026",
        "n_clientes_simulados": int(len(clientes)),
        "n_productos_catalogo": int(len(productos)),
        "n_facturas": int(len(facturas)),
        "ingresos_totales": round(float(facturas["total"].sum()), 2),
        "ticket_promedio_sim": round(float(facturas["total"].mean()), 2),
        "n_asientos_contables": int(contab["id_asiento"].nunique()),
        "saldo_caja_final": round(float(caja["saldo_caja"].iloc[-1]), 2),
        "saldo_caja_inicial": round(float(caja["saldo_caja"].iloc[0]), 2),
        "n_ordenes_compra": int(len(ordenes)),
        "n_ordenes_recibidas": ordenes_recibidas,
        "monto_total_ordenes": round(float(ordenes["costo_estimado"].sum()), 2),
        "por_proveedor": [{"proveedor": p, "ordenes": int(v)} for p, v in por_proveedor.items()],
        "en_riesgo_primera_consulta": int(en_riesgo_inicial),
        "en_riesgo_segunda_consulta": int(en_riesgo_final),
        "fecha_primera_consulta": primera_fecha_alerta,
        "fecha_segunda_consulta": ultima_fecha_alerta,
    }


def resultados_rfm():
    rfm = pd.read_csv(os.path.join(DATA, "rfm_resultados.csv"))
    resumen = pd.read_csv(os.path.join(DATA, "rfm_resumen_segmentos.csv"))
    resumen = resumen.sort_values("gasto_total", ascending=False)

    top_vip = rfm[rfm["segmento"] == "VIP / Campeones"].sort_values("monetario", ascending=False).head(5)

    return {
        "n_clientes_analizados": int(len(rfm)),
        "segmentos": [
            {"segmento": row["segmento"], "clientes": int(row["clientes"]),
             "pct_clientes": float(row["pct_clientes"]), "gasto_total": round(float(row["gasto_total"]), 2),
             "pct_ingresos": float(row["pct_ingresos"]), "gasto_promedio": round(float(row["gasto_promedio"]), 2),
             "frecuencia_promedio": float(row["frecuencia_promedio"]),
             "recencia_promedio": float(row["recencia_promedio"])}
            for _, row in resumen.iterrows()
        ],
        "top_vip": [
            {"cliente": row["id_cliente"], "gasto": round(float(row["monetario"]), 2),
             "frecuencia": int(row["frecuencia"])}
            for _, row in top_vip.iterrows()
        ],
    }


def main():
    datos = {
        "diagnostico": diagnostico_historico(),
        "simulacion": resultados_simulacion(),
        "rfm": resultados_rfm(),
    }
    ruta = os.path.join(RAIZ, "scripts_reporte", "datos_informe.json")
    with open(ruta, "w", encoding="utf-8") as f:
        json.dump(datos, f, ensure_ascii=False, indent=2)
    print("Generado:", ruta)
    print(json.dumps(datos, ensure_ascii=False, indent=2)[:2000])


if __name__ == "__main__":
    main()
