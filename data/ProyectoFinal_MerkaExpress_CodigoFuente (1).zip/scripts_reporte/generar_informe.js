// scripts_reporte/generar_informe.js
// Ensamblaje final del Informe Final (.docx) - Proyecto Final ISID223 (MerkaExpress)

const fs = require("fs");
const path = require("path");
const {
  Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType,
  Header, Footer, PageNumber, LevelFormat, convertInchesToTwip, BorderStyle,
} = require("docx");

const base = require("./informe_base");
const seccion2 = require("./informe_seccion2");
const seccion3 = require("./informe_seccion3");
const seccion4 = require("./informe_seccion4");
const seccion5 = require("./informe_seccion5");

const { NAVY, GRAY, TEAL } = base;

const header = new Header({
  children: [
    new Paragraph({
      alignment: AlignmentType.RIGHT,
      border: { bottom: { color: "D9DEE4", space: 4, style: BorderStyle.SINGLE, size: 4 } },
      children: [new TextRun({
        text: "MerkaExpress — Proyecto Final ISID223 — Transformación Digital Empresarial",
        size: 15, color: GRAY, italics: true,
      })],
    }),
  ],
});

const footer = new Footer({
  children: [
    new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [
        new TextRun({ text: "NexoTech Consultores  ·  Página ", size: 15, color: GRAY }),
        new TextRun({ children: [PageNumber.CURRENT], size: 15, color: GRAY }),
        new TextRun({ text: " de ", size: 15, color: GRAY }),
        new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 15, color: GRAY }),
      ],
    }),
  ],
});

const doc = new Document({
  creator: "NexoTech Consultores",
  title: "Proyecto Final ISID223 - Transformación Digital Empresarial - MerkaExpress",
  description: "Informe final: Sistema Integrado POS-ERP-SCM-CRM para MerkaExpress",
  styles: {
    default: {
      document: { run: { font: "Calibri", size: 22, color: "222222" } },
    },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 32, bold: true, color: NAVY, font: "Calibri" },
        paragraph: { spacing: { before: 480, after: 220 } } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 26, bold: true, color: NAVY, font: "Calibri" },
        paragraph: { spacing: { before: 340, after: 160 } } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 23, bold: true, color: TEAL, font: "Calibri" },
        paragraph: { spacing: { before: 240, after: 120 } } },
    ],
  },
  numbering: {
    config: [
      {
        reference: "bullets",
        levels: [{
          level: 0, format: LevelFormat.BULLET, text: "•", alignment: AlignmentType.LEFT,
          style: { paragraph: { indent: { left: convertInchesToTwip(0.28), hanging: convertInchesToTwip(0.18) } } },
        }],
      },
    ],
  },
  sections: [
    {
      properties: {
        page: {
          margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 },
        },
        titlePage: true,
      },
      headers: { default: new Header({ children: [new Paragraph({ children: [] })] }) },
      footers: { default: new Footer({ children: [new Paragraph({ children: [] })] }) },
      children: [...base.portada],
    },
    {
      properties: {
        page: { margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 } },
      },
      headers: { default: header },
      footers: { default: footer },
      children: [
        ...base.tocSeccion,
        ...base.resumenEjecutivo,
        ...seccion2,
        ...seccion3,
        ...seccion4,
        ...seccion5,
      ],
    },
  ],
});

Packer.toBuffer(doc).then((buffer) => {
  const outPath = path.join(base.RAIZ, "Informe_Final_MerkaExpress.docx");
  fs.writeFileSync(outPath, buffer);
  console.log("Generado:", outPath, "(" + (buffer.length / 1024).toFixed(0) + " KB)");
});
