# MerkaExpress — Transformación Digital Empresarial
### Proyecto Final · ISID223 Introducción a los Sistemas de Información (2025-B) · EPN
**Firma consultora:** NexoTech Consultores | **Prof.** Iván Carrera — EPN-FIS

Sistema integrado **TPS (POS) · ERP · SCM · CRM** para MerkaExpress, una cadena de
minimercados con sucursales reales de `SuperMarket_Analysis.csv` (Alex/Yangon,
Cairo/Mandalay, Giza/Naypyitaw), desarrollado en Python bajo Programación Orientada a
Objetos. Incluye una **aplicación de escritorio modular** (Tkinter) pensada para abrirse
y ejecutarse directamente en **PyCharm**.

> **100% datos reales, cero datos inventados:** el catálogo son las 6 líneas de producto
> reales del CSV, las sucursales y ciudades son las que trae el archivo (no se asume
> ninguna geografía distinta), la tarifa de impuesto es la misma del histórico (5%, columna
> "Tax 5%"), y las 1.000 transacciones que el sistema reproduce al arrancar son las 1.000
> filas reales (mismo precio, cantidad, fecha/hora y costo de cada una). Lo único que se
> reconstruye es el `id_cliente` (el archivo no trae uno — ver la Sección 5.4 del informe o
> el módulo `datos_maestros.py` para la metodología, ya validada). NexoTech Consultores
> (equipo EPN, Ecuador) es la firma que construye el sistema; MerkaExpress es el cliente
> internacional que lo contrata — el sistema no asume que el cliente opera en Ecuador.

## Aplicación de escritorio

```
python3 main_app.py
```

Abre una ventana con 6 módulos en pestañas:

| Pestaña | Qué hace |
|---|---|
| Inicio | KPIs generales del sistema (ingresos, caja chica, clientes, órdenes SCM) |
| TPS · Punto de Venta | Registra ventas nuevas (cliente real + producto + cantidad); panel de "Actividad en vivo" que muestra, en tiempo real, cómo ERP/SCM/CRM reaccionan automáticamente |
| ERP · Financiero | Saldo de caja chica y libro completo de asientos contables (partida doble, verificación Debe=Haber) |
| SCM · Inventario | Stock por línea de producto (con alerta visual si está bajo el mínimo), órdenes de compra automáticas, botón para simular la recepción de un pedido |
| CRM · Clientes | Botón para ejecutar la consulta automatizada de "clientes en riesgo de deserción"; buscador de cliente con ficha individual (historial, gasto total) |
| Dashboard BI | Tablero gerencial embebido (Matplotlib dentro de la misma ventana): ventas, segmentación RFM, órdenes SCM por proveedor, clientes en riesgo — se recalcula en vivo con el botón "Actualizar" |

Al arrancar, la aplicación reproduce automáticamente el 100% del histórico real (tarda ~1-2
segundos) antes de mostrar la interfaz — es la misma lógica de `main_demo.py`, encapsulada en
`gui/motor.py` para que todas las pestañas compartan un único estado en vivo.

### Cómo abrir en PyCharm
1. `File → Open...` y selecciona esta carpeta (`proyecto_final/`) como raíz del proyecto.
2. Configura un intérprete (`File → Settings → Project → Python Interpreter`), crea un venv si
   no tienes uno, e instala `requirements.txt` (PyCharm lo detecta y ofrece instalarlo solo).
3. **Linux:** si `import tkinter` falla, instala el paquete de sistema (no es un paquete pip):
   `sudo apt-get install python3-tk`. En Windows/Mac, tkinter ya viene incluido con Python.
4. Clic derecho sobre `main_app.py` → `Run 'main_app'`.

## Estructura del repositorio

```
proyecto_final/
├── main_app.py                     Aplicación de escritorio (GUI) — punto de entrada
├── main_demo.py                    Script de consola: simulación + demo de integración (Fase 2.3)
├── datos_maestros.py               Catálogo (6 líneas reales) + reconstrucción de clientes
├── requirements.txt
│
├── gui/
│   ├── motor.py                    Motor: única fuente de verdad del estado en vivo del sistema
│   ├── app.py                      Ventana principal (navegación por pestañas)
│   ├── estilos.py                  Paleta de colores y estilos ttk compartidos
│   ├── widgets.py                  Combobox con autocompletado, tablas reutilizables
│   └── tab_inicio.py / tab_tps.py / tab_erp.py / tab_scm.py / tab_crm.py / tab_dashboard.py
│
├── core/
│   ├── modelos.py                  Cliente, Producto, Venta, DetalleVenta (POO)
│   └── sistema_pos.py              SistemaPOS (TPS / Core Business) + patrón Observer
│
├── modulos/
│   ├── modulo_erp.py               Asientos contables (partida doble) + caja chica
│   ├── modulo_scm.py               Órdenes de compra automáticas por punto de reorden
│   └── modulo_crm.py               Detección automatizada de clientes en riesgo
│
├── bi/
│   ├── analisis_rfm.py             Segmentación RFM (Fase 3.1)
│   └── dashboard.py                Generación del dashboard como imagen (versión consola)
│
├── diagramas/                      ER, arquitectura, cadena de valor, mockups (.png)
├── colab/                          Notebooks para Google Colab (ver más abajo)
├── data/                           CSV generados en cada ejecución (se regeneran solos)
└── scripts_reporte/                Generador del informe final (.docx/.pdf)
```

## Otras formas de ejecutar el proyecto

```bash
pip install -r requirements.txt

python3 main_app.py               # Aplicación de escritorio (recomendado)
python3 main_demo.py              # Versión de consola con el log de integración completo
python3 bi/analisis_rfm.py        # Segmentación RFM por separado
python3 bi/dashboard.py           # Dashboard como imagen PNG (sin GUI)
python3 diagramas/generar_diagramas.py   # Regenerar ER / arquitectura / cadena de valor / mockups
```

## Dashboard alternativo 100% en datos reales (Google Colab)

`colab/MerkaExpress_Dashboard_Colab.ipynb` (BI exploratorio directo sobre el CSV histórico) y
`colab/MerkaExpress_Dashboard_Fase4_Colab.ipynb` (dashboard gerencial de la Fase 4, alimentado
por los CSV que produce `main_demo.py`) — ambos pensados para Google Colab, ver instrucciones
dentro de cada notebook.

> Nota: estos notebooks y el informe PDF/Word de fases anteriores todavía muestran la
> geografía y la tarifa de impuesto antiguas (asumían un cliente ecuatoriano con IVA del
> 15%); si los necesitas actualizados con la geografía y el 5% reales, pídelo y se regeneran.

## Nota metodológica sobre los datos

El histórico (`SuperMarket_Analysis.csv`) se usa al 100% (todas sus filas, sin muestreo)
tanto para el diagnóstico (Fase 1) como para poblar el sistema en vivo (Fase 2 en adelante).
La única reconstrucción necesaria —documentada y verificable en `datos_maestros.py`— es el
identificador de cliente, inexistente en el archivo original. Sucursales, ciudades, línea de
producto y tarifa de impuesto son exactamente las del archivo fuente.

## Autores
Integrantes: *(completar con los nombres reales del equipo)* — GitHub: `Keso-pan`
