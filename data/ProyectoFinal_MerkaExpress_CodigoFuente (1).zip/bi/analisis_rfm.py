# -*- coding: utf-8 -*-
"""
bi/analisis_rfm.py
Proyecto Final ISID223 - Transformacion Digital Empresarial (MerkaExpress)

Fase 3.1 - Segmentacion RFM (Recencia, Frecuencia, Monetario).

Toma el historico de transacciones generado por el Sistema POS
(data/ventas_sistema.csv) -que reproduce el 100% de las 1000 transacciones
reales de SuperMarket_Analysis.csv mas 3 ventas de demostracion (Fase 2.3)- y
calcula el puntaje RFM sobre el 100% de los 606 clientes reconstruidos
(ver datos_maestros.py para la metodologia de reconstruccion).

Ejecutar desde la raiz del proyecto:  python3 bi/analisis_rfm.py
Genera: data/rfm_resultados.csv
"""

import os
import pandas as pd

RUTA_DATOS = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
FECHA_REFERENCIA = "2019-03-31"   # dia siguiente al escenario de demostracion (Fase 2.3)
TASA_IMPUESTO = 0.05   # misma tarifa plana ("Tax 5%") del historico real


def cargar_facturas():
    ventas = pd.read_csv(os.path.join(RUTA_DATOS, "ventas_sistema.csv"))
    facturas = (ventas.groupby(["id_venta", "id_cliente", "fecha"], as_index=False)
                       ["subtotal_linea"].sum()
                       .rename(columns={"subtotal_linea": "subtotal"}))
    facturas["total"] = (facturas["subtotal"] * (1 + TASA_IMPUESTO)).round(2)
    return facturas


def calcular_rfm(facturas: pd.DataFrame, fecha_referencia: str) -> pd.DataFrame:
    fecha_ref = pd.Timestamp(fecha_referencia)
    facturas["fecha"] = pd.to_datetime(facturas["fecha"])

    rfm = facturas.groupby("id_cliente").agg(
        ultima_compra=("fecha", "max"),
        frecuencia=("id_venta", "nunique"),
        monetario=("total", "sum"),
    ).reset_index()
    rfm["recencia"] = (fecha_ref - rfm["ultima_compra"]).dt.days
    rfm["monetario"] = rfm["monetario"].round(2)

    # Puntajes 1-5. R y M usan quintiles (distribucion continua, sin empates
    # masivos). F usa un mapeo DIRECTO en vez de quintiles: con 452 de 606
    # clientes en frecuencia==1, pd.qcut() por rango reparte ese empate de
    # forma arbitraria entre varios puntajes (verificado: los mismos 452
    # clientes con frecuencia==1 quedaban repartidos entre F_score 1 a 4).
    # Un mapeo directo sobre el rango real observado (1 a 8 compras) es mas
    # honesto que forzar quintiles sobre una variable discreta y concentrada.
    rfm["R_score"] = pd.qcut(rfm["recencia"].rank(method="first", ascending=False), 5,
                              labels=[1, 2, 3, 4, 5]).astype(int)
    rfm["F_score"] = rfm["frecuencia"].apply(_score_frecuencia)
    rfm["M_score"] = pd.qcut(rfm["monetario"].rank(method="first"), 5,
                              labels=[1, 2, 3, 4, 5]).astype(int)
    rfm["RFM_total"] = rfm["R_score"] + rfm["F_score"] + rfm["M_score"]

    rfm["segmento"] = rfm.apply(_etiquetar_segmento, axis=1)
    return rfm


def _score_frecuencia(f: int) -> int:
    if f <= 1:
        return 1
    if f == 2:
        return 2
    if f == 3:
        return 3
    if f <= 5:
        return 4
    return 5


def _etiquetar_segmento(row) -> str:
    r, f, m = row["R_score"], row["F_score"], row["M_score"]
    if r >= 4 and f >= 4 and m >= 4:
        return "VIP / Campeones"
    if r <= 2 and f >= 4 and m >= 4:
        return "No Perder (alto valor inactivo)"
    if f >= 4 and r >= 3:
        return "Clientes Fieles"
    if r <= 2 and f >= 3:
        return "En Riesgo"
    if r >= 4 and f <= 2:
        return "Nuevos / Prometedores"
    if r <= 2 and f <= 2:
        return "Hibernando / Perdidos"
    return "Regulares"


def validar_contra_diseno(rfm: pd.DataFrame) -> pd.DataFrame:
    """Cruza el segmento RFM obtenido contra el tipo de cliente real
    (Member/Normal). No es una 'validacion' de un diseno sintetico -toda la
    base es real-; es una lectura honesta de que tan bien separa el modelo
    a los clientes con relacion de fidelizacion real (Member) de las compras
    anonimas de un solo evento (Normal)."""
    ruta_perfiles = os.path.join(RUTA_DATOS, "perfil_diseno_simulacion.csv")
    if not os.path.exists(ruta_perfiles):
        return pd.DataFrame()
    perfiles = pd.read_csv(ruta_perfiles)
    perfiles["tipo"] = perfiles["perfil_diseno"].str.split(" ").str[0]  # "Member"/"Normal"
    cruce = rfm.merge(perfiles, on="id_cliente", how="left")
    tabla = pd.crosstab(cruce["segmento"], cruce["tipo"])
    tabla["Total"] = tabla.sum(axis=1)
    return tabla.sort_values("Total", ascending=False)


def resumen_por_segmento(rfm: pd.DataFrame) -> pd.DataFrame:
    resumen = rfm.groupby("segmento").agg(
        clientes=("id_cliente", "count"),
        gasto_promedio=("monetario", "mean"),
        gasto_total=("monetario", "sum"),
        frecuencia_promedio=("frecuencia", "mean"),
        recencia_promedio=("recencia", "mean"),
    ).round(2).sort_values("gasto_total", ascending=False)
    resumen["pct_clientes"] = (resumen["clientes"] / resumen["clientes"].sum() * 100).round(1)
    resumen["pct_ingresos"] = (resumen["gasto_total"] / resumen["gasto_total"].sum() * 100).round(1)
    return resumen


def main():
    facturas = cargar_facturas()
    rfm = calcular_rfm(facturas, FECHA_REFERENCIA)

    salida = os.path.join(RUTA_DATOS, "rfm_resultados.csv")
    rfm.sort_values("RFM_total", ascending=False).to_csv(salida, index=False)

    print("=" * 78)
    print(" FASE 3.1 | SEGMENTACION RFM - MerkaExpress (100% de los clientes reconstruidos)")
    print("=" * 78)
    print(f"\nClientes analizados: {len(rfm)}  |  Fecha de corte: {FECHA_REFERENCIA}")
    print(f"Facturas procesadas: {len(facturas)}  |  Ingresos totales: "
          f"${facturas['total'].sum():,.2f}")
    print(f"Verificacion -> suma de 'frecuencia' de todos los clientes: {int(rfm['frecuencia'].sum())} "
          f"(debe igualar el numero de facturas: {len(facturas)})\n")

    resumen = resumen_por_segmento(rfm)
    print(resumen.to_string())

    print("\n--- Composicion de cada segmento por tipo real de cliente (Member vs. Normal) ---")
    tabla_val = validar_contra_diseno(rfm)
    if not tabla_val.empty:
        print(tabla_val.to_string())

    resumen.to_csv(os.path.join(RUTA_DATOS, "rfm_resumen_segmentos.csv"))
    print(f"\nArchivo generado: {salida}")
    return rfm, resumen


if __name__ == "__main__":
    main()
