# -*- coding: utf-8 -*-
"""
bi/dashboard.py
Proyecto Final ISID223 - Transformacion Digital Empresarial (MerkaExpress)

Fase 4.1 - Dashboard Gerencial.
Genera un tablero de control compuesto (PNG) con:
  1) Evolucion temporal de ventas (semanal)
  2) Segmentacion RFM (Fase 3)
  3) KPI de Inventario/SCM: ordenes de compra generadas por proveedor
  4) Panel de alertas CRM: clientes en riesgo de desercion

Ejecutar desde la raiz del proyecto:  python3 bi/dashboard.py
Genera: diagramas/dashboard_gerencial.png
"""

import os
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib import gridspec

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RUTA_DATOS = os.path.join(RAIZ, "data")
RUTA_SALIDA = os.path.join(RAIZ, "diagramas")
os.makedirs(RUTA_SALIDA, exist_ok=True)

# --- Paleta corporativa ---
NAVY = "#1B2A4A"
TEAL = "#12897E"
AMBER = "#E8A33D"
RED = "#C4432B"
GRAY = "#6B7280"
LIGHT_BG = "#F4F6F8"
GRID = "#D9DEE4"

COLOR_SEGMENTO = {
    "VIP / Campeones": TEAL,
    "Clientes Fieles": "#3F8F63",
    "Regulares": "#7CA8C4",
    "Nuevos / Prometedores": AMBER,
    "En Riesgo": "#D98A3D",
    "No Perder (alto valor inactivo)": "#8E3B46",
    "Hibernando / Perdidos": GRAY,
}

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "axes.edgecolor": GRID,
    "axes.linewidth": 0.8,
    "text.color": NAVY,
    "axes.labelcolor": NAVY,
    "xtick.color": GRAY,
    "ytick.color": GRAY,
})


def cargar_datos():
    ventas = pd.read_csv(os.path.join(RUTA_DATOS, "ventas_sistema.csv"), parse_dates=["fecha"])
    facturas = ventas.groupby(["id_venta", "fecha"], as_index=False)["subtotal_linea"].sum()
    facturas["total"] = (facturas["subtotal_linea"] * 1.15).round(2)

    rfm_resumen = pd.read_csv(os.path.join(RUTA_DATOS, "rfm_resumen_segmentos.csv"))
    ordenes = pd.read_csv(os.path.join(RUTA_DATOS, "ordenes_compra.csv"))
    alertas = pd.read_csv(os.path.join(RUTA_DATOS, "alertas_crm.csv"))
    clientes = pd.read_csv(os.path.join(RUTA_DATOS, "clientes_final.csv"))
    return facturas, rfm_resumen, ordenes, alertas, clientes


def panel_kpis(fig, gs, facturas, alertas, clientes, ordenes):
    ax = fig.add_subplot(gs[0, :])
    ax.axis("off")

    ingresos_totales = facturas["total"].sum()
    ticket_promedio = facturas["total"].mean()
    ultima_fecha_alerta = alertas["fecha_consulta"].max()
    en_riesgo_actual = alertas[alertas["fecha_consulta"] == ultima_fecha_alerta]["id_cliente"].nunique()
    ordenes_generadas = len(ordenes)

    kpis = [
        ("INGRESOS TOTALES", f"${ingresos_totales:,.0f}", TEAL),
        ("TICKET PROMEDIO", f"${ticket_promedio:,.2f}", NAVY),
        ("CLIENTES ACTIVOS", f"{len(clientes):,}", AMBER),
        ("CLIENTES EN RIESGO", f"{en_riesgo_actual:,}", RED),
        ("ÓRDENES A PROVEEDORES", f"{ordenes_generadas:,}", GRAY),
    ]
    n = len(kpis)
    for i, (label, valor, color) in enumerate(kpis):
        x0 = i / n
        ax.add_patch(plt.Rectangle((x0 + 0.006, 0.05), 1 / n - 0.012, 0.9,
                                    transform=ax.transAxes, facecolor="white",
                                    edgecolor=GRID, linewidth=1.0, zorder=1))
        ax.add_patch(plt.Rectangle((x0 + 0.006, 0.05), 0.012, 0.9,
                                    transform=ax.transAxes, facecolor=color,
                                    edgecolor="none", zorder=2))
        ax.text(x0 + 0.05, 0.66, valor, transform=ax.transAxes, fontsize=17,
                fontweight="bold", color=NAVY, va="center", ha="left", zorder=3)
        ax.text(x0 + 0.05, 0.26, label, transform=ax.transAxes, fontsize=8.3,
                color=GRAY, va="center", ha="left", zorder=3, fontweight="bold")
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)


def panel_ventas(fig, gs, facturas):
    ax = fig.add_subplot(gs[1, 0:2])
    semanal = facturas.set_index("fecha")["total"].resample("W-MON").sum()
    ax.fill_between(semanal.index, semanal.values, color=TEAL, alpha=0.15)
    ax.plot(semanal.index, semanal.values, color=TEAL, linewidth=2.2, marker="o", markersize=4)
    ax.set_title("Ventas — evolución semanal (Sistema POS)", fontsize=11, fontweight="bold",
                 color=NAVY, loc="left")
    ax.set_ylabel("Ventas ($)", fontsize=9)
    ax.xaxis.set_major_formatter(mdates.DateFormatter("%d-%b"))
    ax.xaxis.set_major_locator(mdates.WeekdayLocator(interval=2))
    ax.grid(axis="y", color=GRID, linewidth=0.7)
    ax.set_axisbelow(True)
    for spine in ["top", "right"]:
        ax.spines[spine].set_visible(False)
    plt.setp(ax.get_xticklabels(), rotation=0, fontsize=8)


def panel_rfm(fig, gs, rfm_resumen):
    ax = fig.add_subplot(gs[1, 2])
    rfm_resumen = rfm_resumen.sort_values("clientes")
    colores = [COLOR_SEGMENTO.get(s, GRAY) for s in rfm_resumen["segmento"]]
    barras = ax.barh(rfm_resumen["segmento"], rfm_resumen["clientes"], color=colores, height=0.62)
    for barra, pct in zip(barras, rfm_resumen["pct_ingresos"]):
        ax.text(barra.get_width() + 0.6, barra.get_y() + barra.get_height() / 2,
                f"{int(barra.get_width())} cli · {pct:.0f}% ing.", va="center", fontsize=7.6,
                color=NAVY)
    ax.set_title("Segmentación RFM de clientes", fontsize=11, fontweight="bold",
                 color=NAVY, loc="left")
    ax.set_xlabel("N.º de clientes", fontsize=8.5)
    ax.tick_params(axis="y", labelsize=8)
    ax.set_xlim(0, rfm_resumen["clientes"].max() * 1.45)
    for spine in ["top", "right"]:
        ax.spines[spine].set_visible(False)
    ax.grid(axis="x", color=GRID, linewidth=0.7)
    ax.set_axisbelow(True)


def panel_scm(fig, gs, ordenes):
    ax = fig.add_subplot(gs[2, 0])
    por_prov = ordenes.groupby("proveedor")["id_orden"].count().sort_values()
    ax.barh(por_prov.index, por_prov.values, color=AMBER, height=0.55)
    ax.set_title("SCM — Órdenes de compra automáticas por proveedor", fontsize=10.5,
                 fontweight="bold", color=NAVY, loc="left")
    ax.set_xlabel("N.º de órdenes generadas", fontsize=8.5)
    ax.tick_params(axis="y", labelsize=7.6)
    for spine in ["top", "right"]:
        ax.spines[spine].set_visible(False)
    ax.grid(axis="x", color=GRID, linewidth=0.7)
    ax.set_axisbelow(True)


def panel_crm(fig, gs, alertas):
    ax = fig.add_subplot(gs[2, 1:3])
    ax.axis("off")
    ultima_fecha = alertas["fecha_consulta"].max()
    top = (alertas[alertas["fecha_consulta"] == ultima_fecha]
           .sort_values("dias_inactividad", ascending=False).head(6))

    ax.add_patch(plt.Rectangle((0, 0), 1, 1, transform=ax.transAxes, facecolor="#FBEEEC",
                                edgecolor=RED, linewidth=1.1))
    ax.text(0.02, 0.90, "CRM — Alerta: Clientes en Riesgo de Deserción", fontsize=10.5,
            fontweight="bold", color=RED, transform=ax.transAxes, va="top")
    ax.text(0.02, 0.76, f"Consulta automatizada · corte {ultima_fecha} · umbral 30 días de inactividad",
            fontsize=8, color=GRAY, transform=ax.transAxes, va="top", style="italic")

    y = 0.58
    ax.text(0.02, y, "Cliente", fontsize=8.3, fontweight="bold", color=NAVY, transform=ax.transAxes)
    ax.text(0.62, y, "Días inactivo", fontsize=8.3, fontweight="bold", color=NAVY, transform=ax.transAxes)
    y -= 0.11
    for _, fila in top.iterrows():
        ax.text(0.02, y, f"{fila['nombre']}  ({fila['id_cliente']})", fontsize=8.2,
                color=NAVY, transform=ax.transAxes)
        ax.text(0.66, y, f"{int(fila['dias_inactividad'])}", fontsize=8.2,
                color=RED, fontweight="bold", transform=ax.transAxes)
        y -= 0.078


def generar_dashboard():
    facturas, rfm_resumen, ordenes, alertas, clientes = cargar_datos()

    fig = plt.figure(figsize=(14, 9.2), facecolor="white")
    fig.suptitle("MerkaExpress — Tablero de Control Gerencial", fontsize=17,
                 fontweight="bold", color=NAVY, x=0.02, ha="left", y=0.985)
    fig.text(0.02, 0.955, "Sistema Integrado POS · ERP · SCM · CRM   |   Generado automáticamente "
                          "a partir de datos transaccionales en tiempo real",
             fontsize=9, color=GRAY, ha="left")

    gs = gridspec.GridSpec(3, 3, height_ratios=[0.62, 1.35, 1.15], hspace=0.62, wspace=0.35,
                            top=0.90, bottom=0.05, left=0.045, right=0.985)

    panel_kpis(fig, gs, facturas, alertas, clientes, ordenes)
    panel_ventas(fig, gs, facturas)
    panel_rfm(fig, gs, rfm_resumen)
    panel_scm(fig, gs, ordenes)
    panel_crm(fig, gs, alertas)

    salida = os.path.join(RUTA_SALIDA, "dashboard_gerencial.png")
    fig.savefig(salida, dpi=200, facecolor="white", bbox_inches="tight")
    plt.close(fig)
    print(f"Dashboard generado: {salida}")
    return salida


if __name__ == "__main__":
    generar_dashboard()
