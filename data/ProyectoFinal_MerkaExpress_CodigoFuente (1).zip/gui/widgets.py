# -*- coding: utf-8 -*-
"""gui/widgets.py — Widgets reutilizables compartidos entre pestañas."""

import tkinter as tk
from tkinter import ttk

from gui.estilos import NAVY, TEAL, WHITE, GRAY, BORDER, FUENTE


class ComboAutocompletado(ttk.Frame):
    """Entry + lista desplegable que se filtra a medida que el usuario
    escribe. Necesario porque un ttk.Combobox normal es inmanejable con
    600+ clientes reales."""

    def __init__(self, parent, opciones: list[tuple[str, str]], on_select=None,
                 ancho=32, placeholder="Escribe para buscar..."):
        """opciones: lista de (valor_interno, texto_mostrado)."""
        super().__init__(parent)
        self.opciones = opciones
        self.on_select = on_select
        self.valor_seleccionado = None

        self.var = tk.StringVar()
        self.entry = tk.Entry(self, textvariable=self.var, width=ancho, font=(FUENTE, 10),
                               relief="solid", borderwidth=1, highlightthickness=0)
        self.entry.pack(fill="x")
        self.entry.insert(0, "")
        self.entry.bind("<KeyRelease>", self._al_escribir)
        self.entry.bind("<FocusOut>", lambda e: self.after(150, self._ocultar))
        self.entry.bind("<Down>", self._mover_foco_lista)

        self.popup = None

    def _al_escribir(self, event):
        if event.keysym in ("Down", "Up", "Return", "Escape"):
            return
        texto = self.var.get().strip().lower()
        self.valor_seleccionado = None
        if not texto:
            self._ocultar()
            return
        coincidencias = [op for op in self.opciones if texto in op[1].lower()][:12]
        if coincidencias:
            self._mostrar(coincidencias)
        else:
            self._ocultar()

    def _mostrar(self, coincidencias):
        if self.popup is None:
            self.popup = tk.Toplevel(self)
            self.popup.wm_overrideredirect(True)
            self.popup.attributes("-topmost", True)
            self.lista = tk.Listbox(self.popup, font=(FUENTE, 10),
                                     height=min(8, len(coincidencias)), activestyle="dotbox",
                                     relief="solid", borderwidth=1, highlightthickness=0,
                                     selectbackground=TEAL, selectforeground=WHITE)
            self.lista.pack(fill="both", expand=True)
            self.lista.bind("<<ListboxSelect>>", self._al_seleccionar)
            self.lista.bind("<Return>", self._al_seleccionar)

        x = self.entry.winfo_rootx()
        y = self.entry.winfo_rooty() + self.entry.winfo_height()
        w = max(self.entry.winfo_width(), 260)
        self.popup.geometry(f"{w}x{min(8, len(coincidencias))*22}+{x}+{y}")

        self.lista.delete(0, tk.END)
        self._coincidencias_actuales = coincidencias
        for _, texto in coincidencias:
            self.lista.insert(tk.END, texto)
        self.popup.deiconify()

    def _mover_foco_lista(self, event):
        if self.popup is not None:
            self.lista.focus_set()
            self.lista.selection_set(0)

    def _al_seleccionar(self, event):
        if not self.lista.curselection():
            return
        idx = self.lista.curselection()[0]
        valor, texto = self._coincidencias_actuales[idx]
        self.var.set(texto)
        self.valor_seleccionado = valor
        self._ocultar()
        if self.on_select:
            self.on_select(valor, texto)

    def _ocultar(self):
        if self.popup is not None:
            self.popup.destroy()
            self.popup = None

    def obtener(self):
        return self.valor_seleccionado

    def limpiar(self):
        self.var.set("")
        self.valor_seleccionado = None
        self._ocultar()


def tabla_simple(parent, columnas: list[tuple[str, str, int]], altura=10):
    """Crea un ttk.Treeview con scrollbar. columnas: lista de (id, titulo, ancho)."""
    marco = ttk.Frame(parent)
    ids = [c[0] for c in columnas]
    tabla = ttk.Treeview(marco, columns=ids, show="headings", height=altura)
    for cid, titulo, ancho in columnas:
        tabla.heading(cid, text=titulo)
        tabla.column(cid, width=ancho, anchor="w")
    scroll = ttk.Scrollbar(marco, orient="vertical", command=tabla.yview)
    tabla.configure(yscrollcommand=scroll.set)
    tabla.pack(side="left", fill="both", expand=True)
    scroll.pack(side="right", fill="y")
    return marco, tabla
