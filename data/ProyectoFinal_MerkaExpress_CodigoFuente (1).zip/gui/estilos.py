# -*- coding: utf-8 -*-
"""
gui/estilos.py
Paleta de colores y estilos ttk compartidos por toda la aplicacion, para que
las 6 pestañas se vean como una sola aplicacion coherente (misma paleta que
el informe, los diagramas y los dashboards de Colab).
"""

import tkinter as tk
from tkinter import ttk

NAVY = "#1B2A4A"
NAVY_LIGHT = "#2C3E5E"
TEAL = "#12897E"
TEAL_LIGHT = "#E4F2F0"
AMBER = "#B9791F"
AMBER_LIGHT = "#FBEEDD"
RED = "#B03A2E"
RED_LIGHT = "#FBEEEC"
GRAY = "#6B7280"
GRAY_LIGHT = "#F4F6F8"
BORDER = "#D9DEE4"
WHITE = "#FFFFFF"
DARK = "#20262E"

FUENTE = "Helvetica"


def aplicar_estilos(root: tk.Tk) -> ttk.Style:
    style = ttk.Style(root)
    try:
        style.theme_use("clam")
    except tk.TclError:
        pass

    root.configure(bg=GRAY_LIGHT)

    style.configure(".", font=(FUENTE, 10), background=GRAY_LIGHT)

    # ---- Notebook (navegacion por pestañas = "modulos") ----
    style.configure("TNotebook", background=GRAY_LIGHT, borderwidth=0, tabmargins=[8, 8, 0, 0])
    style.configure("TNotebook.Tab", font=(FUENTE, 11, "bold"), padding=[16, 10],
                     background=WHITE, foreground=GRAY)
    style.map("TNotebook.Tab",
              background=[("selected", NAVY)],
              foreground=[("selected", WHITE)])

    # ---- Frames ----
    style.configure("Card.TFrame", background=WHITE, relief="flat", borderwidth=1)
    style.configure("Fondo.TFrame", background=GRAY_LIGHT)
    style.configure("Navy.TFrame", background=NAVY)

    # ---- Labels ----
    style.configure("TLabel", background=GRAY_LIGHT, foreground=DARK, font=(FUENTE, 10))
    style.configure("Card.TLabel", background=WHITE, foreground=DARK, font=(FUENTE, 10))
    style.configure("Titulo.TLabel", background=GRAY_LIGHT, foreground=NAVY, font=(FUENTE, 18, "bold"))
    style.configure("CardTitulo.TLabel", background=WHITE, foreground=NAVY, font=(FUENTE, 12, "bold"))
    style.configure("Subtitulo.TLabel", background=GRAY_LIGHT, foreground=GRAY, font=(FUENTE, 10))
    style.configure("KpiValor.TLabel", background=WHITE, foreground=NAVY, font=(FUENTE, 20, "bold"))
    style.configure("KpiEtiqueta.TLabel", background=WHITE, foreground=GRAY, font=(FUENTE, 8, "bold"))
    style.configure("Navy.TLabel", background=NAVY, foreground=WHITE, font=(FUENTE, 10))

    # ---- Botones ----
    style.configure("TButton", font=(FUENTE, 10, "bold"), padding=[12, 8])
    style.configure("Primary.TButton", background=TEAL, foreground=WHITE)
    style.map("Primary.TButton", background=[("active", "#0E6E65")])
    style.configure("Amber.TButton", background=AMBER, foreground=WHITE)
    style.map("Amber.TButton", background=[("active", "#93611A")])
    style.configure("Danger.TButton", background=RED, foreground=WHITE)
    style.map("Danger.TButton", background=[("active", "#8C2E24")])
    style.configure("Secundario.TButton", background=WHITE, foreground=NAVY)

    # ---- Entradas / combos ----
    style.configure("TEntry", padding=6)
    style.configure("TCombobox", padding=6)

    # ---- Tablas (Treeview) ----
    style.configure("Treeview", font=(FUENTE, 9), rowheight=26, background=WHITE,
                     fieldbackground=WHITE, foreground=DARK, borderwidth=0)
    style.configure("Treeview.Heading", font=(FUENTE, 9, "bold"), background=NAVY,
                     foreground=WHITE, relief="flat")
    style.map("Treeview.Heading", background=[("active", NAVY_LIGHT)])
    style.map("Treeview", background=[("selected", TEAL_LIGHT)], foreground=[("selected", DARK)])

    style.configure("TSeparator", background=BORDER)

    return style


def tarjeta_kpi(parent, valor: str, etiqueta: str, color=TEAL):
    """Construye una tarjeta KPI reutilizable (valor grande + etiqueta)."""
    marco = tk.Frame(parent, bg=WHITE, highlightbackground=BORDER, highlightthickness=1)
    barra = tk.Frame(marco, bg=color, width=4)
    barra.pack(side="left", fill="y")
    contenido = tk.Frame(marco, bg=WHITE)
    contenido.pack(side="left", fill="both", expand=True, padx=14, pady=10)
    tk.Label(contenido, text=valor, bg=WHITE, fg=NAVY, font=(FUENTE, 18, "bold")).pack(anchor="w")
    tk.Label(contenido, text=etiqueta, bg=WHITE, fg=GRAY, font=(FUENTE, 8, "bold")).pack(anchor="w")
    return marco
