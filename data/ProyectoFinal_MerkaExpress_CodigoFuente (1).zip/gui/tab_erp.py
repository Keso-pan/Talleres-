# -*- coding: utf-8 -*-
"""gui/tab_erp.py — Módulo ERP: caja chica y libro de asientos contables."""

import tkinter as tk
from tkinter import ttk

import pandas as pd

from gui.estilos import NAVY, TEAL, RED, GRAY, WHITE, GRAY_LIGHT, BORDER, FUENTE, tarjeta_kpi
from gui.widgets import tabla_simple


class PestanaERP(ttk.Frame):
    def __init__(self, parent, motor, app):
        super().__init__(parent, style="Fondo.TFrame")
        self.motor = motor
        self.app = app
        self._construir()

    def _construir(self):
        cont = tk.Frame(self, bg=GRAY_LIGHT)
        cont.pack(fill="both", expand=True, padx=20, pady=16)

        tk.Label(cont, text="ERP — Módulo Financiero", font=(FUENTE, 15, "bold"),
                 bg=GRAY_LIGHT, fg=NAVY).pack(anchor="w")
        tk.Label(cont, text="Cada venta del TPS genera aquí, automáticamente, un asiento contable "
                            "de partida doble y actualiza la caja chica.",
                 font=(FUENTE, 9), bg=GRAY_LIGHT, fg=GRAY).pack(anchor="w", pady=(2, 14))

        self.marco_kpis = tk.Frame(cont, bg=GRAY_LIGHT)
        self.marco_kpis.pack(fill="x", pady=(0, 16))

        marco_tabla = tk.Frame(cont, bg=WHITE, highlightbackground=BORDER, highlightthickness=1)
        marco_tabla.pack(fill="both", expand=True)
        cab = tk.Frame(marco_tabla, bg=WHITE)
        cab.pack(fill="x", padx=14, pady=(10, 4))
        tk.Label(cab, text="Libro de asientos contables (más recientes primero)",
                 font=(FUENTE, 11, "bold"), bg=WHITE, fg=NAVY).pack(side="left")
        ttk.Button(cab, text="Actualizar", style="Secundario.TButton",
                   command=self.refrescar).pack(side="right")

        marco_int, self.tabla = tabla_simple(
            marco_tabla,
            [("id_asiento", "Asiento", 90), ("id_venta", "Venta", 90), ("fecha", "Fecha", 90),
             ("cuenta", "Cuenta", 260), ("debe", "Debe", 100), ("haber", "Haber", 100),
             ("detalle", "Detalle", 260)],
            altura=18,
        )
        marco_int.pack(fill="both", expand=True, padx=14, pady=(0, 12))

        self.refrescar()

    def refrescar(self):
        for w in self.marco_kpis.winfo_children():
            w.destroy()
        k = self.motor.kpis_generales()
        try:
            contab = pd.read_csv("data/contabilidad_asientos.csv")
            total_debe = contab["debe"].sum()
            total_haber = contab["haber"].sum()
        except FileNotFoundError:
            contab = pd.DataFrame()
            total_debe = total_haber = 0

        datos = [
            (f"${k['saldo_caja']:,.2f}", "SALDO CAJA CHICA", TEAL),
            (f"{contab['id_asiento'].nunique() if len(contab) else 0:,}", "ASIENTOS GENERADOS", NAVY),
            (f"${total_debe:,.2f}", "TOTAL DEBE", GRAY),
            (f"${total_haber:,.2f}", "TOTAL HABER", GRAY),
            ("Cuadrado" if abs(total_debe - total_haber) < 0.01 else "Descuadrado",
             "VERIFICACIÓN CONTABLE", TEAL if abs(total_debe - total_haber) < 0.01 else RED),
        ]
        for i, (valor, etiqueta, color) in enumerate(datos):
            t = tarjeta_kpi(self.marco_kpis, valor, etiqueta, color)
            t.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 8, 0))
            self.marco_kpis.columnconfigure(i, weight=1)

        self.tabla.delete(*self.tabla.get_children())
        if len(contab):
            for _, fila in contab.tail(300).iloc[::-1].iterrows():
                debe = f"${fila['debe']:,.2f}" if fila["debe"] else ""
                haber = f"${fila['haber']:,.2f}" if fila["haber"] else ""
                self.tabla.insert("", "end", values=(
                    fila["id_asiento"], fila["id_venta"], fila["fecha"], fila["cuenta"],
                    debe, haber, fila["detalle"]))
