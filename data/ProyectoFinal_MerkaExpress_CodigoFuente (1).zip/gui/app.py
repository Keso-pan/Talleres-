# -*- coding: utf-8 -*-
"""
gui/app.py
Ventana principal de la aplicacion MerkaExpress. Muestra una pantalla de
carga mientras el motor reproduce el 100% de las transacciones reales, y
luego arma la navegacion por pestañas (un modulo por pestaña: TPS, ERP,
SCM, CRM, Dashboard).
"""

import tkinter as tk
from tkinter import ttk

from gui import estilos
from gui.estilos import NAVY, WHITE, GRAY, TEAL, GRAY_LIGHT, FUENTE
from gui.motor import obtener_motor


class AplicacionMerkaExpress(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("MerkaExpress — Sistema Integrado POS · ERP · SCM · CRM")
        self.geometry("1360x860")
        self.minsize(1150, 720)
        self.style = estilos.aplicar_estilos(self)
        self.motor = obtener_motor()

        self._construir_pantalla_carga()
        self.after(100, self._cargar_y_arrancar)

    # ------------------------------------------------------------------
    def _construir_pantalla_carga(self):
        self.marco_carga = tk.Frame(self, bg=NAVY)
        self.marco_carga.pack(fill="both", expand=True)

        centro = tk.Frame(self.marco_carga, bg=NAVY)
        centro.place(relx=0.5, rely=0.5, anchor="center")

        tk.Label(centro, text="MerkaExpress", font=(FUENTE, 30, "bold"), bg=NAVY, fg=WHITE).pack()
        tk.Label(centro, text="Sistema Integrado POS · ERP · SCM · CRM",
                 font=(FUENTE, 12), bg=NAVY, fg="#B9C4D4").pack(pady=(0, 30))

        self.lbl_estado = tk.Label(centro, text="Iniciando...", font=(FUENTE, 10),
                                    bg=NAVY, fg=WHITE)
        self.lbl_estado.pack()

        self.barra = ttk.Progressbar(centro, mode="indeterminate", length=340)
        self.barra.pack(pady=14)
        self.barra.start(12)

    def _actualizar_estado_carga(self, mensaje: str):
        self.lbl_estado.config(text=mensaje)
        self.update_idletasks()

    def _cargar_y_arrancar(self):
        self.motor.inicializar(callback_estado=self._actualizar_estado_carga)
        self.barra.stop()
        self.marco_carga.destroy()
        self._construir_interfaz_principal()

    # ------------------------------------------------------------------
    def _construir_interfaz_principal(self):
        self._construir_encabezado()

        self.notebook = ttk.Notebook(self)
        self.notebook.pack(fill="both", expand=True, padx=10, pady=(6, 10))

        from gui.tab_inicio import PestanaInicio
        from gui.tab_tps import PestanaTPS
        from gui.tab_erp import PestanaERP
        from gui.tab_scm import PestanaSCM
        from gui.tab_crm import PestanaCRM
        from gui.tab_dashboard import PestanaDashboard

        self.pestana_inicio = PestanaInicio(self.notebook, self.motor, self)
        self.pestana_tps = PestanaTPS(self.notebook, self.motor, self)
        self.pestana_erp = PestanaERP(self.notebook, self.motor, self)
        self.pestana_scm = PestanaSCM(self.notebook, self.motor, self)
        self.pestana_crm = PestanaCRM(self.notebook, self.motor, self)
        self.pestana_dashboard = PestanaDashboard(self.notebook, self.motor, self)

        self.notebook.add(self.pestana_inicio, text="   Inicio   ")
        self.notebook.add(self.pestana_tps, text="   TPS · Punto de Venta   ")
        self.notebook.add(self.pestana_erp, text="   ERP · Financiero   ")
        self.notebook.add(self.pestana_scm, text="   SCM · Inventario   ")
        self.notebook.add(self.pestana_crm, text="   CRM · Clientes   ")
        self.notebook.add(self.pestana_dashboard, text="   Dashboard BI   ")

        self.notebook.bind("<<NotebookTabChanged>>", self._al_cambiar_pestana)

    def _construir_encabezado(self):
        enc = tk.Frame(self, bg=NAVY, height=54)
        enc.pack(fill="x")
        enc.pack_propagate(False)
        tk.Label(enc, text="MerkaExpress", font=(FUENTE, 15, "bold"), bg=NAVY, fg=WHITE
                 ).pack(side="left", padx=(18, 6), pady=8)
        tk.Label(enc, text="NexoTech Consultores", font=(FUENTE, 9, "bold"),
                 bg=NAVY, fg=TEAL).pack(side="right", padx=18)

    # ------------------------------------------------------------------
    def _al_cambiar_pestana(self, event):
        """Refresca la pestaña activa con los datos mas recientes del motor
        cada vez que el usuario navega a ella (para reflejar cambios hechos
        en otras pestañas -patron Observer tambien en la GUI-)."""
        idx = self.notebook.index("current")
        pestana = self.notebook.nametowidget(self.notebook.tabs()[idx])
        if hasattr(pestana, "refrescar"):
            pestana.refrescar()


def iniciar():
    app = AplicacionMerkaExpress()
    app.mainloop()


if __name__ == "__main__":
    iniciar()
