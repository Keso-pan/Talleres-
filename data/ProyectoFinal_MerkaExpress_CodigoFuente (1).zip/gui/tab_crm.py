# -*- coding: utf-8 -*-
"""gui/tab_crm.py — Módulo CRM: consulta automatizada de clientes en riesgo
de deserción y búsqueda del historial de un cliente puntual."""

import tkinter as tk
from tkinter import ttk

import pandas as pd

from gui.estilos import NAVY, TEAL, AMBER, RED, GRAY, WHITE, GRAY_LIGHT, BORDER, FUENTE, tarjeta_kpi
from gui.widgets import ComboAutocompletado, tabla_simple


class PestanaCRM(ttk.Frame):
    def __init__(self, parent, motor, app):
        super().__init__(parent, style="Fondo.TFrame")
        self.motor = motor
        self.app = app
        self._construir()

    def _construir(self):
        cont = tk.Frame(self, bg=GRAY_LIGHT)
        cont.pack(fill="both", expand=True, padx=20, pady=16)

        tk.Label(cont, text="CRM — Relación con el Cliente", font=(FUENTE, 15, "bold"),
                 bg=GRAY_LIGHT, fg=NAVY).pack(anchor="w")
        tk.Label(cont, text="Consulta automatizada que aísla a los clientes Member sin compras "
                            "recientes y dispara la alerta 'Cliente en Riesgo de Deserción'.",
                 font=(FUENTE, 9), bg=GRAY_LIGHT, fg=GRAY).pack(anchor="w", pady=(2, 14))

        self.marco_kpis = tk.Frame(cont, bg=GRAY_LIGHT)
        self.marco_kpis.pack(fill="x", pady=(0, 14))

        # ---- Controles de consulta ----
        marco_ctrl = tk.Frame(cont, bg=WHITE, highlightbackground=BORDER, highlightthickness=1)
        marco_ctrl.pack(fill="x", pady=(0, 14))
        interior = tk.Frame(marco_ctrl, bg=WHITE)
        interior.pack(fill="x", padx=14, pady=10)

        tk.Label(interior, text="Fecha de corte", bg=WHITE, fg=GRAY, font=(FUENTE, 9)).grid(row=0, column=0, sticky="w")
        self.var_fecha = tk.StringVar(value=self.motor.fecha_ultima_transaccion or "2019-03-30")
        tk.Entry(interior, textvariable=self.var_fecha, width=12).grid(row=1, column=0, sticky="w", padx=(0, 16))

        tk.Label(interior, text="Umbral (días de inactividad)", bg=WHITE, fg=GRAY, font=(FUENTE, 9)
                 ).grid(row=0, column=1, sticky="w")
        self.var_umbral = tk.IntVar(value=30)
        tk.Spinbox(interior, from_=7, to=180, textvariable=self.var_umbral, width=6
                    ).grid(row=1, column=1, sticky="w", padx=(0, 16))

        ttk.Button(interior, text="Ejecutar consulta automatizada", style="Danger.TButton",
                   command=self._ejecutar_consulta).grid(row=1, column=2, sticky="w")

        tk.Label(interior, text="(Solo evalúa clientes Member: son los únicos con una relación de "
                                 "fidelización rastreable — ver Fase 3.1)",
                 font=(FUENTE, 8), bg=WHITE, fg=GRAY).grid(row=2, column=0, columnspan=3, sticky="w", pady=(4, 0))

        # ---- Resultados + busqueda ----
        fila = tk.Frame(cont, bg=GRAY_LIGHT)
        fila.pack(fill="both", expand=True)
        fila.columnconfigure(0, weight=6)
        fila.columnconfigure(1, weight=4)
        fila.rowconfigure(0, weight=1)

        marco_res = tk.Frame(fila, bg=WHITE, highlightbackground=BORDER, highlightthickness=1)
        marco_res.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        tk.Label(marco_res, text="Clientes en riesgo (última consulta)", font=(FUENTE, 11, "bold"),
                 bg=WHITE, fg=NAVY).pack(anchor="w", padx=14, pady=(10, 4))
        marco_t, self.tabla_riesgo = tabla_simple(
            marco_res,
            [("cliente", "Cliente", 130), ("id", "ID", 90), ("ultima", "Última compra", 100),
             ("dias", "Días inactivo", 90)],
            altura=14,
        )
        marco_t.pack(fill="both", expand=True, padx=14, pady=(0, 12))

        # ---- Busqueda de cliente ----
        marco_buscar = tk.Frame(fila, bg=WHITE, highlightbackground=BORDER, highlightthickness=1)
        marco_buscar.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
        tk.Label(marco_buscar, text="Buscar cliente", font=(FUENTE, 11, "bold"),
                 bg=WHITE, fg=NAVY).pack(anchor="w", padx=14, pady=(10, 4))
        opciones = sorted(
            [(cid, f"{c.nombre} ({cid})") for cid, c in self.motor.clientes.items()], key=lambda x: x[1])
        self.combo_buscar = ComboAutocompletado(marco_buscar, opciones, ancho=32,
                                                 on_select=self._al_elegir_cliente)
        self.combo_buscar.pack(fill="x", padx=14, pady=(0, 10))

        self.marco_ficha = tk.Frame(marco_buscar, bg=WHITE)
        self.marco_ficha.pack(fill="both", expand=True, padx=14, pady=(0, 14))
        self.lbl_ficha = tk.Label(self.marco_ficha, text="Busca un cliente para ver su ficha.",
                                   font=(FUENTE, 9), bg=WHITE, fg=GRAY, justify="left", wraplength=280)
        self.lbl_ficha.pack(anchor="nw")

        self.refrescar()

    def _ejecutar_consulta(self):
        resultado = self.motor.ejecutar_consulta_crm(self.var_fecha.get(), self.var_umbral.get())
        self.tabla_riesgo.delete(*self.tabla_riesgo.get_children())
        try:
            alertas = pd.read_csv("data/alertas_crm.csv")
            ultima = alertas[alertas["fecha_consulta"] == self.var_fecha.get()].sort_values(
                "dias_inactividad", ascending=False)
        except FileNotFoundError:
            ultima = pd.DataFrame()
        for _, fila in ultima.iterrows():
            self.tabla_riesgo.insert("", "end", values=(
                fila["nombre"], fila["id_cliente"], fila["fecha_ultima_compra"],
                int(fila["dias_inactividad"])))
        self.refrescar()
        if hasattr(self.app, "pestana_tps"):
            self.app.pestana_tps.refrescar()

    def _al_elegir_cliente(self, id_cliente, texto):
        c = self.motor.clientes.get(id_cliente)
        if not c:
            return
        try:
            ventas = pd.read_csv("data/ventas_sistema.csv")
            propias = ventas[ventas["id_cliente"] == id_cliente]
            n_compras = propias["id_venta"].nunique()
            gasto_total = round(propias["subtotal_linea"].sum() * 1.15, 2)
        except FileNotFoundError:
            n_compras, gasto_total = 0, 0

        for w in self.marco_ficha.winfo_children():
            w.destroy()
        tk.Label(self.marco_ficha, text=c.nombre, font=(FUENTE, 12, "bold"), bg=WHITE, fg=NAVY
                 ).pack(anchor="w")
        tk.Label(self.marco_ficha, text=f"{id_cliente}  ·  {c.tipo}  ·  {c.genero}",
                 font=(FUENTE, 9), bg=WHITE, fg=GRAY).pack(anchor="w", pady=(0, 8))
        for etiqueta, valor in [
            ("Sucursal de registro", c.sucursal_registro),
            ("Cliente desde", c.fecha_registro),
            ("Última compra", c.fecha_ultima_compra or "—"),
            ("N.º de compras", str(n_compras)),
            ("Gasto total", f"${gasto_total:,.2f}"),
        ]:
            fila = tk.Frame(self.marco_ficha, bg=WHITE)
            fila.pack(fill="x", pady=2)
            tk.Label(fila, text=etiqueta, font=(FUENTE, 9), bg=WHITE, fg=GRAY, width=16, anchor="w"
                     ).pack(side="left")
            tk.Label(fila, text=valor, font=(FUENTE, 9, "bold"), bg=WHITE, fg=NAVY, anchor="w"
                     ).pack(side="left")

    def refrescar(self):
        for w in self.marco_kpis.winfo_children():
            w.destroy()
        try:
            alertas = pd.read_csv("data/alertas_crm.csv")
            n_alertas_ultima = 0
            if len(alertas):
                ultima_fecha = alertas["fecha_consulta"].max()
                n_alertas_ultima = alertas[alertas["fecha_consulta"] == ultima_fecha]["id_cliente"].nunique()
        except FileNotFoundError:
            n_alertas_ultima = 0
        n_member = sum(1 for c in self.motor.clientes.values() if c.tipo == "Member")

        datos = [
            (f"{len(self.motor.clientes):,}", "CLIENTES RECONSTRUIDOS (100%)", NAVY),
            (f"{n_member:,}", "CON MEMBRESÍA (MEMBER)", TEAL),
            (f"{n_alertas_ultima}", "EN RIESGO (ÚLTIMA CONSULTA)", RED if n_alertas_ultima else TEAL),
        ]
        for i, (valor, etiqueta, color) in enumerate(datos):
            t = tarjeta_kpi(self.marco_kpis, valor, etiqueta, color)
            t.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 8, 0))
            self.marco_kpis.columnconfigure(i, weight=1)
