# -*- coding: utf-8 -*-
"""gui/tab_inicio.py — Pantalla de inicio: KPIs generales y descripcion del sistema."""

import tkinter as tk
from tkinter import ttk

from gui.estilos import NAVY, TEAL, AMBER, RED, GRAY, WHITE, GRAY_LIGHT, BORDER, FUENTE, tarjeta_kpi


class PestanaInicio(ttk.Frame):
    def __init__(self, parent, motor, app):
        super().__init__(parent, style="Fondo.TFrame")
        self.motor = motor
        self.app = app
        self._construir()

    def _construir(self):
        cont = tk.Frame(self, bg=GRAY_LIGHT)
        cont.pack(fill="both", expand=True, padx=24, pady=20)

        tk.Label(cont, text="Panel general", font=(FUENTE, 16, "bold"),
                 bg=GRAY_LIGHT, fg=NAVY).pack(anchor="w", pady=(0, 18))

        self.marco_kpis = tk.Frame(cont, bg=GRAY_LIGHT)
        self.marco_kpis.pack(fill="x")

        # ---- Descripcion de modulos ----
        marco_modulos = tk.Frame(cont, bg=GRAY_LIGHT)
        marco_modulos.pack(fill="both", expand=True, pady=(26, 0))

        modulos = [
            ("TPS", "Sistema Principal (Core Business)",
             "Registra ventas, calcula el impuesto (5%) y descuenta stock en tiempo real. "
             "Notifica automáticamente a ERP, SCM y CRM (patrón Observer).", TEAL),
            ("ERP", "Mini-financiero",
             "Genera el asiento contable de partida doble y actualiza la caja chica "
             "automáticamente por cada venta registrada en el TPS.", NAVY),
            ("SCM", "Inventario y Proveedores",
             "Vigila el stock de cada línea de producto y genera órdenes de compra "
             "automáticas al llegar al punto de reorden.", AMBER),
            ("CRM", "Relación con el Cliente",
             "Mantiene la fecha de última compra al día y ejecuta consultas automatizadas "
             "para aislar clientes en riesgo de deserción.", RED),
        ]
        for i, (sigla, titulo, desc, color) in enumerate(modulos):
            tarjeta = tk.Frame(marco_modulos, bg=WHITE, highlightbackground=BORDER, highlightthickness=1)
            tarjeta.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 10, 0))
            marco_modulos.columnconfigure(i, weight=1)
            barra = tk.Frame(tarjeta, bg=color, height=4)
            barra.pack(fill="x")
            interior = tk.Frame(tarjeta, bg=WHITE)
            interior.pack(fill="both", expand=True, padx=14, pady=12)
            tk.Label(interior, text=sigla, font=(FUENTE, 13, "bold"), bg=WHITE, fg=color).pack(anchor="w")
            tk.Label(interior, text=titulo, font=(FUENTE, 10, "bold"), bg=WHITE, fg=NAVY).pack(anchor="w", pady=(2, 6))
            tk.Label(interior, text=desc, font=(FUENTE, 9), bg=WHITE, fg=GRAY,
                     wraplength=200, justify="left").pack(anchor="w")

        pie = tk.Frame(cont, bg=GRAY_LIGHT)
        pie.pack(fill="x", pady=(24, 0))
        tk.Label(pie, text="Firma consultora: NexoTech Consultores  ·  Cliente: MerkaExpress "
                            "(sucursales Alex/Yangon, Cairo/Mandalay, Giza/Naypyitaw)  ·  ISID223 — EPN",
                 font=(FUENTE, 9), bg=GRAY_LIGHT, fg=GRAY).pack(anchor="w")

        self.refrescar()

    def refrescar(self):
        for w in self.marco_kpis.winfo_children():
            w.destroy()
        k = self.motor.kpis_generales()
        datos = [
            (f"${k['ingresos_totales']:,.0f}", "INGRESOS TOTALES", TEAL),
            (f"${k['ticket_promedio']:,.2f}", "TICKET PROMEDIO", NAVY),
            (f"{k['n_transacciones']:,}", "TRANSACCIONES", AMBER),
            (f"{k['n_clientes']:,}", "CLIENTES", GRAY),
            (f"${k['saldo_caja']:,.0f}", "CAJA CHICA (ERP)", TEAL),
            (f"{k['n_ordenes_scm']}", "ÓRDENES SCM", RED),
        ]
        for i, (valor, etiqueta, color) in enumerate(datos):
            tarjeta = tarjeta_kpi(self.marco_kpis, valor, etiqueta, color)
            tarjeta.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 8, 0))
            self.marco_kpis.columnconfigure(i, weight=1)
