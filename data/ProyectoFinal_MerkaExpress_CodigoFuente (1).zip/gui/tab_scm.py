# -*- coding: utf-8 -*-
"""gui/tab_scm.py — Módulo SCM: inventario por línea de producto y órdenes
de compra automáticas, con opción de simular la recepción de un pedido."""

import tkinter as tk
from tkinter import ttk, messagebox

import pandas as pd

from gui.estilos import NAVY, TEAL, AMBER, RED, GRAY, WHITE, GRAY_LIGHT, BORDER, FUENTE, tarjeta_kpi
from gui.widgets import tabla_simple


class PestanaSCM(ttk.Frame):
    def __init__(self, parent, motor, app):
        super().__init__(parent, style="Fondo.TFrame")
        self.motor = motor
        self.app = app
        self._construir()

    def _construir(self):
        cont = tk.Frame(self, bg=GRAY_LIGHT)
        cont.pack(fill="both", expand=True, padx=20, pady=16)

        tk.Label(cont, text="SCM — Inventario y Proveedores", font=(FUENTE, 15, "bold"),
                 bg=GRAY_LIGHT, fg=NAVY).pack(anchor="w")
        tk.Label(cont, text="Cuando una venta del TPS deja el stock en o bajo el punto de reorden, "
                            "el SCM genera automáticamente una orden de compra.",
                 font=(FUENTE, 9), bg=GRAY_LIGHT, fg=GRAY).pack(anchor="w", pady=(2, 14))

        self.marco_kpis = tk.Frame(cont, bg=GRAY_LIGHT)
        self.marco_kpis.pack(fill="x", pady=(0, 16))

        fila = tk.Frame(cont, bg=GRAY_LIGHT)
        fila.pack(fill="both", expand=True)
        fila.columnconfigure(0, weight=1)
        fila.columnconfigure(1, weight=1)
        fila.rowconfigure(0, weight=1)

        # ---- Inventario ----
        marco_inv = tk.Frame(fila, bg=WHITE, highlightbackground=BORDER, highlightthickness=1)
        marco_inv.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        tk.Label(marco_inv, text="Inventario por línea de producto", font=(FUENTE, 11, "bold"),
                 bg=WHITE, fg=NAVY).pack(anchor="w", padx=14, pady=(10, 4))
        marco_t1, self.tabla_inventario = tabla_simple(
            marco_inv,
            [("producto", "Línea de producto", 190), ("stock", "Stock", 70),
             ("minimo", "Mínimo", 70), ("proveedor", "Proveedor", 190), ("estado", "Estado", 90)],
            altura=10,
        )
        marco_t1.pack(fill="both", expand=True, padx=14, pady=(0, 10))
        self.tabla_inventario.tag_configure("bajo", foreground=RED)
        self.tabla_inventario.tag_configure("ok", foreground=TEAL)

        # ---- Ordenes de compra ----
        marco_oc = tk.Frame(fila, bg=WHITE, highlightbackground=BORDER, highlightthickness=1)
        marco_oc.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
        cab = tk.Frame(marco_oc, bg=WHITE)
        cab.pack(fill="x", padx=14, pady=(10, 4))
        tk.Label(cab, text="Órdenes de compra (automáticas)", font=(FUENTE, 11, "bold"),
                 bg=WHITE, fg=NAVY).pack(side="left")
        marco_t2, self.tabla_ordenes = tabla_simple(
            marco_oc,
            [("id_orden", "Orden", 80), ("fecha", "Fecha", 85), ("producto", "Producto", 170),
             ("proveedor", "Proveedor", 170), ("cantidad", "Cant.", 55), ("estado", "Estado", 80)],
            altura=10,
        )
        marco_t2.pack(fill="both", expand=True, padx=14, pady=(0, 6))

        marco_accion = tk.Frame(marco_oc, bg=WHITE)
        marco_accion.pack(fill="x", padx=14, pady=(0, 12))
        tk.Label(marco_accion, text="Selecciona una orden 'Generada' y simula que el proveedor "
                                     "la entrega:", font=(FUENTE, 8), bg=WHITE, fg=GRAY
                 ).pack(anchor="w")
        ttk.Button(marco_accion, text="Recibir pedido del proveedor seleccionado",
                   style="Amber.TButton", command=self._recibir_pedido).pack(fill="x", pady=(4, 0))

        self.refrescar()

    def _recibir_pedido(self):
        seleccion = self.tabla_ordenes.selection()
        if not seleccion:
            messagebox.showwarning("Sin selección", "Selecciona primero una orden en la tabla.")
            return
        valores = self.tabla_ordenes.item(seleccion[0], "values")
        id_orden, estado = valores[0], valores[5]
        if estado == "Recibida":
            messagebox.showinfo("Ya recibida", f"La orden {id_orden} ya fue marcada como recibida.")
            return
        try:
            ordenes = pd.read_csv("data/ordenes_compra.csv")
            fila_orden = ordenes[ordenes["id_orden"] == id_orden].iloc[0]
        except (FileNotFoundError, IndexError):
            return
        self.motor.recibir_pedido_manual(fila_orden["id_producto"])
        messagebox.showinfo("Pedido recibido", f"Stock de '{fila_orden['producto']}' actualizado.")
        self.refrescar()
        if hasattr(self.app, "pestana_inicio"):
            self.app.pestana_inicio.refrescar()

    def refrescar(self):
        for w in self.marco_kpis.winfo_children():
            w.destroy()
        productos_bajo = [p for p in self.motor.productos.values() if p.hay_stock_bajo()]
        try:
            ordenes = pd.read_csv("data/ordenes_compra.csv")
        except FileNotFoundError:
            ordenes = pd.DataFrame()
        pendientes = len(ordenes[ordenes["estado"] == "Generada"]) if len(ordenes) else 0

        datos = [
            (f"{len(self.motor.productos)}", "LÍNEAS DE PRODUCTO", NAVY),
            (f"{len(productos_bajo)}", "CON STOCK BAJO AHORA", RED if productos_bajo else TEAL),
            (f"{len(ordenes)}", "ÓRDENES GENERADAS (TOTAL)", AMBER),
            (f"{pendientes}", "ÓRDENES PENDIENTES", RED if pendientes else TEAL),
        ]
        for i, (valor, etiqueta, color) in enumerate(datos):
            t = tarjeta_kpi(self.marco_kpis, valor, etiqueta, color)
            t.grid(row=0, column=i, sticky="nsew", padx=(0 if i == 0 else 8, 0))
            self.marco_kpis.columnconfigure(i, weight=1)

        self.tabla_inventario.delete(*self.tabla_inventario.get_children())
        for p in sorted(self.motor.productos.values(), key=lambda x: x.stock_actual - x.stock_minimo):
            bajo = p.hay_stock_bajo()
            self.tabla_inventario.insert("", "end", values=(
                p.nombre, p.stock_actual, p.stock_minimo, p.proveedor,
                "BAJO" if bajo else "OK"), tags=("bajo" if bajo else "ok",))

        self.tabla_ordenes.delete(*self.tabla_ordenes.get_children())
        if len(ordenes):
            for _, fila in ordenes.iloc[::-1].iterrows():
                self.tabla_ordenes.insert("", "end", values=(
                    fila["id_orden"], fila["fecha"], fila["producto"], fila["proveedor"],
                    fila["cantidad_solicitada"], fila["estado"]))
