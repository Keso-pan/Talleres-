# -*- coding: utf-8 -*-
"""gui/tab_dashboard.py — Modulo de Dashboard: tablero gerencial embebido con
matplotlib (Fase 4.1), calculado en vivo sobre los datos reales del sistema."""

import tkinter as tk
from tkinter import ttk

import matplotlib
matplotlib.use("Agg")  # el canvas de Tkinter se maneja aparte via FigureCanvasTkAgg
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import matplotlib.gridspec as gridspec
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import pandas as pd

from gui.estilos import NAVY, TEAL, AMBER, RED, GRAY, WHITE, GRAY_LIGHT, BORDER, FUENTE
from bi.analisis_rfm import cargar_facturas, calcular_rfm, resumen_por_segmento, FECHA_REFERENCIA

COLOR_SEGMENTO = {
    "VIP / Campeones": TEAL, "Clientes Fieles": "#3F8F63", "Regulares": "#7CA8C4",
    "Nuevos / Prometedores": AMBER, "En Riesgo": "#D98A3D",
    "No Perder (alto valor inactivo)": "#8E3B46", "Hibernando / Perdidos": GRAY,
}


class PestanaDashboard(ttk.Frame):
    def __init__(self, parent, motor, app):
        super().__init__(parent, style="Fondo.TFrame")
        self.motor = motor
        self.app = app
        self.canvas = None
        self._construir()

    def _construir(self):
        cont = tk.Frame(self, bg=GRAY_LIGHT)
        cont.pack(fill="both", expand=True, padx=16, pady=12)

        cab = tk.Frame(cont, bg=GRAY_LIGHT)
        cab.pack(fill="x")
        tk.Label(cab, text="Dashboard BI — Tablero de Control Gerencial", font=(FUENTE, 15, "bold"),
                 bg=GRAY_LIGHT, fg=NAVY).pack(side="left")
        ttk.Button(cab, text="Actualizar con los datos más recientes", style="Primary.TButton",
                   command=self.refrescar).pack(side="right")

        self.marco_canvas = tk.Frame(cont, bg=WHITE, highlightbackground=BORDER, highlightthickness=1)
        self.marco_canvas.pack(fill="both", expand=True, pady=(10, 0))

        self.refrescar()

    def refrescar(self):
        for w in self.marco_canvas.winfo_children():
            w.destroy()

        fig = self._construir_figura()
        self.canvas = FigureCanvasTkAgg(fig, master=self.marco_canvas)
        self.canvas.draw()
        self.canvas.get_tk_widget().pack(fill="both", expand=True, padx=6, pady=6)
        plt.close(fig)

    # ------------------------------------------------------------------
    def _construir_figura(self):
        ventas = pd.read_csv("data/ventas_sistema.csv", parse_dates=["fecha"])
        ordenes = pd.read_csv("data/ordenes_compra.csv")
        alertas = pd.read_csv("data/alertas_crm.csv")

        facturas = cargar_facturas()
        rfm = calcular_rfm(facturas, FECHA_REFERENCIA)
        resumen = resumen_por_segmento(rfm).reset_index()  # 'segmento' es el índice -> columna normal

        semanal = ventas.groupby(["id_venta", "fecha"])["subtotal_linea"].sum().reset_index()
        semanal["total"] = (semanal["subtotal_linea"] * 1.05).round(2)
        semanal = semanal.set_index("fecha")["total"].resample("W-MON").sum()

        fig = plt.figure(figsize=(12.6, 7.6), dpi=100, facecolor="white")
        fig.suptitle("MerkaExpress — Dashboard en vivo (datos reales del sistema)",
                     fontsize=13, fontweight="bold", color=NAVY, x=0.02, ha="left")

        gs = gridspec.GridSpec(2, 2, height_ratios=[1, 1], hspace=0.5, wspace=0.28,
                                top=0.90, bottom=0.09, left=0.07, right=0.97)

        ax1 = fig.add_subplot(gs[0, 0])
        ax1.plot(semanal.index, semanal.values, color=TEAL, marker="o", markersize=3)
        ax1.fill_between(semanal.index, semanal.values, color=TEAL, alpha=0.12)
        ax1.set_title("Ventas semanales", fontsize=10.5, fontweight="bold", color=NAVY)
        ax1.xaxis.set_major_formatter(mdates.DateFormatter("%d-%b"))
        ax1.tick_params(axis="x", rotation=30, labelsize=7.5)

        ax2 = fig.add_subplot(gs[0, 1])
        resumen_ord = resumen.sort_values("clientes")
        colores = [COLOR_SEGMENTO.get(s, GRAY) for s in resumen_ord["segmento"]]
        barras = ax2.barh(resumen_ord["segmento"], resumen_ord["clientes"], color=colores)
        for b, pct in zip(barras, resumen_ord["pct_ingresos"]):
            ax2.text(b.get_width() + 1, b.get_y() + b.get_height() / 2, f"{pct:.0f}%",
                     va="center", fontsize=7.5)
        ax2.set_title("Segmentación RFM (clientes / % ingresos)", fontsize=10.5, fontweight="bold", color=NAVY)
        ax2.tick_params(labelsize=7.5)

        ax3 = fig.add_subplot(gs[1, 0])
        por_prov = ordenes.groupby("proveedor")["id_orden"].count().sort_values()
        ax3.barh(por_prov.index, por_prov.values, color=AMBER)
        ax3.set_title(f"SCM — Órdenes de compra por proveedor (n={len(ordenes)})",
                      fontsize=10.5, fontweight="bold", color=NAVY)
        ax3.tick_params(labelsize=7.5)

        ax4 = fig.add_subplot(gs[1, 1])
        ultima_fecha = alertas["fecha_consulta"].max() if len(alertas) else None
        top = (alertas[alertas["fecha_consulta"] == ultima_fecha].sort_values(
            "dias_inactividad", ascending=False).head(8) if ultima_fecha else pd.DataFrame())
        if top.empty:
            ax4.axis("off")
            ax4.add_patch(plt.Rectangle((0, 0), 1, 1, transform=ax4.transAxes,
                                         facecolor="#FBEEEC", edgecolor=RED, linewidth=1))
            ax4.text(0.5, 0.5, "Clientes en riesgo de deserción (CRM)\n\nSin consultas registradas "
                                "todavía — ve a la pestaña CRM\ny ejecuta la consulta automatizada.",
                     fontsize=9, color=RED, transform=ax4.transAxes, ha="center", va="center")
        else:
            etiquetas = [f"{n} ({c})" for n, c in zip(top["nombre"], top["id_cliente"])]
            ax4.barh(etiquetas[::-1], top["dias_inactividad"][::-1], color=RED)
            ax4.set_title(f"Clientes en riesgo de deserción (CRM, corte {ultima_fecha})",
                          fontsize=10.5, fontweight="bold", color=NAVY)
            ax4.set_xlabel("Días de inactividad", fontsize=8)
            ax4.tick_params(labelsize=7.5)

        return fig
