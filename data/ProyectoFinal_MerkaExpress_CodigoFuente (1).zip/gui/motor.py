# -*- coding: utf-8 -*-
"""
gui/motor.py
Proyecto Final ISID223 - Transformacion Digital Empresarial (MerkaExpress)

Motor de la aplicacion: inicializa el sistema real (100% de las 1000
transacciones de SuperMarket_Analysis.csv, reproducidas a traves del
Sistema POS -TPS-) y expone una API simple para que los modulos de la GUI
(TPS, ERP, SCM, CRM, Dashboard) lean y operen sobre el MISMO estado en vivo.

No genera ningun dato inventado: el catalogo son las 6 lineas reales, los
clientes son la reconstruccion (ya validada) del 100% de las filas reales,
y las 1000 transacciones que se reproducen al arrancar son las reales del
CSV. Los unicos datos "nuevos" que puede haber son los que el propio
usuario registre desde la pestaña TPS mientras usa la aplicacion (igual que
un cajero registrando ventas reales en un POS).
"""

import os
import sys
from datetime import datetime

import pandas as pd

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if RAIZ not in sys.path:
    sys.path.insert(0, RAIZ)

from core.sistema_pos import SistemaPOS
from core.modelos import Cliente, Producto, Venta
from modulos.modulo_erp import ModuloERP
from modulos.modulo_scm import ModuloSCM
from modulos.modulo_crm import ModuloCRM
from datos_maestros import (
    crear_catalogo_productos, reconstruir_clientes, preparar_eventos_reales,
    MAPA_SUCURSAL, MAPA_PAGO,
)

RUTA_DATOS = os.path.join(RAIZ, "data")
RUTA_CSV_HISTORICO = os.path.join(RUTA_DATOS, "SuperMarket_Analysis.csv")
LEAD_TIME_PROVEEDOR = 6


class MotorAplicacion:
    """Encapsula el estado en vivo del sistema integrado y las operaciones
    que la interfaz grafica necesita. Una sola instancia se comparte entre
    todas las pestañas (patron 'single source of truth')."""

    def __init__(self):
        self.df_historico: pd.DataFrame | None = None
        self.sistema: SistemaPOS | None = None
        self.erp: ModuloERP | None = None
        self.scm: ModuloSCM | None = None
        self.crm: ModuloCRM | None = None
        self.productos: dict[str, Producto] = {}
        self.clientes: dict[str, Cliente] = {}
        self.perfil_cliente: dict[str, str] = {}
        self.mapa_id_por_linea: dict[str, str] = {}
        self.n_transacciones_historicas = 0
        self.n_transacciones_nuevas_sesion = 0
        self.fecha_ultima_transaccion = None
        self.log_integracion: list[str] = []  # eventos ERP/SCM/CRM recientes, para mostrar en la GUI

    # ------------------------------------------------------------------
    def inicializar(self, callback_estado=None) -> None:
        """Carga el 100% del CSV historico, reconstruye clientes y catalogo,
        y reproduce las 1000 transacciones reales a traves del TPS. Se
        ejecuta una sola vez, al arrancar la aplicacion."""

        def avisar(msg):
            if callback_estado:
                callback_estado(msg)

        avisar("Cargando dataset historico completo (SuperMarket_Analysis.csv)...")
        df = pd.read_csv(RUTA_CSV_HISTORICO, encoding="utf-8-sig")
        df["Date"] = pd.to_datetime(df["Date"])
        assert len(df) == 1000, f"Se esperaban 1000 filas reales, se cargaron {len(df)}"
        self.df_historico = df
        self.n_transacciones_historicas = len(df)

        avisar("Construyendo catálogo (6 líneas reales) y reconstruyendo clientes (100% de filas)...")
        self.productos, self.mapa_id_por_linea = crear_catalogo_productos(df)
        self.clientes, ids_por_fila, self.perfil_cliente = reconstruir_clientes(df, seed=42)
        eventos = preparar_eventos_reales(df, ids_por_fila, self.mapa_id_por_linea)

        avisar("Inicializando Sistema Principal (TPS) y suscribiendo ERP, SCM y CRM (Observer)...")
        self.sistema = SistemaPOS(ruta_datos=RUTA_DATOS)
        self.sistema.cargar_clientes(list(self.clientes.values()))
        self.sistema.cargar_productos(list(self.productos.values()))

        self.erp = ModuloERP(ruta_datos=RUTA_DATOS, saldo_inicial_caja=5000.0)
        self.scm = ModuloSCM(catalogo_productos=self.productos, ruta_datos=RUTA_DATOS, cantidad_reorden=180)
        self.crm = ModuloCRM(catalogo_clientes=self.clientes, ruta_datos=RUTA_DATOS)
        self.erp.verbose = False
        self.scm.verbose = False
        self.sistema.suscribir(self.erp)
        self.sistema.suscribir(self.scm)
        self.sistema.suscribir(self.crm)

        avisar(f"Reproduciendo el 100% de las {len(eventos)} transacciones reales...")
        for ev in eventos:
            self.sistema.registrar_venta(
                id_cliente=ev["id_cliente"], sucursal=ev["sucursal"], forma_pago=ev["forma_pago"],
                carrito=ev["carrito"], fecha=ev["fecha"], hora=ev["hora"], modo_historico=True,
            )
            for pid in self.scm.ordenes_listas_para_recibir(ev["fecha"], LEAD_TIME_PROVEEDOR):
                self.scm.recibir_pedido(pid)

        self.fecha_ultima_transaccion = df["Date"].max().strftime("%Y-%m-%d")
        avisar("Listo.")

    # ------------------------------------------------------------------
    def registrar_venta_nueva(self, id_cliente, sucursal, forma_pago, carrito, fecha=None, hora=None) -> Venta:
        """Registra una venta NUEVA desde la interfaz (uso normal del TPS en
        vivo). A diferencia de la carga inicial, aqui SI aplica la
        validacion real de stock (modo_historico=False).

        Si no se especifica fecha, se usa el dia siguiente a la ultima
        transaccion conocida del sistema (no la fecha real del reloj): el
        histórico completo está fechado en 2019, así que una venta nueva
        fechada "hoy" (años después) rompería el cálculo de recencia del
        RFM y del CRM para todo el resto de la base. Esto mantiene la
        línea de tiempo del sistema internamente consistente."""
        fecha = fecha or self.fecha_ultima_transaccion or datetime.now().strftime("%Y-%m-%d")
        hora = hora or datetime.now().strftime("%H:%M:%S")
        self._log_erp_antes = self.erp._contador_asientos
        self._log_scm_antes = self.scm._contador_ordenes

        venta = self.sistema.registrar_venta(
            id_cliente=id_cliente, sucursal=sucursal, forma_pago=forma_pago,
            carrito=carrito, fecha=fecha, hora=hora, modo_historico=False,
        )
        self.n_transacciones_nuevas_sesion += 1

        eventos = [f"[TPS] Venta {venta.id_venta} registrada para {id_cliente} — total ${venta.total:,.2f}"]
        if self.erp._contador_asientos > self._log_erp_antes:
            eventos.append(f"[ERP] Asiento contable generado automáticamente — caja chica: "
                            f"${self.erp.saldo_caja:,.2f}")
        if self.scm._contador_ordenes > self._log_scm_antes:
            eventos.append("[SCM] Stock bajo el mínimo detectado — orden de compra generada automáticamente")
        eventos.append(f"[CRM] Fecha de última compra de {id_cliente} actualizada automáticamente")

        self.log_integracion = eventos + self.log_integracion
        self.log_integracion = self.log_integracion[:40]
        return venta

    def ejecutar_consulta_crm(self, fecha_referencia: str, umbral_dias: int = 30, solo_member: bool = True):
        resultado = self.crm.detectar_clientes_en_riesgo(fecha_referencia, umbral_dias, solo_member)
        self.log_integracion = (
            [f"[CRM] Consulta automatizada ejecutada ({fecha_referencia}): "
             f"{len(resultado)} cliente(s) en riesgo detectado(s)."] + self.log_integracion
        )[:40]
        return resultado

    def recibir_pedido_manual(self, id_producto: str):
        producto = self.productos.get(id_producto)
        stock_antes = producto.stock_actual if producto else None
        self.scm.recibir_pedido(id_producto)
        if producto:
            self.log_integracion = (
                [f"[SCM] Pedido de '{producto.nombre}' recibido manualmente — "
                 f"stock {stock_antes} → {producto.stock_actual} u."] + self.log_integracion
            )[:40]

    # ------------------------------------------------------------------
    def kpis_generales(self) -> dict:
        ventas_csv = pd.read_csv(os.path.join(RUTA_DATOS, "ventas_sistema.csv"))
        facturas = ventas_csv.groupby("id_venta")["subtotal_linea"].sum()
        ingresos = round((facturas * 1.15).sum(), 2)
        return {
            "ingresos_totales": ingresos,
            "ticket_promedio": round((facturas * 1.15).mean(), 2) if len(facturas) else 0,
            "n_transacciones": len(facturas),
            "n_clientes": len(self.clientes),
            "saldo_caja": self.erp.saldo_caja if self.erp else 0,
            "n_ordenes_scm": self.scm._contador_ordenes if self.scm else 0,
        }


_instancia: MotorAplicacion | None = None


def obtener_motor() -> MotorAplicacion:
    """Devuelve la instancia unica (singleton) del motor, compartida por
    todas las pestañas de la aplicacion."""
    global _instancia
    if _instancia is None:
        _instancia = MotorAplicacion()
    return _instancia
