# -*- coding: utf-8 -*-
"""gui/tab_tps.py — Sistema Principal (TPS): registrar ventas nuevas y ver,
en vivo, como ERP/SCM/CRM reaccionan automaticamente (Fase 2.3)."""

import os
import tkinter as tk
from tkinter import ttk, messagebox

import pandas as pd

from gui.estilos import NAVY, TEAL, AMBER, RED, GRAY, WHITE, GRAY_LIGHT, BORDER, FUENTE
from gui.widgets import ComboAutocompletado, tabla_simple
from datos_maestros import MAPA_SUCURSAL

SUCURSALES = sorted(set(MAPA_SUCURSAL.values()))
FORMAS_PAGO = ["Efectivo", "Tarjeta de Credito", "Billetera Digital"]


class PestanaTPS(ttk.Frame):
    def __init__(self, parent, motor, app):
        super().__init__(parent, style="Fondo.TFrame")
        self.motor = motor
        self.app = app
        self.carrito = []  # lista de dicts: id_producto, nombre, cantidad, precio, subtotal
        self._construir()

    # ------------------------------------------------------------------
    def _construir(self):
        cont = tk.Frame(self, bg=GRAY_LIGHT)
        cont.pack(fill="both", expand=True, padx=20, pady=16)

        tk.Label(cont, text="TPS — Sistema Principal (Punto de Venta)", font=(FUENTE, 15, "bold"),
                 bg=GRAY_LIGHT, fg=NAVY).pack(anchor="w")
        tk.Label(cont, text="Cada venta registrada aquí notifica automáticamente a ERP, SCM y CRM "
                            "(patrón Observer) — mira el panel de actividad a la derecha.",
                 font=(FUENTE, 9), bg=GRAY_LIGHT, fg=GRAY).pack(anchor="w", pady=(2, 14))

        fila = tk.Frame(cont, bg=GRAY_LIGHT)
        fila.pack(fill="both", expand=True)
        fila.columnconfigure(0, weight=6)
        fila.columnconfigure(1, weight=4)
        fila.rowconfigure(0, weight=1)

        self._construir_formulario(fila)
        self._construir_panel_actividad(fila)

        # ---- Transacciones recientes ----
        marco_recientes = tk.Frame(cont, bg=WHITE, highlightbackground=BORDER, highlightthickness=1)
        marco_recientes.pack(fill="both", expand=False, pady=(14, 0))
        tk.Label(marco_recientes, text="Transacciones recientes", font=(FUENTE, 11, "bold"),
                 bg=WHITE, fg=NAVY).pack(anchor="w", padx=14, pady=(10, 4))
        marco_tabla, self.tabla_recientes = tabla_simple(
            marco_recientes,
            [("id_venta", "Venta", 90), ("cliente", "Cliente", 200), ("sucursal", "Sucursal", 90),
             ("fecha", "Fecha", 90), ("hora", "Hora", 70), ("producto", "Producto", 220),
             ("total", "Total", 90)],
            altura=6,
        )
        marco_tabla.pack(fill="both", expand=True, padx=14, pady=(0, 12))

        self.refrescar()

    # ------------------------------------------------------------------
    def _construir_formulario(self, parent):
        card = tk.Frame(parent, bg=WHITE, highlightbackground=BORDER, highlightthickness=1)
        card.grid(row=0, column=0, sticky="nsew", padx=(0, 10))

        interior = tk.Frame(card, bg=WHITE)
        interior.pack(fill="both", expand=True, padx=16, pady=14)

        tk.Label(interior, text="Nueva venta", font=(FUENTE, 12, "bold"), bg=WHITE, fg=NAVY
                 ).grid(row=0, column=0, columnspan=4, sticky="w", pady=(0, 10))

        tk.Label(interior, text="Cliente", bg=WHITE, fg=GRAY, font=(FUENTE, 9)
                 ).grid(row=1, column=0, sticky="w")
        opciones_cliente = sorted(
            [(cid, f"{c.nombre} ({cid}) — {c.tipo}") for cid, c in self.motor.clientes.items()],
            key=lambda x: x[1],
        )
        self.combo_cliente = ComboAutocompletado(interior, opciones_cliente, ancho=36)
        self.combo_cliente.grid(row=2, column=0, columnspan=4, sticky="ew", pady=(0, 10))

        tk.Label(interior, text="Sucursal", bg=WHITE, fg=GRAY, font=(FUENTE, 9)
                 ).grid(row=3, column=0, sticky="w")
        self.var_sucursal = tk.StringVar(value=SUCURSALES[0])
        ttk.Combobox(interior, textvariable=self.var_sucursal, values=SUCURSALES,
                     state="readonly", width=16).grid(row=4, column=0, sticky="w", pady=(0, 10))

        tk.Label(interior, text="Forma de pago", bg=WHITE, fg=GRAY, font=(FUENTE, 9)
                 ).grid(row=3, column=1, sticky="w")
        self.var_pago = tk.StringVar(value=FORMAS_PAGO[0])
        ttk.Combobox(interior, textvariable=self.var_pago, values=FORMAS_PAGO,
                     state="readonly", width=18).grid(row=4, column=1, sticky="w", pady=(0, 10))

        tk.Label(interior, text="Fecha (AAAA-MM-DD)", bg=WHITE, fg=GRAY, font=(FUENTE, 9)
                 ).grid(row=3, column=2, columnspan=2, sticky="w")
        self.var_fecha = tk.StringVar(value=self.motor.fecha_ultima_transaccion or "")
        tk.Entry(interior, textvariable=self.var_fecha, width=14
                 ).grid(row=4, column=2, columnspan=2, sticky="w", pady=(0, 10))

        ttk.Separator(interior).grid(row=5, column=0, columnspan=4, sticky="ew", pady=8)

        tk.Label(interior, text="Producto", bg=WHITE, fg=GRAY, font=(FUENTE, 9)
                 ).grid(row=6, column=0, sticky="w")
        opciones_prod = [f"{p.id_producto} — {p.nombre} (${p.precio_unitario:.2f}, stock {p.stock_actual})"
                          for p in self.motor.productos.values()]
        self.var_producto = tk.StringVar()
        combo_prod = ttk.Combobox(interior, textvariable=self.var_producto, values=opciones_prod,
                                   state="readonly", width=34)
        combo_prod.grid(row=7, column=0, columnspan=2, sticky="ew", pady=(0, 10))
        if opciones_prod:
            combo_prod.current(0)

        tk.Label(interior, text="Cantidad", bg=WHITE, fg=GRAY, font=(FUENTE, 9)
                 ).grid(row=6, column=2, sticky="w")
        self.var_cantidad = tk.IntVar(value=1)
        tk.Spinbox(interior, from_=1, to=99, textvariable=self.var_cantidad, width=6
                    ).grid(row=7, column=2, sticky="w", pady=(0, 10))

        ttk.Button(interior, text="+ Agregar", style="Secundario.TButton",
                   command=self._agregar_al_carrito).grid(row=7, column=3, sticky="w", padx=(6, 0))

        marco_carrito, self.tabla_carrito = tabla_simple(
            interior,
            [("producto", "Producto", 220), ("cantidad", "Cant.", 55),
             ("precio", "Precio", 80), ("subtotal", "Subtotal", 90)],
            altura=5,
        )
        marco_carrito.grid(row=8, column=0, columnspan=4, sticky="nsew", pady=(4, 10))
        interior.rowconfigure(8, weight=1)

        marco_totales = tk.Frame(interior, bg=WHITE)
        marco_totales.grid(row=9, column=0, columnspan=4, sticky="ew")
        self.lbl_subtotal = tk.Label(marco_totales, text="Subtotal: $0.00", bg=WHITE, fg=GRAY, font=(FUENTE, 9))
        self.lbl_subtotal.pack(side="left")
        self.lbl_impuesto = tk.Label(marco_totales, text="Impuesto (5%): $0.00", bg=WHITE, fg=GRAY, font=(FUENTE, 9))
        self.lbl_impuesto.pack(side="left", padx=14)
        self.lbl_total = tk.Label(marco_totales, text="TOTAL: $0.00", bg=WHITE, fg=NAVY, font=(FUENTE, 12, "bold"))
        self.lbl_total.pack(side="right")

        ttk.Button(interior, text="COBRAR VENTA  →", style="Amber.TButton",
                   command=self._registrar_venta).grid(row=10, column=0, columnspan=4, sticky="ew", pady=(12, 0))

        for c in range(4):
            interior.columnconfigure(c, weight=1)

    def _construir_panel_actividad(self, parent):
        card = tk.Frame(parent, bg=NAVY)
        card.grid(row=0, column=1, sticky="nsew")
        tk.Label(card, text="Actividad del sistema (en vivo)", font=(FUENTE, 11, "bold"),
                 bg=NAVY, fg=WHITE).pack(anchor="w", padx=14, pady=(12, 2))
        tk.Label(card, text="Evidencia de integración Fase 2.3: cada tarjeta aparece sin\n"
                            "intervención humana, disparada automáticamente por el TPS.",
                 font=(FUENTE, 8), bg=NAVY, fg="#9FB0C7", justify="left").pack(anchor="w", padx=14, pady=(0, 10))

        fondo_feed = "#141F35"
        contenedor = tk.Frame(card, bg=fondo_feed, highlightbackground="#26314D", highlightthickness=1)
        contenedor.pack(fill="both", expand=True, padx=14, pady=(0, 14))

        self.canvas_actividad = tk.Canvas(contenedor, bg=fondo_feed, highlightthickness=0, bd=0)
        scrollbar = ttk.Scrollbar(contenedor, orient="vertical", command=self.canvas_actividad.yview)
        self.marco_actividad = tk.Frame(self.canvas_actividad, bg=fondo_feed)
        self.marco_actividad.bind(
            "<Configure>",
            lambda e: self.canvas_actividad.configure(scrollregion=self.canvas_actividad.bbox("all")),
        )
        self._ventana_actividad = self.canvas_actividad.create_window((0, 0), window=self.marco_actividad, anchor="nw")
        self.canvas_actividad.bind(
            "<Configure>",
            lambda e: self.canvas_actividad.itemconfig(self._ventana_actividad, width=e.width),
        )
        self.canvas_actividad.configure(yscrollcommand=scrollbar.set)
        self.canvas_actividad.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

        def _rueda(event):
            self.canvas_actividad.yview_scroll(int(-1 * (event.delta / 120)), "units")
        self.canvas_actividad.bind_all("<MouseWheel>", _rueda, add="+")

    # ------------------------------------------------------------------
    def _agregar_al_carrito(self):
        seleccion = self.var_producto.get()
        if not seleccion:
            return
        id_producto = seleccion.split(" — ")[0]
        producto = self.motor.productos[id_producto]
        cantidad = max(1, self.var_cantidad.get())
        subtotal = round(producto.precio_unitario * cantidad, 2)
        self.carrito.append({
            "id_producto": id_producto, "nombre": producto.nombre,
            "cantidad": cantidad, "precio": producto.precio_unitario, "subtotal": subtotal,
        })
        self._refrescar_carrito()

    def _refrescar_carrito(self):
        self.tabla_carrito.delete(*self.tabla_carrito.get_children())
        subtotal_total = 0.0
        for linea in self.carrito:
            self.tabla_carrito.insert("", "end", values=(
                linea["nombre"], linea["cantidad"], f"${linea['precio']:.2f}", f"${linea['subtotal']:.2f}"))
            subtotal_total += linea["subtotal"]
        impuesto = round(subtotal_total * 0.05, 2)
        total = round(subtotal_total + impuesto, 2)
        self.lbl_subtotal.config(text=f"Subtotal: ${subtotal_total:,.2f}")
        self.lbl_impuesto.config(text=f"Impuesto (5%): ${impuesto:,.2f}")
        self.lbl_total.config(text=f"TOTAL: ${total:,.2f}")

    def _registrar_venta(self):
        id_cliente = self.combo_cliente.obtener()
        if not id_cliente:
            messagebox.showwarning("Falta el cliente", "Busca y selecciona un cliente de la lista.")
            return
        if not self.carrito:
            messagebox.showwarning("Carrito vacío", "Agrega al menos un producto al carrito.")
            return

        carrito_api = [(l["id_producto"], l["cantidad"]) for l in self.carrito]
        try:
            venta = self.motor.registrar_venta_nueva(
                id_cliente=id_cliente, sucursal=self.var_sucursal.get(),
                forma_pago=self.var_pago.get(), carrito=carrito_api,
                fecha=self.var_fecha.get().strip() or None,
            )
        except ValueError as e:
            messagebox.showerror("No se pudo registrar la venta", str(e))
            return

        messagebox.showinfo("Venta registrada", f"{venta.id_venta} registrada — Total ${venta.total:,.2f}")
        self.carrito = []
        self._refrescar_carrito()
        self.combo_cliente.limpiar()
        self.refrescar()
        if hasattr(self.app, "pestana_inicio"):
            self.app.pestana_inicio.refrescar()

    # ------------------------------------------------------------------
    def refrescar(self):
        self._refrescar_log()
        self._refrescar_recientes()

    COLOR_MODULO = {"TPS": TEAL, "ERP": "#7FB3FF", "SCM": AMBER, "CRM": "#FF8A80"}

    def _refrescar_log(self):
        for w in self.marco_actividad.winfo_children():
            w.destroy()

        eventos = self.motor.log_integracion[:20]
        fondo_feed = "#141F35"
        if not eventos:
            tk.Label(self.marco_actividad, bg=fondo_feed, fg="#8A93A6", font=(FUENTE, 9),
                     justify="left", wraplength=260,
                     text="Aún no hay actividad nueva en esta sesión.\n"
                          "Registra una venta para ver la integración en vivo."
                     ).pack(anchor="w", padx=10, pady=10)
            return

        for texto in eventos:
            modulo = next((t for t in ("TPS", "ERP", "SCM", "CRM") if f"[{t}]" in texto), None)
            color = self.COLOR_MODULO.get(modulo, GRAY)
            mensaje = texto.split("]", 1)[1].strip() if modulo else texto

            fila = tk.Frame(self.marco_actividad, bg="#1B2740")
            fila.pack(fill="x", padx=8, pady=4)
            tk.Frame(fila, bg=color, width=4).pack(side="left", fill="y")
            interior = tk.Frame(fila, bg="#1B2740")
            interior.pack(side="left", fill="both", expand=True, padx=10, pady=7)
            if modulo:
                tk.Label(interior, text=modulo, bg=color, fg="#0B111F", font=(FUENTE, 8, "bold"),
                         padx=6, pady=1).pack(anchor="w")
            tk.Label(interior, text=mensaje, bg="#1B2740", fg="#D8DEE9", font=(FUENTE, 9),
                     justify="left", wraplength=250, anchor="w").pack(anchor="w", pady=(4, 0))

    def _refrescar_recientes(self):
        try:
            df = pd.read_csv("data/ventas_sistema.csv")
        except FileNotFoundError:
            return
        ultimas = df.tail(10).iloc[::-1]
        self.tabla_recientes.delete(*self.tabla_recientes.get_children())
        for _, fila in ultimas.iterrows():
            nombre_cliente = self.motor.clientes.get(fila["id_cliente"])
            nombre = nombre_cliente.nombre if nombre_cliente else fila["id_cliente"]
            total_linea = round(fila["subtotal_linea"] * 1.05, 2)
            self.tabla_recientes.insert("", "end", values=(
                fila["id_venta"], nombre, fila["sucursal"], fila["fecha"], fila["hora"],
                fila["nombre_producto"], f"${total_linea:,.2f}"))
